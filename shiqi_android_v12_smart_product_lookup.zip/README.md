# 拾期 · SHELFIE

拾期是一款个人物品保质期管理 App，包含聊天式 AI 记录入口、物品清单、到期日历和多主题界面。当前交付为 **Android 源码工程，不是已编译 APK**。

## 当前功能
- 三套视觉主题：柔雾蔷薇、冰川蓝调、奶油手札
- 物品新增、编辑、删除、搜索、临期/过期筛选
- 产品标注到期日、生产日期 + 保质期限、开封日期 + 开封后期限；多种日期并存时按最早有效日期判断
- 月历视图、逐日到期物品、月份切换
- 拾期 AI 小助手：OpenAI Chat Completions 兼容 API，自然语言新增、修改、删除建议
- AI 批量录入：一次 1–20 件，全部校验、整体确认、原子式保存；任一条缺少日期依据则整批不保存
- AI 清单查询：查询结果 ID 由模型提出、由本机记录复核，卡片显示本机真实字段
- AI 开封登记：记录开封日期；仅在用户提供或记录中已有开封后期限时计算 PAO 日期，不猜测产品通用期限
- AI 修改、删除、批量新增、开封登记均需用户确认后执行
- JSON 备份导出/导入校验
- Android 本地 SQLite 保存物品记录；首次打开时把旧版 WebView localStorage 记录迁移到 SQLite
- Android 本地到期通知：按每件物品设置的提前天数，在提醒日当地上午 9 点排程；设置页提醒管理中心可逐件调整 7/3/1 天或关闭
- Android API Key 使用 Android Keystore AES-GCM 加密保存

## AI 使用示例
- 批量录入：“帮我记下牛奶，标注到期日 12 月 3 日；鸡蛋 12 月 8 日到期；面霜开封后 6 个月使用，我今天开封。”
- 查询：“哪些东西 7 天内到期？”、“有哪些已经开封？”、“面霜放在哪里？”
- 开封登记：“我今天开封了那瓶面霜。”如果同名物品不唯一，助手应先询问是哪一件。
- 修改/删除：“把牛奶存放位置改成冰箱冷藏层。”、“删除已经用完的面霜。”操作会先显示确认卡片。

## 日期与 AI 约束
- 日期用用户设备本地日历日处理；不按 UTC 时刻换算。
- 产品标注到期日、生产日期+保质期、开封日期+开封后期限是不同依据，不互相推断。
- AI 只根据用户明确提供的期限或已有记录处理；没有 PAO/保质期依据时，先追问。
- 查询只显示经本机 ID 校验的物品；批量新增采取整批校验和整批确认。

## Android 通知说明
- Android 13 及以上需要用户授权 `POST_NOTIFICATIONS`，可在「设置 → 系统到期提醒」开启。
- 通知通过 WorkManager 排程，目标触发时间是本地上午 9 点；WorkManager 属于可延迟后台任务，系统省电策略可能造成延后，不保证分钟级准点。
- 仍需在 OnePlus 12 上实际验证通知权限、省电策略、重启后重排及后台运行。

## Android 构建
查看 [`android/README.md`](android/README.md)。项目使用 JDK 17、Android SDK Platform 35、Gradle Wrapper 8.9、Android Gradle Plugin 8.7.3。

## 自动化测试
在项目根目录运行：

```bash
npm test
node --check www/app.js
node --check www/photo-recognition.js
node --check www/ai-mutations.js
```

当前测试覆盖日期边界、AI 修改/删除/批量新增/查询/开封登记、包装照片规范化、多照片冲突合并、条码结果清洗、商品目录查询/多目录兜底/手动搜索/缓存限频，以及 Android SQLite/WorkManager/Keystore/ML Kit/公开目录网络桥契约。V1.2 自动化测试结果为 63/63 通过，见 `TEST_REPORT_V1.2.md`。Android APK 编译与 OnePlus 12 真机联调仍需 Android SDK/设备验证。

## 当前限制
- 本轮未在当前开发环境重新编译 APK。
- AI 动作能否准确返回 JSON 仍取决于所配置模型对 JSON 指令的遵循程度；前端会校验 ID 和日期字段，无法保证每家服务商模型都完全遵循指令。
- V1.2 已接入 Open Facts 商品目录：条码 v3 查询、食品/美妆/宠物食品/日用品目录兜底、手动名称搜索。公开数据库由社区贡献，可能缺失或过时；查不到时可继续拍照识别和手动建档。官方要求自定义 User-Agent，并限制商品读取与搜索频率；本项目已添加识别性 User-Agent、查询冷却和短时缓存。详见官方 API 文档：https://openfoodfacts.github.io/documentation/docs/Product-Opener/api/
- 当前版本尚未完成 Android APK 编译、OnePlus 12 真机网络/相机/条码/通知回归、Release 签名和商店发布。

## 更新记录
- [V1.2：智能商品识别中心](CHANGELOG_V1.2.md)
- [V1.2：完工验收清单](FINALIZATION_CHECKLIST.md)
- [V1.1：多角度包装识别、本机条码扫描与 AI 补全](CHANGELOG_V1.1.md)
- [V0.9：AI 批量录入、清单查询与开封登记](CHANGELOG_V0.9.md)
- [V0.8：API 安全、AI 修改删除与提醒管理](CHANGELOG_V0.8.md)
- [V0.7：SQLite 与 Android 系统提醒](CHANGELOG_V0.7.md)
- [V0.6：期限规则与月历](CHANGELOG_V0.6.md)


## V1.0–V1.1 AI 包装识别

V1.0 支持相机/相册单图视觉识别；V1.1 扩展为最多 3 张同一商品照片联合识别（正面、背面、底部/PAO），并在本地比较逐图结果。若不同照片读出不同日期或期限，冲突字段会清空并要求人工核对。图片发送给用户自配的视觉模型前需要单次授权；原图不会进入 SQLite 或 JSON 备份。

V1.1 Android 版增加 Google ML Kit bundled Barcode Scanning：对已选择照片本地识别 EAN/UPC、Code 128/39、QR、Data Matrix 等条码。该步骤不上传照片；条码不作为任何日期/保质期证据。

V1.2 新增智能商品识别中心：先通过 Open Facts v3 按条码查全类型商品，未命中时再尝试食品、美妆、宠物食品、日用品目录；也可以手动按商品名/品牌搜索。资料由用户选用后填入草稿，公开资料中的日期/保质期不会导入。公开目录查不到时不阻断流程，可继续拍照识别或手动建档。商品名搜索由用户手动提交，不做逐字请求。

更新说明：[`CHANGELOG_V1.2.md`](CHANGELOG_V1.2.md)；V1.2 自动化测试报告：[`TEST_REPORT_V1.2.md`](TEST_REPORT_V1.2.md)。
