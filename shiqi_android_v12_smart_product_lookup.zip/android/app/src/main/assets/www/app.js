import {localDate,parseDate,diffDays,addShelfLife,getExpiryInfo,isValidExpiryRecord,getReminderDate} from './date-utils.js';
import {prepareAiMutation,prepareAiBatchCreate,prepareAiQuery,applyAiMutation} from './ai-mutations.js';
import {normalizePhotoExtraction,mergePhotoExtractions,normalizeBarcodeResults,hasPhotoExpiryBasis,photoDateBasisLabel,photoMissingRequirements} from './photo-recognition.js';
import {lookupBarcode,searchProducts,normalizeBarcodeCode} from './product-lookup.js';

const STORAGE_KEY='shelfie_items_v1';
const THEME_KEY='shelfie_theme_v1';
const API_KEY='shelfie_ai_config_v1';
const $=id=>document.getElementById(id);
const newId=()=>globalThis.crypto?.randomUUID?.()||`item-${Date.now()}-${Math.random().toString(36).slice(2,9)}`;
const categories=['食品饮料','护肤美妆','药品保健','日用百货','其他'];
let items=loadItems();
let currentFilter='all';
let searchQuery='';
let toastTimer;
let sessionApiKey='';
let apiConfig=loadApiConfig();
let chatHistory=[];
let pendingActions=new Map();
let expiryWasManuallyEdited=false;
let calendarMonth=new Date(new Date().getFullYear(),new Date().getMonth(),1,12);
let selectedCalendarDate=localDate(new Date());
let pendingImportItems=null;
let selectedPhotoDataUrls=[];
let selectedPhotoNames=[];
let photoExtraction=null;
let photoBarcodes=[];
let photoProductMatch=null;
let currentProductLookupResults=[];

function readBrowserItems(){try{const v=JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]');return Array.isArray(v)?v:[]}catch{return []}}
function nativeItemPayload(records){return records.map(item=>({...item,effectiveExpiry:getExpiryInfo(item).date,reminderDate:getReminderDate(item)}))}
function writeNativeItems(records){if(!window.ShelfieNative?.saveItemsJson)return true;try{return window.ShelfieNative.saveItemsJson(JSON.stringify(nativeItemPayload(records)))===true}catch{return false}}
function loadItems(){
  const browserItems=readBrowserItems();
  if(window.ShelfieNative?.getItemsJson){
    try{
      const nativeItems=JSON.parse(window.ShelfieNative.getItemsJson()||'[]');
      if(Array.isArray(nativeItems)&&nativeItems.length)return nativeItems;
      // One-time migration: preserve records from the previous WebView-only build.
      if(browserItems.length){writeNativeItems(browserItems);return browserItems;}
      return Array.isArray(nativeItems)?nativeItems:[];
    }catch{return browserItems}
  }
  return browserItems;
}
function saveItems(){
  let previousCache=null;
  try{previousCache=localStorage.getItem(STORAGE_KEY);localStorage.setItem(STORAGE_KEY,JSON.stringify(items));}
  catch(e){showToast('本机存储空间不足，请先导出备份或清理数据');return false}
  if(!writeNativeItems(items)){
    try{if(previousCache===null)localStorage.removeItem(STORAGE_KEY);else localStorage.setItem(STORAGE_KEY,previousCache)}catch{}
    showToast('SQLite 保存失败；本次修改未确认保存，请先导出 JSON 备份');return false
  }
  return true;
}
function loadApiConfig(){
  let config={};
  try{config=JSON.parse(localStorage.getItem(API_KEY)||'{}')||{}}catch{config={}}
  // Migrate legacy plaintext keys out of localStorage. Android saves them only through Keystore.
  if(config.apiKey){
    const legacy=String(config.apiKey);
    if(window.ShelfieNative?.saveApiKey){
      const stored=window.ShelfieNative.saveApiKey(legacy)===true;
      sessionApiKey=legacy;
      config.saveKey=stored;
    }else{
      sessionApiKey=legacy;
      config.saveKey=false;
    }
    delete config.apiKey;
    try{localStorage.setItem(API_KEY,JSON.stringify(config))}catch{}
  }
  if(window.ShelfieNative?.getSavedApiKey){
    try{const saved=window.ShelfieNative.getSavedApiKey();if(saved){sessionApiKey=saved;config.saveKey=true}}catch{}
  }else{
    config.saveKey=false;
  }
  return config;
}
function saveApiConfig(){
  const baseUrl=$('apiBaseUrl').value.trim();
  if(!/^https:\/\//i.test(baseUrl)){showToast('为保护 API Key，接口地址必须使用 HTTPS');return}
  const entered=$('apiKey').value.trim();
  const key=entered||sessionApiKey;
  const wantsSave=$('saveApiKey').checked;
  let savedOnDevice=false;
  if(wantsSave&&window.ShelfieNative?.saveApiKey){
    if(!key){showToast('请先填写 API Key');return}
    if(window.ShelfieNative.saveApiKey(key)!==true){showToast('Android Keystore 保存失败，请取消记住选项后重试');return}
    savedOnDevice=true;
  }else if(!wantsSave&&window.ShelfieNative?.clearApiKey){
    if(window.ShelfieNative.clearApiKey()!==true){showToast('无法清除设备上已保存的 API Key');return}
  }
  sessionApiKey=key;
  if(wantsSave&&!window.ShelfieNative){showToast('浏览器预览不会持久保存 API Key，仅本次会话可用')}
  const temp=Number($('apiTemperature').value);
  apiConfig={baseUrl,model:$('apiModel').value.trim(),temperature:Number.isFinite(temp)?Math.max(0,Math.min(2,temp)):0.2,saveKey:savedOnDevice,saveMode:$('aiSaveMode').value};
  localStorage.setItem(API_KEY,JSON.stringify(apiConfig));
  $('apiKey').value='';
  $('apiKey').placeholder=savedOnDevice?'已通过 Android Keystore 加密保存；留空继续使用':'粘贴你自己的 API Key';
  $('saveApiKey').checked=savedOnDevice;
  updateApiStatus();
  showToast(savedOnDevice?'API 配置已保存，Key 已由 Android Keystore 加密保护':'API 配置已保存');
}
function effectiveApiKey(){return $('apiKey')?.value.trim()||sessionApiKey||''}
function apiEndpoint(){let base=(apiConfig.baseUrl||$('apiBaseUrl')?.value||'').trim().replace(/\/+$/,'');if(!base)return '';return base.endsWith('/chat/completions')?base:`${base}/chat/completions`}
function statusOf(item){const d=diffDays(getExpiryInfo(item).date);if(d===null)return {kind:'unknown',count:'—',label:'待补日期'};if(d<0)return {kind:'expired',count:`${Math.abs(d)}天`,label:'已过期'};if(d===0)return {kind:'today',count:'今天',label:'到期日'};if(d<=7)return {kind:'soon',count:`${d}天`,label:'即将到期'};if(d<=30)return {kind:'month',count:`${d}天`,label:'30 天内'};return {kind:'safe',count:`${d}天`,label:'剩余时间'}}
function fmtDate(value){if(!value)return '未填写';const d=parseDate(value);if(!d||Number.isNaN(d.getTime()))return '未填写';return `${d.getFullYear()}.${String(d.getMonth()+1).padStart(2,'0')}.${String(d.getDate()).padStart(2,'0')}`}
function showToast(message){const t=$('toast');if(!t)return;t.textContent=message;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),2500)}
function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function iconSvg(category){
  const paths={
    '食品饮料':'<path d="M12 3v3M7 6h10l1.2 14H5.8L7 6Z"/><path d="M8 10h8M9 14c1.8 1.8 4.2 1.8 6 0"/>',
    '护肤美妆':'<path d="M9 4h6v3H9zM10 7h4v2l2 2v8H8v-8l2-2z"/><path d="M9 14h6M11 17h2"/>',
    '药品保健':'<rect x="7" y="5" width="10" height="15" rx="3"/><path d="M10 5V3h4v2M12 9v7M9 12.5h6"/>',
    '日用百货':'<path d="M6 8h12l1 12H5L6 8Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2M9 13h6"/>',
    '其他':'<path d="M4 9.5 12 5l8 4.5v9l-8 4-8-4z"/><path d="m4 9.5 8 4.5 8-4.5M12 14v8M8 7.2l8 4.5"/>'
  };
  return `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[category]||paths['其他']}</svg>`;
}
function itemCounts(){const c={total:items.length,soon:0,expired:0};items.forEach(i=>{const s=statusOf(i);if(s.kind==='soon'||s.kind==='today')c.soon++;if(s.kind==='expired')c.expired++});return c}
function renderRail(){
  const c=itemCounts();
  $('railTotal').textContent=c.total;$('railSoon').textContent=c.soon;$('railExpired').textContent=c.expired;$('sideItemCount').textContent=c.total;
  const upcoming=[...items].filter(x=>getExpiryInfo(x).date).sort((a,b)=>getExpiryInfo(a).date.localeCompare(getExpiryInfo(b).date)).filter(x=>diffDays(getExpiryInfo(x).date)<=30).slice(0,4);
  $('railUpcoming').innerHTML=upcoming.length?upcoming.map(i=>{const s=statusOf(i);return `<div class="rail-upcoming-item"><i class="rail-date-dot" style="background:${s.kind==='expired'||s.kind==='today'?'var(--danger)':'var(--warn)'}"></i><div><b>${escapeHtml(i.name)}</b><small>${fmtDate(getExpiryInfo(i).date)} · ${s.label} ${s.count}</small></div></div>`}).join(''):'<p class="rail-empty">暂时没有临期物品。</p>';
}
function renderInventory(){
  const c=itemCounts();$('totalCount').textContent=c.total;$('soonCount').textContent=c.soon;$('expiredCount').textContent=c.expired;
  const filtered=items.filter(i=>{const s=statusOf(i);const match=currentFilter==='all'||(currentFilter==='soon'&&(s.kind==='soon'||s.kind==='today'))||(currentFilter==='month'&&(s.kind==='soon'||s.kind==='today'||s.kind==='month'))||(currentFilter==='expired'&&s.kind==='expired');const q=searchQuery.trim().toLowerCase();const effective=getExpiryInfo(i).date;const text=[i.name,i.category,i.location||'',i.note||'',i.manufacture||'',i.expiry||'',i.openedDate||'',effective||''].join(' ').toLowerCase();return match&&(!q||text.includes(q))}).sort((a,b)=>(getExpiryInfo(a).date||'9999').localeCompare(getExpiryInfo(b).date||'9999'));
  $('visibleCount').textContent=filtered.length;
  $('inventoryList').innerHTML=filtered.map(item=>{const s=statusOf(item),exp=getExpiryInfo(item);const basis=exp.basis==='after-opening'?'按开封后期限':'产品标注/计算日期';return `<article class="item-card" data-open-item="${escapeHtml(item.id)}" tabindex="0" role="button" aria-label="查看${escapeHtml(item.name)}详情"><div class="item-art">${iconSvg(item.category)}</div><div class="item-main"><div class="item-title-row"><span class="item-title">${escapeHtml(item.name)}</span><span class="category-label">${escapeHtml(item.category)}</span></div><div class="item-meta">到期 ${fmtDate(exp.date)} · ${item.quantity||1} 件<span class="item-location">${escapeHtml(item.location||'尚未设置存放位置')} · ${basis}</span></div></div><div class="item-status status-${s.kind}"><strong class="status-count">${s.count}</strong><span class="status-label">${s.label}</span></div></article>`}).join('');
  $('emptyState').hidden=filtered.length!==0;$('inventoryList').style.display=filtered.length?'grid':'none';
}
function renderCalendar(){
  const c=itemCounts();
  $('calendarSummary').innerHTML=`<div><b>${c.total}</b><span>全部物品</span></div><div><b>${c.soon}</b><span>7 天内到期</span></div><div><b>${c.expired}</b><span>已经过期</span></div>`;
  const year=calendarMonth.getFullYear(),month=calendarMonth.getMonth();
  $('calendarMonthLabel').textContent=`${year} 年 ${month+1} 月`;
  const firstWeekday=new Date(year,month,1,12).getDay();
  const daysInMonth=new Date(year,month+1,0,12).getDate();
  const weekdayNames=['日','一','二','三','四','五','六'];
  const dateMap=new Map();
  items.forEach(item=>{const date=getExpiryInfo(item).date;if(!date)return;if(!dateMap.has(date))dateMap.set(date,[]);dateMap.get(date).push(item)});
  let html=weekdayNames.map(d=>`<div class="calendar-weekday">${d}</div>`).join('');
  for(let i=0;i<firstWeekday;i++)html+='<div class="calendar-day calendar-day-empty" aria-hidden="true"></div>';
  const today=localDate(new Date());
  for(let day=1;day<=daysInMonth;day++){
    const date=`${year}-${String(month+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
    const dayItems=dateMap.get(date)||[];
    const selected=date===selectedCalendarDate;
    html+=`<button type="button" class="calendar-day${date===today?' is-today':''}${selected?' is-selected':''}${dayItems.length?' has-items':''}" data-calendar-date="${date}" aria-label="${date}，${dayItems.length} 件到期物品"><span class="calendar-day-number">${day}</span>${dayItems.length?`<span class="calendar-day-count">${dayItems.length} 件</span>`:'<span class="calendar-day-count empty">　</span>'}</button>`;
  }
  $('calendarGrid').innerHTML=html;
  const selectedItems=dateMap.get(selectedCalendarDate)||[];
  $('calendarSelected').innerHTML=`<div class="calendar-selected-heading"><strong>${fmtDate(selectedCalendarDate)}</strong><span>${selectedItems.length} 件物品到期</span></div>${selectedItems.length?selectedItems.map(i=>{const st=statusOf(i);return `<article class="item-card" data-open-item="${escapeHtml(i.id)}" role="button" tabindex="0"><div class="item-art">${iconSvg(i.category)}</div><div class="item-main"><div class="item-title-row"><span class="item-title">${escapeHtml(i.name)}</span><span class="category-label">${escapeHtml(i.category)}</span></div><div class="item-meta">${escapeHtml(i.location||'尚未设置存放位置')}</div></div><div class="item-status status-${st.kind}"><strong>${st.label}</strong><span>${st.count}</span></div></article>`}).join(''):'<p class="calendar-no-items">这一天没有记录到期物品，可以安心一点 ♡</p>'}`;
  const upcoming=[...items].filter(i=>getExpiryInfo(i).date).sort((a,b)=>getExpiryInfo(a).date.localeCompare(getExpiryInfo(b).date));
  $('calendarUpcoming').innerHTML=upcoming.length?upcoming.map(i=>{const st=statusOf(i),exp=getExpiryInfo(i).date;return `<article class="item-card" data-open-item="${escapeHtml(i.id)}" role="button" tabindex="0"><div class="item-art">${iconSvg(i.category)}</div><div class="item-main"><div class="item-title-row"><span class="item-title">${escapeHtml(i.name)}</span><span class="category-label">${escapeHtml(i.category)}</span></div><div class="item-meta">${fmtDate(exp)} · ${escapeHtml(i.location||'未设置存放位置')}</div></div><div class="item-status status-${st.kind}"><strong class="status-count">${st.count}</strong><span class="status-label">${st.label}</span></div></article>`}).join(''):'<div class="empty-state"><div class="empty-art">☾</div><h3>日历还很空</h3><p>添加物品后，这里会按到期日期列出安排。</p></div>';
}
function render(){renderInventory();renderRail();renderCalendar();renderReminderManager()}
function renderReminderManager(){
  const root=$('reminderManager');if(!root)return;
  const enabled=items.filter(item=>Number(item.reminderDays)>0&&getReminderDate(item));
  const disabled=items.length-enabled.length;
  $('reminderManagerSummary').textContent=`${enabled.length} 件已设置提醒 · ${disabled} 件已关闭或缺少有效日期`;
  if(!items.length){root.innerHTML='<p class="reminder-manager-empty">还没有物品记录，添加物品后就能在这里管理提醒。</p>';return}
  const sorted=[...items].sort((a,b)=>(getExpiryInfo(a).date||'9999').localeCompare(getExpiryInfo(b).date||'9999'));
  root.innerHTML=sorted.map(item=>{
    const expiry=getExpiryInfo(item).date;
    const days=Number(item.reminderDays)||0;
    const reminder=getReminderDate(item);
    const label=days>0&&reminder?`提醒日期 ${fmtDate(reminder)} · 到期 ${fmtDate(expiry)}`:`到期 ${fmtDate(expiry)} · 当前未提醒`;
    return `<article class="reminder-manager-row"><div class="reminder-manager-copy"><b>${escapeHtml(item.name)}</b><small>${escapeHtml(item.category||'其他')} · ${label}</small></div><label class="reminder-manager-select"><span>提前</span><select data-reminder-days="${escapeHtml(item.id)}" aria-label="${escapeHtml(item.name)}提前提醒天数"><option value="7"${days===7?' selected':''}>7 天</option><option value="3"${days===3?' selected':''}>3 天</option><option value="1"${days===1?' selected':''}>1 天</option><option value="0"${days===0?' selected':''}>关闭</option></select></label></article>`;
  }).join('');
}
function updateReminderDays(id,value){
  const days=Math.max(0,Math.min(30,Number(value)||0));
  const previous=items;
  items=items.map(item=>item.id===id?{...item,reminderDays:days}:item);
  if(!saveItems()){items=previous;renderReminderManager();return}
  render();
  showToast(days?`已设为提前 ${days} 天提醒`:'已关闭这件物品的提醒');
}
function setFilter(filter){currentFilter=filter;document.querySelectorAll('.chip').forEach(c=>c.classList.toggle('active',c.dataset.filter===filter));renderInventory()}
function openModal(id){$(id).hidden=false;document.body.style.overflow='hidden'}
function closeModal(id){$(id).hidden=true;document.body.style.overflow='';if(id==='photoScanModal')resetPhotoScan()}
function resetForm(){$('itemForm').reset();$('editingId').value='';$('itemQuantity').value='1';$('modalTitle').textContent='添加一件物品';$('calculatedHint').textContent='填写生产日期和保质期可自动计算；若记录开封后期限，拾期会按更早的日期提醒。';$('expiryDate').value='';expiryWasManuallyEdited=false}
function startAdd(){resetForm();$('manufactureDate').value=localDate(new Date());openModal('itemModal')}
function editItem(id){const i=items.find(x=>x.id===id);if(!i)return;resetForm();$('editingId').value=i.id;$('modalTitle').textContent='编辑物品记录';$('itemName').value=i.name;$('itemCategory').value=i.category;$('itemQuantity').value=i.quantity||1;$('manufactureDate').value=i.manufacture||'';$('shelfLife').value=i.shelfLife||'';$('shelfUnit').value=i.shelfUnit||'days';$('expiryDate').value=i.expiry||'';$('openedDate').value=i.openedDate||'';$('afterOpeningValue').value=i.afterOpeningValue||'';$('afterOpeningUnit').value=i.afterOpeningUnit||'months';$('itemLocation').value=i.location||'';$('reminderDays').value=String(i.reminderDays??7);$('itemNote').value=i.note||'';expiryWasManuallyEdited=!!i.expiry;$('calculatedHint').textContent=`当前有效到期日：${fmtDate(getExpiryInfo(i).date)}。如填写开封后期限，将以更早的日期为准。`;closeModal('detailModal');openModal('itemModal')}
function showDetails(id){
  const i=items.find(x=>x.id===id);if(!i)return;
  const s=statusOf(i),expiryInfo=getExpiryInfo(i);
  const unitLabel=u=>u==='days'?'天':u==='years'?'年':'个月';
  $('detailContent').innerHTML=`<div class="sheet-heading"><div><p class="eyebrow">ITEM DETAILS</p><h2 id="detailTitle">物品记录</h2></div><button class="close-button" data-close="detailModal">×</button></div><div class="detail-hero"><div class="item-art">${iconSvg(i.category)}</div><div><h2>${escapeHtml(i.name)}</h2><p>${escapeHtml(i.category)} · ${i.quantity||1} 件</p></div></div><div class="detail-grid"><div class="detail-cell"><small>生产日期</small><strong>${fmtDate(i.manufacture)}</strong></div><div class="detail-cell"><small>产品标注到期日</small><strong>${fmtDate(i.expiry)}</strong></div><div class="detail-cell"><small>保质期限</small><strong>${i.shelfLife?`${i.shelfLife}${unitLabel(i.shelfUnit)}`:'未填写'}</strong></div><div class="detail-cell"><small>开封日期</small><strong>${fmtDate(i.openedDate)}</strong></div><div class="detail-cell"><small>开封后期限</small><strong>${i.afterOpeningValue?`${i.afterOpeningValue}${unitLabel(i.afterOpeningUnit)}`:'未填写'}</strong></div><div class="detail-cell"><small>当前有效到期日</small><strong>${fmtDate(expiryInfo.date)}</strong></div><div class="detail-cell"><small>当前状态</small><strong>${s.label} · ${s.count}</strong></div><div class="detail-cell"><small>存放位置</small><strong>${escapeHtml(i.location||'未设置')}</strong></div><div class="detail-cell"><small>提醒设置</small><strong>${i.reminderDays>0?`提前 ${i.reminderDays} 天（计划 ${fmtDate(getReminderDate(i))}）`:'关闭'}</strong></div></div><p class="detail-note">${i.note?escapeHtml(i.note):'还没有添加备注。'}</p><div class="detail-actions"><button class="danger-button" id="deleteCurrent">删除记录</button><button class="primary-button" id="editCurrent">编辑记录　↗</button></div>`;
  openModal('detailModal');$('detailContent').querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>closeModal(b.dataset.close));$('deleteCurrent').onclick=()=>{const previous=items;items=items.filter(x=>x.id!==id);if(!saveItems()){items=previous;return}closeModal('detailModal');render();showToast('这件物品已从清单移除')};$('editCurrent').onclick=()=>editItem(id);
}
function applyTheme(theme){document.body.dataset.theme=theme;localStorage.setItem(THEME_KEY,theme);document.querySelectorAll('.theme-option').forEach(el=>el.classList.toggle('selected',el.dataset.themeChoice===theme));const colors={rose:'#f7e8ed',blue:'#e8f3f9',cream:'#f3ecde'};document.querySelector('meta[name="theme-color"]').content=colors[theme]||colors.rose}
function exportData(){const payload={app:'SHELFIE',version:3,exportedAt:new Date().toISOString(),items};if(window.ShelfieNative?.exportBackup){window.ShelfieNative.exportBackup(JSON.stringify(payload,null,2));showToast('已打开系统保存窗口');return}const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`拾期备份-${localDate(new Date())}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);showToast('备份文件已导出')}
function importData(file){
  const reader=new FileReader();
  reader.onload=()=>{
    try{
      const parsed=JSON.parse(reader.result);
      const incoming=Array.isArray(parsed)?parsed:parsed.items;
      if(!Array.isArray(incoming))throw new Error('bad');
      const clean=incoming.map(normalizeImportedItem).filter(Boolean);
      if(!clean.length&&incoming.length)throw new Error('no-valid-records');
      pendingImportItems=clean;
      $('importConfirmMessage').textContent=`备份中有 ${incoming.length} 条记录，其中 ${clean.length} 条通过校验。确认后会用备份内容替换本机当前清单（${items.length} 条）；建议先导出当前数据。`;
      openModal('importConfirmModal');
    }catch(e){showToast(e.message==='no-valid-records'?'备份中没有有效日期记录，未导入':'文件格式不正确，未能导入')}
  };
  reader.readAsText(file);
}
function cancelImport(){pendingImportItems=null;closeModal('importConfirmModal')}
function confirmImport(){
  if(!pendingImportItems)return;
  const previous=items;
  items=pendingImportItems;
  if(!saveItems()){items=previous;pendingImportItems=null;return}
  const count=items.length;pendingImportItems=null;closeModal('importConfirmModal');render();showToast(`已安全导入 ${count} 条记录`);
}
function normalizeImportedItem(raw){if(!raw||typeof raw!=='object')return null;const clean={...raw,id:String(raw.id||newId()),name:String(raw.name||'').trim(),category:categories.includes(raw.category)?raw.category:categoryFromText(raw.category||raw.name),quantity:Math.max(1,Math.min(999,Number(raw.quantity)||1)),manufacture:parseDate(raw.manufacture)?raw.manufacture:'',shelfLife:Number.isInteger(Number(raw.shelfLife))&&Number(raw.shelfLife)>0?Number(raw.shelfLife):null,shelfUnit:['days','months','years'].includes(raw.shelfUnit)?raw.shelfUnit:'days',expiry:parseDate(raw.expiry)?raw.expiry:'',openedDate:parseDate(raw.openedDate)?raw.openedDate:'',afterOpeningValue:Number.isInteger(Number(raw.afterOpeningValue))&&Number(raw.afterOpeningValue)>0?Number(raw.afterOpeningValue):null,afterOpeningUnit:['days','months','years'].includes(raw.afterOpeningUnit)?raw.afterOpeningUnit:'months',location:String(raw.location||''),note:String(raw.note||''),reminderDays:Number.isInteger(Number(raw.reminderDays))?Math.max(0,Math.min(30,Number(raw.reminderDays))):7,createdAt:raw.createdAt||new Date().toISOString()};if(!clean.name||!isValidExpiryRecord(clean))return null;return clean}

function goToView(name){const target=name==='overview'?'assistant':name;const views={assistant:'assistantView',inventory:'inventoryView',calendar:'calendarView',settings:'settingsView'};if(!views[target])return;Object.entries(views).forEach(([k,id])=>{const el=$(id);el.hidden=k!==target;el.classList.toggle('active',k===target)});document.querySelectorAll('[data-nav]').forEach(el=>{const active=el.dataset.nav===target||(target==='assistant'&&el.dataset.nav==='overview');el.classList.toggle('active',active)});window.scrollTo({top:0,behavior:'smooth'});if(target==='settings'){populateApiForm();updateNotificationStatus();renderReminderManager()}}

// The assistant asks the configured OpenAI-compatible model for a strict JSON envelope.
const ACTION_SCHEMA=`你必须只输出一个合法 JSON 对象：{"reply":"自然、准确的中文回复","action":null 或一个动作对象}。新增记录遵循用户设置的保存模式：选择“确认后保存”时显示确认卡片，选择“信息完整时自动保存”时只有日期依据完整的新增记录可自动写入；修改、删除和登记开封无论何种模式都必须显示确认卡片，用户点击确认前不得保存。
新增单件：{"type":"create_item","item":{"name":"物品名","category":"食品饮料|护肤美妆|药品保健|日用百货|其他","quantity":1,"manufacture":"YYYY-MM-DD或空字符串","shelfLife":数字或null,"shelfUnit":"days|months|years","expiry":"YYYY-MM-DD或空字符串","openedDate":"YYYY-MM-DD或空字符串","afterOpeningValue":数字或null,"afterOpeningUnit":"days|months|years","location":"","note":"","reminderDays":7}}。
批量新增：{"type":"create_items","items":[上面格式的物品对象,...]}，一次最多20件；批量必须完整校验、整体确认、整体保存，不得只保存其中有效的部分。只要任一件缺少有效到期依据，就不提出动作，而是列出缺少信息的物品并追问。
修改：{"type":"update_item","itemId":"必须来自当前清单的精确 id","patch":{"只写需要修改的字段":"新值"}}。删除：{"type":"delete_item","itemId":"必须来自当前清单的精确 id"}。
登记开封：{"type":"record_opened","itemId":"必须来自当前清单的精确 id","openedDate":"YYYY-MM-DD","afterOpeningValue":数字或null,"afterOpeningUnit":"days|months|years"}。用户说“今天/昨天开封”时，按系统提供的本地今天日期计算；只有用户明确说出或清单中已有开封后期限时，才设置 afterOpeningValue，不得猜 PAO 期限。即使缺少开封后期限，也可以只登记 openedDate，并明确告诉用户之后可补充包装上的开封后期限。
查询：{"type":"query_items","itemIds":["清单中匹配的物品 id",...]}。用户询问“哪些快到期”“已开封的有哪些”“牛奶放在哪里”等清单查询时，必须从当前物品数据中选择匹配 id；没有匹配项时返回空数组。前端会用本地清单核对这些 id，不能编造物品或字段。
修改、删除、开封、查询时必须严格使用当前清单 id；同名物品存在多条且用户未明确指出时先追问，不得猜选。patch 只允许 name/category/quantity/manufacture/shelfLife/shelfUnit/expiry/openedDate/afterOpeningValue/afterOpeningUnit/location/note/reminderDays；日期必须来自用户明确提供的信息。产品标注到期日、生产日期+保质期、开封日期+开封后期限是三种不同依据，不能混淆，不能凭常识推断通用保质期。相对日期按系统提供的本地今天日期计算。普通闲聊或解释型问题 action 为 null。新增日期依据不足时 action 为 null 并追问。不要输出 Markdown 代码围栏。`;
function makeSystemPrompt(){
  const today=localDate(new Date());
  const visible=items.slice(0,300).map(i=>{
    const expiryInfo=getExpiryInfo(i);
    return {
      id:i.id,name:i.name,category:i.category,quantity:i.quantity||1,
      effectiveExpiry:expiryInfo.date||'',expiryBasis:expiryInfo.basis,
      printedExpiry:i.expiry||'',manufacture:i.manufacture||'',shelfLife:i.shelfLife||null,shelfUnit:i.shelfUnit||'',
      openedDate:i.openedDate||'',afterOpeningExpiry:expiryInfo.afterOpeningExpiry||'',
      afterOpeningValue:i.afterOpeningValue||null,afterOpeningUnit:i.afterOpeningUnit||'',
      location:i.location||'',note:i.note||'',reminderDays:i.reminderDays??7,
      reminderDate:getReminderDate(i),daysLeft:diffDays(expiryInfo.date),daysSinceOpened:i.openedDate?diffDays(today)-diffDays(i.openedDate):null
    };
  });
  const counts=itemCounts();
  return `你是「拾期 SHELFIE」里的温柔、准确、谨慎的保质期管理助手。今天的用户本地日期是 ${today}。当前新增记录保存模式：${apiConfig.saveMode==='auto'?'信息完整时自动保存':'确认卡片后保存'}。本地清单共 ${items.length} 件；本次上下文提供 ${visible.length} 件${items.length>visible.length?'（清单超过上下文上限，只包含前300件；若查询可能遗漏，请说明并让用户缩小范围）':''}。状态统计：${JSON.stringify(counts)}。当前物品数据如下：${JSON.stringify(visible)}。
查询规则：日期比较只使用 YYYY-MM-DD 本地日期和 daysLeft；“快到期”默认指未来30天内（含今天），用户指定7天/本周等范围时严格按其范围；“已过期”是 daysLeft<0；“今天到期”是 daysLeft=0；“已开封”是 openedDate 非空；“未开封”是 openedDate 为空。回答存放位置、数量、有效到期日时必须引用清单字段，不得猜测。查询时返回 query_items 动作及精确 itemIds，以便界面展示已核实清单。
录入规则：用户一次说多件物品时，尽量使用 create_items 批量整理；每件都必须有有效到期依据：产品标注到期日，或生产日期+保质期，或开封日期+开封后期限。如果其中任何一件缺少依据，不要提交部分批次，说明具体缺少什么。用户只提供“开封了”时记录实际开封日期，不要自行推测开封后可用多久；没有 PAO 信息就追问或保留为空。所有相对日期按今天 ${today} 计算。
${ACTION_SCHEMA}`;
}
function apiPayload(messages){return {model:apiConfig.model||$('apiModel').value.trim(),temperature:Number(apiConfig.temperature??0.2),messages:[{role:'system',content:makeSystemPrompt()},...messages]}}
function apiUrl(){const v=(apiConfig.baseUrl||$('apiBaseUrl').value||'').trim().replace(/\/+$/,'');return v.endsWith('/chat/completions')?v:`${v}/chat/completions`}
function requestApiBody(payload){
  const url=apiUrl(),key=effectiveApiKey();
  if(!url||!key||!apiConfig.model)return Promise.reject(new Error('请先填写 API Base URL、模型名称和 API Key。'));
  if(!/^https:\/\//i.test(url))return Promise.reject(new Error('为保护 API Key，接口地址必须使用 HTTPS。'));
  const body=JSON.stringify(payload);
  if(window.ShelfieNative?.chatCompletion){return new Promise((resolve,reject)=>{const id=`r${Date.now()}${Math.random().toString(36).slice(2,6)}`;window.__shelfiePending=window.__shelfiePending||{};window.__shelfiePending[id]={resolve,reject};window.ShelfieNative.chatCompletion(id,url,key,body)})}
  return fetch(url,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${key}`},body}).then(async r=>{const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.error?.message||`API 请求失败（HTTP ${r.status}）`);return data})
}
function callCompletion(messages){return requestApiBody(apiPayload(messages))}
function extractEnvelope(content){let raw=String(content||'').trim();raw=raw.replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'');const first=raw.indexOf('{'),last=raw.lastIndexOf('}');if(first>=0&&last>first){try{return JSON.parse(raw.slice(first,last+1))}catch{}}return {reply:raw,action:null}}
function categoryFromText(value){const v=String(value||'');return categories.includes(v)?v:(v.includes('面霜')||v.includes('精华')||v.includes('护肤')||v.includes('口红')?'护肤美妆':v.includes('药')||v.includes('维生素')?'药品保健':v.includes('洗')||v.includes('纸')||v.includes('清洁')?'日用百货':v.includes('牛奶')||v.includes('饮')||v.includes('食品')||v.includes('面包')||v.includes('零食')?'食品饮料':'其他')}
function normalizeAiItem(raw, existing=null){
  const source={...(existing||{}),...(raw||{}),id:existing?.id||raw?.id||newId(),createdAt:existing?.createdAt||raw?.createdAt||new Date().toISOString()};
  const name=String(source.name||'').trim();if(!name)return null;
  const validOrEmpty=value=>!value||Boolean(parseDate(String(value)));
  const manufacture=validOrEmpty(source.manufacture)?String(source.manufacture||''):'';
  const openedDate=validOrEmpty(source.openedDate)?String(source.openedDate||''):'';
  const shelfLife=Number(source.shelfLife)>0&&Number.isInteger(Number(source.shelfLife))?Number(source.shelfLife):null;
  const shelfUnit=['days','months','years'].includes(source.shelfUnit)?source.shelfUnit:'days';
  const afterOpeningValue=Number(source.afterOpeningValue)>0&&Number.isInteger(Number(source.afterOpeningValue))?Number(source.afterOpeningValue):null;
  const afterOpeningUnit=['days','months','years'].includes(source.afterOpeningUnit)?source.afterOpeningUnit:'months';
  let expiry=validOrEmpty(source.expiry)?String(source.expiry||''):'';
  if(!expiry&&manufacture&&shelfLife)expiry=addShelfLife(manufacture,shelfLife,shelfUnit);
  const item={id:source.id,name,category:categoryFromText(source.category||name),quantity:Math.max(1,Math.min(999,Number(source.quantity)||1)),manufacture,shelfLife,shelfUnit,expiry,openedDate,afterOpeningValue,afterOpeningUnit,location:String(source.location||''),note:String(source.note||''),reminderDays:Number.isFinite(Number(source.reminderDays))?Math.max(0,Math.min(30,Number(source.reminderDays))):7,createdAt:source.createdAt,source:source.source||'assistant'};
  if(!isValidExpiryRecord(item))return null;
  return item;
}
function addMessage(role,text){const row=document.createElement('div');row.className=`message-row ${role==='user'?'user-message':'assistant-message'}`;const avatar=document.createElement('div');avatar.className='message-avatar';avatar.textContent=role==='user'?'妳':'✿';const body=document.createElement('div');body.className='message-body';const name=document.createElement('div');name.className='message-name';name.textContent=role==='user'?'我':'拾期小助手';const time=document.createElement('time');time.textContent=new Date().toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'});name.appendChild(time);const bubble=document.createElement('div');bubble.className=`bubble ${role==='user'?'user-bubble':'assistant-bubble'}`;bubble.textContent=text;body.append(name,bubble);row.append(avatar,body);$('chatMessages').appendChild(row);$('chatMessages').scrollTop=$('chatMessages').scrollHeight;return row}
function createAiRecordCard(item){
  const id=newId();pendingActions.set(id,{type:'create',item});
  const info=getExpiryInfo(item),unitLabel=u=>u==='days'?'天':u==='years'?'年':'个月';
  const card=document.createElement('section');card.className='ai-record-card';card.dataset.aiAction=id;
  card.innerHTML=`<div class="ai-record-title"><span>✧ 待确认的物品记录</span><span>拾期已整理</span></div><div class="ai-record-grid"><div><small>物品名称</small><b>${escapeHtml(item.name)}</b></div><div><small>分类</small><b>${escapeHtml(item.category)}</b></div><div><small>生产日期</small><b>${item.manufacture?fmtDate(item.manufacture):'未提供'}</b></div><div><small>保质期限</small><b>${item.shelfLife?`${item.shelfLife}${unitLabel(item.shelfUnit)}`:'未提供'}</b></div><div><small>产品标注到期日</small><b>${fmtDate(item.expiry)}</b></div><div><small>开封后期限</small><b>${item.afterOpeningValue?`${fmtDate(item.openedDate)} 起 ${item.afterOpeningValue}${unitLabel(item.afterOpeningUnit)}`:'未提供'}</b></div><div><small>预计提醒日期</small><b>${fmtDate(getReminderDate(item)||info.date)}</b></div><div><small>数量</small><b>${item.quantity}</b></div></div><div class="ai-record-actions"><button class="ai-cancel" data-ai-cancel="${id}">先不保存</button><button class="ai-confirm" data-ai-confirm="${id}">确认加入物品清单</button></div>`;
  $('chatMessages').appendChild(card);$('chatMessages').scrollTop=$('chatMessages').scrollHeight;
}
function createAiBatchCard(mutation){
  const id=newId();pendingActions.set(id,mutation);
  const rows=mutation.items.map((item,index)=>{
    const info=getExpiryInfo(item);
    return `<div class="ai-batch-row"><span class="ai-batch-index">${index+1}</span><div><b>${escapeHtml(item.name)}</b><small>${escapeHtml(item.category)} · ${fmtDate(info.date)} · ${item.quantity||1} 件</small></div><span class="ai-batch-check">待保存</span></div>`;
  }).join('');
  const card=document.createElement('section');card.className='ai-record-card ai-batch-card';card.dataset.aiAction=id;
  card.innerHTML=`<div class="ai-record-title"><span>✧ 批量物品记录</span><span>${mutation.items.length} 件 · 整批确认</span></div><div class="ai-batch-list">${rows}</div><p class="ai-batch-note">所有物品会一起保存；如果取消，本批次一件也不会写入清单。</p><div class="ai-record-actions"><button class="ai-cancel" data-ai-cancel="${id}">先不保存</button><button class="ai-confirm" data-ai-confirm="${id}">确认保存 ${mutation.items.length} 件</button></div>`;
  $('chatMessages').appendChild(card);$('chatMessages').scrollTop=$('chatMessages').scrollHeight;
}
function createAiQueryCard(resultItems){
  const card=document.createElement('section');card.className='ai-record-card ai-query-card';
  if(!resultItems.length){
    card.innerHTML='<div class="ai-record-title"><span>✧ 清单查询结果</span><span>已核对本机记录</span></div><p class="ai-query-empty">当前清单里没有符合条件的物品。</p>';
  }else{
    const rows=resultItems.map(item=>{
      const info=getExpiryInfo(item),status=statusOf(item);
      return `<div class="ai-batch-row"><span class="ai-query-dot"></span><div><b>${escapeHtml(item.name)}</b><small>${escapeHtml(item.category||'其他')} · 到期 ${fmtDate(info.date)} · ${escapeHtml(item.location||'未设存放位置')}</small></div><span class="ai-query-status status-${status.kind}">${escapeHtml(status.label)} ${escapeHtml(status.count)}</span></div>`;
    }).join('');
    card.innerHTML=`<div class="ai-record-title"><span>✧ 清单查询结果</span><span>${resultItems.length} 件 · 本机核对</span></div><div class="ai-batch-list">${rows}</div>`;
  }
  $('chatMessages').appendChild(card);$('chatMessages').scrollTop=$('chatMessages').scrollHeight;
}
function mutationFieldValue(item,key){
  const unit=u=>u==='days'?'天':u==='years'?'年':'个月';
  if(key==='effectiveExpiry')return fmtDate(getExpiryInfo(item).date);
  if(key==='manufacture'||key==='expiry'||key==='openedDate')return fmtDate(item[key]);
  if(key==='shelfLife')return item.shelfLife?`${item.shelfLife}${unit(item.shelfUnit)}`:'未填写';
  if(key==='afterOpeningValue')return item.afterOpeningValue?`${item.afterOpeningValue}${unit(item.afterOpeningUnit)}`:'未填写';
  if(key==='reminderDays')return Number(item.reminderDays)>0?`提前 ${item.reminderDays} 天`:'关闭';
  if(key==='quantity')return `${item.quantity||1} 件`;
  const value=item[key];return value===null||value===undefined||value===''?'未填写':String(value);
}
function createAiMutationCard(mutation){
  const id=newId();pendingActions.set(id,mutation);
  const deleting=mutation.type==='delete',item=deleting?mutation.before:mutation.item;
  const opening=mutation.intent==='record_opened';
  const heading=deleting?'✧ 确认删除这件物品':opening?'✧ 确认登记开封':'✧ 确认修改物品记录';
  const keys=['name','category','quantity','manufacture','shelfLife','expiry','openedDate','afterOpeningValue','location','reminderDays','note'];
  const labels={name:'物品名称',category:'分类',quantity:'数量',manufacture:'生产日期',shelfLife:'保质期限',expiry:'产品标注到期日',openedDate:'开封日期',afterOpeningValue:'开封后期限',location:'存放位置',reminderDays:'提前提醒',note:'备注'};
  const details=deleting
    ?`将从清单中删除「${escapeHtml(item.name)}」。<small>分类：${escapeHtml(item.category||'其他')} · 当前有效到期日：${fmtDate(getExpiryInfo(item).date)} · 存放位置：${escapeHtml(item.location||'未设置')}</small>`
    :keys.filter(key=>JSON.stringify(mutation.before[key]??'')!==JSON.stringify(item[key]??'')).map(key=>`<div class="ai-mutation-diff-row"><small>${labels[key]}</small><span>${escapeHtml(mutationFieldValue(mutation.before,key))}</span><i>→</i><b>${escapeHtml(mutationFieldValue(item,key))}</b></div>`).join('')||'<small>没有检测到字段变化。</small>';
  const card=document.createElement('section');card.className='ai-record-card ai-mutation-card';card.dataset.aiAction=id;
  card.innerHTML=`<div class="ai-record-title"><span>${heading}</span><span>需要你确认</span></div><div class="ai-mutation-preview">${deleting?details:`<div class="ai-mutation-diff">${details}</div>`}</div><div class="ai-record-actions"><button class="ai-cancel" data-ai-cancel="${id}">取消操作</button><button class="ai-confirm" data-ai-confirm="${id}">${deleting?'确认删除':opening?'确认记录开封':'确认修改'}</button></div>`;
  $('chatMessages').appendChild(card);$('chatMessages').scrollTop=$('chatMessages').scrollHeight;
}
function commitAiItem(id){
  const mutation=pendingActions.get(id);if(!mutation)return;
  const previous=items;
  try{items=applyAiMutation(items,mutation)}catch(error){showToast(error.message||'操作无法完成');return}
  if(!saveItems()){items=previous;return}
  pendingActions.delete(id);
  const card=document.querySelector(`[data-ai-action="${id}"]`);
  if(card){const done=mutation.type==='create_batch'?'已批量保存到我的物品':mutation.type==='create'?'已保存到我的物品':mutation.type==='update'?(mutation.intent==='record_opened'?'开封日期已登记':'物品信息已更新'):'物品已删除';card.innerHTML=`<div class="ai-record-title">✓ ${done}</div>`;card.style.opacity='.75'}
  render();
  if(mutation.type==='create')addMessage('assistant',`已经把「${mutation.item.name}」加入物品清单啦。当前有效到期日是 ${fmtDate(getExpiryInfo(mutation.item).date)}。`);
  if(mutation.type==='create_batch')addMessage('assistant',`已经一次帮你记录 ${mutation.items.length} 件物品，整批保存成功啦。你可以到「我的物品」查看每一件的日期。`);
  if(mutation.type==='update'&&mutation.intent==='record_opened')addMessage('assistant',`已经登记「${mutation.item.name}」的开封日期：${fmtDate(mutation.item.openedDate)}。${mutation.item.afterOpeningValue?`按开封后 ${mutation.item.afterOpeningValue}${mutation.item.afterOpeningUnit==='days'?'天':mutation.item.afterOpeningUnit==='years'?'年':'个月'}，我也会重新计算有效到期日。`:'你还没有提供开封后使用期限；包装上如果有 6M、12M 之类标记，可以再告诉我。'} 当前有效到期日：${fmtDate(getExpiryInfo(mutation.item).date)}。`);
  else if(mutation.type==='update')addMessage('assistant',`已经更新「${mutation.item.name}」的记录，当前有效到期日是 ${fmtDate(getExpiryInfo(mutation.item).date)}。提醒安排也已同步。`);
  if(mutation.type==='delete')addMessage('assistant',`已经从清单中删除「${mutation.before.name}」啦，对应的提醒也会一起取消。`);
  showToast('已按你的确认更新物品清单');
}
function cancelAiItem(id){pendingActions.delete(id);document.querySelector(`[data-ai-action="${id}"]`)?.remove();addMessage('assistant','好的，这项操作已取消，物品清单没有变化。')}

async function sendChat(text){const message=String(text||'').trim();if(!message)return;if(!apiConfig.baseUrl||!apiConfig.model||!effectiveApiKey()){addMessage('user',message);chatHistory.push({role:'user',content:message});addMessage('assistant','我还没有连接你的 AI 服务呢。请先到「主题与 API 设置」填写 API Base URL、模型名称和 API Key，保存后就可以继续聊天和整理记录啦。');goToView('settings');showToast('请先配置拾期小助手 API');return}
  addMessage('user',message);chatHistory.push({role:'user',content:message});$('chatInput').value='';resizeChatInput();$('sendButton').disabled=true;$('sendButton').textContent='…';
  try{const data=await callCompletion(chatHistory.slice(-16));const content=data.choices?.[0]?.message?.content??data.choices?.[0]?.text??'';if(!content)throw new Error('模型没有返回内容，请检查模型名称或接口兼容性。');const envelope=extractEnvelope(content);const reply=String(envelope.reply||'我已经收到你的消息。');chatHistory.push({role:'assistant',content});addMessage('assistant',reply);
    if(envelope.action?.type==='create_item'){
      const item=normalizeAiItem(envelope.action.item||{});
      if(!item){addMessage('assistant','我还不能确定有效到期日，所以暂时没有保存。请补充产品标注到期日，或生产日期+保质期，或开封日期+开封后使用期限。');}
      else if(apiConfig.saveMode==='auto'){const previous=items;items=[...items,item];if(!saveItems()){items=previous;return}render();addMessage('assistant',`已自动记录「${item.name}」，当前有效到期日为 ${fmtDate(getExpiryInfo(item).date)}。`);showToast('已自动保存一条物品记录')}
      else createAiRecordCard(item);
    }else if(envelope.action?.type==='create_items'){
      const prepared=prepareAiBatchCreate(envelope.action.items,items,normalizeAiItem);
      if(!prepared.ok){addMessage('assistant',prepared.reason)}
      else if(apiConfig.saveMode==='auto'){
        const previous=items;
        try{items=applyAiMutation(items,prepared.mutation)}catch(error){items=previous;addMessage('assistant',error.message);return}
        if(!saveItems()){items=previous;return}
        render();addMessage('assistant',`已自动保存 ${prepared.mutation.items.length} 件物品，整批记录成功。`);showToast(`已自动保存 ${prepared.mutation.items.length} 件物品`);
      }else createAiBatchCard(prepared.mutation);
    }else if(envelope.action?.type==='query_items'){
      const query=prepareAiQuery(envelope.action,items);
      if(!query.ok)addMessage('assistant',query.reason);else createAiQueryCard(query.items);
    }else if(envelope.action?.type==='record_opened'||envelope.action?.type==='update_item'||envelope.action?.type==='delete_item'){
      const prepared=prepareAiMutation(envelope.action,items,normalizeAiItem);
      if(!prepared.ok){addMessage('assistant',prepared.reason)}
      else createAiMutationCard(prepared.mutation);
    }
  }catch(err){const safe=String(err.message||'连接失败').replace(/Bearer\s+\S+/gi,'Bearer [隐藏]').slice(0,260);addMessage('assistant',`这次没有成功连接 AI 服务：${safe}\n\n请检查 Base URL、模型名称、API Key 和服务商是否支持 OpenAI Chat Completions 接口。`);showToast('AI 请求未成功')}
  finally{$('sendButton').disabled=false;$('sendButton').textContent='➤'}
}
function updateNotificationStatus(){
  const status=$('notificationStatus'),button=$('requestNotificationPermission');
  if(!status||!button)return;
  if(!window.ShelfieNative?.areNotificationsEnabled){status.textContent='仅网页模式';button.textContent='Android 内可开启通知';button.disabled=true;return}
  const enabled=window.ShelfieNative.areNotificationsEnabled()===true;
  status.textContent=enabled?'已开启':'尚未授权';status.classList.toggle('connected',enabled);
  button.textContent=enabled?'管理系统通知权限':'开启系统通知';button.disabled=false;
  if(enabled&&window.ShelfieNative.refreshReminders)window.ShelfieNative.refreshReminders();
}
window.shelfieNotificationPermissionChanged=(granted)=>{updateNotificationStatus();showToast(granted?'系统通知已开启':'系统通知未开启，你仍可继续使用物品管理')};
window.shelfieRefreshNotificationUi=updateNotificationStatus;
function requestNotificationPermission(){
  if(!window.ShelfieNative?.requestNotificationPermission){showToast('系统通知需要安装 Android 版本后使用');return}
  window.ShelfieNative.requestNotificationPermission();
  setTimeout(updateNotificationStatus,900);
}

function populateApiForm(){if(!apiConfig)return;$('apiBaseUrl').value=apiConfig.baseUrl||'';$('apiModel').value=apiConfig.model||'';$('apiTemperature').value=apiConfig.temperature??0.2;const saved=window.ShelfieNative?.hasSavedApiKey?.()===true;$('saveApiKey').checked=saved||!!apiConfig.saveKey;$('aiSaveMode').value=apiConfig.saveMode||'confirm';$('apiKey').value='';$('apiKey').placeholder=saved?'已通过 Android Keystore 加密保存；留空继续使用，填写可更换':'粘贴你自己的 API Key';updateApiStatus()}
function updateApiStatus(){const ready=!!(apiConfig.baseUrl&&apiConfig.model&&effectiveApiKey());$('apiStatus').textContent=ready?'已配置':'尚未连接';$('apiStatus').classList.toggle('connected',ready);$('apiNudge').hidden=ready}
async function testApi(){
  const base=$('apiBaseUrl').value.trim(),model=$('apiModel').value.trim(),key=$('apiKey').value.trim()||sessionApiKey||'';
  if(!base||!model||!key){showToast('请先填写 Base URL、模型名称和 API Key');return}if(!/^https:\/\//i.test(base)){showToast('为保护 API Key，接口地址必须使用 HTTPS');return}
  const saveMode=$('aiSaveMode').value;apiConfig={...apiConfig,baseUrl:base,model,temperature:Number($('apiTemperature').value)||0.2,saveMode};sessionApiKey=key;
  const btn=$('testApiButton');btn.disabled=true;btn.textContent='正在测试…';
  try{const data=await callCompletion([{role:'user',content:'请只回复：拾期连接成功。'}]);const content=data.choices?.[0]?.message?.content??'';if(!content)throw new Error('接口已响应，但没有返回模型文本。');showToast('连接成功：'+String(content).slice(0,35));updateApiStatus()}
  catch(e){showToast(`连接失败：${String(e.message||'未知错误').slice(0,80)}`)}
  finally{btn.disabled=false;btn.textContent='测试连接'}
}

function resetPhotoScan(){
  selectedPhotoDataUrls=[];selectedPhotoNames=[];photoExtraction=null;photoBarcodes=[];photoProductMatch=null;currentProductLookupResults=[];
  $('productLookupResults').innerHTML='';$('productLookupResults').hidden=true;$('productLookupStatus').hidden=true;$('productSearchQuery').value='';$('photoBarcode').value='';
  ['photoName','photoManufacture','photoExpiry','photoShelfLife','photoOpenedDate','photoPaoValue','photoBatchCode','photoEvidence'].forEach(id=>$(id).value='');
  $('photoCategory').value='其他';$('photoShelfUnit').value='days';$('photoPaoUnit').value='months';
  const grid=$('photoPreviewGrid');if(grid)grid.innerHTML='';
  $('photoPreviewSection').hidden=true;$('photoResultPanel').hidden=true;
  $('photoScanStatus').hidden=true;$('photoScanStatus').textContent='';$('photoScanStatus').classList.remove('error');
  $('photoConsent').checked=false;$('recognizePhotoButton').disabled=true;$('scanPhotoBarcodeButton').disabled=true;
  $('photoBarcode').value='';
  $('photoCameraInput').value='';$('photoGalleryInput').value='';
}
function openPhotoScan(){
  resetPhotoScan();openModal('photoScanModal');
  if(!apiConfig.baseUrl||!apiConfig.model||!effectiveApiKey())setPhotoStatus('先到「设置 → 拾期小助手 API」配置支持图片输入的视觉模型，再开始识别。');
}
function setPhotoStatus(message,isError=false){const el=$('photoScanStatus');el.textContent=message;el.hidden=false;el.classList.toggle('error',isError)}
function readBlobAsDataUrl(blob){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result||''));reader.onerror=()=>reject(new Error('照片读取失败，请重新选择。'));reader.readAsDataURL(blob)})}
async function decodePhotoFile(file){
  if(window.createImageBitmap){try{return await createImageBitmap(file)}catch{}}
  const objectUrl=URL.createObjectURL(file);
  try{return await new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>resolve({width:image.naturalWidth,height:image.naturalHeight,drawSource:image,close:()=>URL.revokeObjectURL(objectUrl)});image.onerror=()=>{URL.revokeObjectURL(objectUrl);reject(new Error('这张图片暂时无法读取。请使用 JPG、PNG 或 WebP 格式。'))};image.src=objectUrl})}
  catch(error){URL.revokeObjectURL(objectUrl);throw error}
}
async function optimizePhoto(file){
  if(!file||!String(file.type||'').startsWith('image/'))throw new Error('请选择图片文件。');
  if(file.size>25*1024*1024)throw new Error('照片原文件超过 25 MB，请先压缩或重新拍摄。');
  const source=await decodePhotoFile(file);
  try{
    const width=source.width||source.naturalWidth,height=source.height||source.naturalHeight;
    if(!width||!height)throw new Error('无法读取照片尺寸，请重新选择 JPG 或 PNG 图片。');
    const scale=Math.min(1,1440/Math.max(width,height));
    const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(width*scale));canvas.height=Math.max(1,Math.round(height*scale));
    const ctx=canvas.getContext('2d',{alpha:false});if(!ctx)throw new Error('当前设备无法处理图片，请重试。');
    ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(source.drawSource||source,0,0,canvas.width,canvas.height);
    let blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',0.82));
    if(!blob)throw new Error('照片压缩失败，请重新选择。');
    if(blob.size>1_600_000){
      const reduced=document.createElement('canvas');reduced.width=Math.max(1,Math.round(canvas.width*0.82));reduced.height=Math.max(1,Math.round(canvas.height*0.82));
      const reducedCtx=reduced.getContext('2d',{alpha:false});reducedCtx.fillStyle='#fff';reducedCtx.fillRect(0,0,reduced.width,reduced.height);reducedCtx.drawImage(canvas,0,0,reduced.width,reduced.height);
      blob=await new Promise(resolve=>reduced.toBlob(resolve,'image/jpeg',0.72));
    }
    if(blob.size>1_800_000)throw new Error('压缩后的照片仍然太大，请重新拍摄或裁剪。');
    return await readBlobAsDataUrl(blob);
  }finally{source.close?.()}
}
function renderPhotoPreviews(){
  const grid=$('photoPreviewGrid');
  grid.innerHTML=selectedPhotoDataUrls.map((url,index)=>`<div class="photo-preview-card"><img src="${url}" alt="包装照片 ${index+1}" /><div><small>${index+1}. ${escapeHtml(selectedPhotoNames[index]||'包装照片')}</small><button type="button" class="photo-remove-button" data-photo-remove="${index}" aria-label="移除第 ${index+1} 张照片">移除</button></div></div>`).join('');
  $('photoPreviewSection').hidden=selectedPhotoDataUrls.length===0;
  $('photoFileCaption').textContent=`已选择 ${selectedPhotoDataUrls.length}/3 张 · 图片仅临时保存在当前识别流程中`;
  $('scanPhotoBarcodeButton').disabled=selectedPhotoDataUrls.length===0;
  $('recognizePhotoButton').disabled=selectedPhotoDataUrls.length===0||!$('photoConsent').checked;
}
async function handlePhotoFiles(files){
  const inputFiles=Array.from(files||[]).filter(Boolean);
  if(!inputFiles.length)return;
  const available=3-selectedPhotoDataUrls.length;
  if(available<=0){setPhotoStatus('最多选择 3 张照片。移除不需要的照片后再添加。',true);return}
  const toProcess=inputFiles.slice(0,available);
  if(inputFiles.length>available)setPhotoStatus('最多支持 3 张照片，已只处理本次可添加的前几张。');
  for(const file of toProcess){
    try{
      setPhotoStatus(`正在压缩第 ${selectedPhotoDataUrls.length+1} 张照片……`);
      const dataUrl=await optimizePhoto(file);
      selectedPhotoDataUrls.push(dataUrl);selectedPhotoNames.push(file.name||`包装照片 ${selectedPhotoNames.length+1}`);
    }catch(error){setPhotoStatus(error.message||'照片读取失败。',true)}
  }
  if(toProcess.length){photoBarcodes=[];$('photoBarcode').value=''}
  renderPhotoPreviews();
  photoExtraction=null;$('photoResultPanel').hidden=true;$('photoConsent').checked=false;
  $('recognizePhotoButton').disabled=true;
  if(selectedPhotoDataUrls.length)setPhotoStatus(`已准备 ${selectedPhotoDataUrls.length} 张照片。建议分别拍商品正面、日期标签和瓶底/开盖标志；勾选授权后统一识别。`);
}
function callVisionCompletion(imageDataUrls, barcodeValues=[]){
  const prompt=`你是包装标签文字识别器。现在提供 ${imageDataUrls.length} 张同一商品的不同角度照片，依次为照片 1 至照片 ${imageDataUrls.length}，可能分别是正面、背面标签、底部喷码或开盖标志。请联合比对所有照片，只读取实际清晰可见的信息，不推测、不补全、不使用常识猜测。不同照片出现冲突时，相关日期/期限字段留空，并在 warnings 中逐项说明；不要自行选择一个日期。\n\n辅助条码（仅供记录，不代表条码数据库查询结果）：${barcodeValues.length?barcodeValues.join('；'):'未扫描'}。条码通常不能证明生产日期、到期日期或保质期，严禁从数字猜日期。\n\n请只输出一个 JSON 对象，不要 Markdown，结构为 {"merged":{字段结构见下方},"perPhoto":[每张照片各自的识别对象，顺序必须与输入照片一致]}。merged 和 perPhoto 每个对象都必须包含这些字段：{"name":"商品名称或空字符串","category":"食品饮料|护肤美妆|药品保健|日用百货|其他","manufactureDate":"完整 YYYY-MM-DD 或空字符串","expiryDate":"完整 YYYY-MM-DD 或空字符串","shelfLifeValue":数字或null,"shelfLifeUnit":"days|months|years","paoValue":数字或null,"paoUnit":"days|months|years","manufactureText":"包装上生产日期原文或空字符串","expiryText":"包装上到期/有效期原文或空字符串","batchCode":"批号/LOT 原文或空字符串","dateEvidence":"日期附近可见的关键原文","visibleText":["最多24条清晰可见文字"],"fieldConfidence":{"name":"high|medium|low|unreadable","manufactureDate":"high|medium|low|unreadable","expiryDate":"high|medium|low|unreadable","shelfLife":"high|medium|low|unreadable","pao":"high|medium|low|unreadable"},"conflicts":["存在冲突的字段名"],"warnings":["需要用户核对的事项"]}。\n\n规则：1. 只有完整且能确定年月日的日期才填写 manufactureDate/expiryDate，必须使用 YYYY-MM-DD；若只看到年月、批号或模糊喷码，日期字段留空，原文放进对应 Text 字段。2. 严格区分 MFG/生产日期、EXP/有效期/Best before、保质期时长、开封后使用期限 PAO（开盖小罐图标 6M/12M）；不要把批号当日期。3. 只有包装文字明确写明时才填 shelfLifeValue 或 paoValue；不要自行换算或推断。4. 如果多张照片日期不一致，merged 冲突字段必须留空并标记；不能把多张图读到的不同日期简单挑一个。5. 不要将今天日期当成生产或开封日期。6. 如果照片没有拍到标签，日期字段留空，并说明建议补拍包装背面、底部喷码或开盖标志。7. 识别结果只是待核对草稿，禁止声称已经保存。`;
  const content=[{type:'text',text:prompt},...imageDataUrls.map(url=>({type:'image_url',image_url:{url,detail:'high'}}))];
  return requestApiBody({model:apiConfig.model,temperature:0.1,max_tokens:2400,messages:[{role:'system',content:'你负责读取商品包装照片。严守可见证据；联合多图识别；冲突必须报告；不得猜日期或推断商品信息。输出严格 JSON。'},{role:'user',content}]});
}
window.ShelfieNativeResult=(id,status,response)=>{const p=window.__shelfiePending?.[id];if(!p)return;delete window.__shelfiePending[id];try{const data=JSON.parse(response||'{}');if(status>=200&&status<300)p.resolve(data);else p.reject(new Error(data.error?.message||`API 请求失败（HTTP ${status}）`))}catch(e){p.reject(e)}};
window.ShelfieBarcodeResult=(id,success,response)=>{const p=window.__shelfieBarcodePending?.[id];if(!p)return;delete window.__shelfieBarcodePending[id];try{const data=JSON.parse(response||'{}');if(success)p.resolve(data);else p.reject(new Error(data.error||'条码识别失败，请换个角度重试。'))}catch(e){p.reject(e)}};
window.ShelfieProductLookupResult=(id,status,response)=>{const p=window.__shelfieProductLookupPending?.[id];if(!p)return;delete window.__shelfieProductLookupPending[id];try{p.resolve({httpStatus:Number(status)||0,data:JSON.parse(response||'{}')})}catch(e){p.reject(new Error('商品数据库返回内容无法解析。'))}};
function requestPublicProductJson(url,signal){
  if(window.ShelfieNative?.getProductJson){
    return new Promise((resolve,reject)=>{const id=`product-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;window.__shelfieProductLookupPending=window.__shelfieProductLookupPending||{};window.__shelfieProductLookupPending[id]={resolve:value=>{if(value.httpStatus===599||value.httpStatus===429||value.httpStatus>=500)reject(new Error(value.data?.error||`商品数据库暂时不可用（HTTP ${value.httpStatus}）`));else resolve(value)},reject};window.ShelfieNative.getProductJson(id,url)});
  }
  return fetch(url,{headers:{Accept:'application/json'},signal}).then(async response=>{const data=await response.json().catch(()=>({}));if(response.status>=500||response.status===429)throw new Error(`商品数据库暂时不可用（HTTP ${response.status}）`);return {httpStatus:response.status,data}});
}
function setProductLookupStatus(message,isError=false){const el=$('productLookupStatus');el.textContent=message;el.hidden=false;el.classList.toggle('error',isError)}
function productFallbackName(){const query=$('productSearchQuery').value.trim();return query.length>=2?query:''}
function renderProductLookupResults(products){
  currentProductLookupResults=Array.isArray(products)?products.slice(0,16):[];
  const root=$('productLookupResults');
  root.innerHTML=currentProductLookupResults.map((product,index)=>{
    const image=product.image&&/^https:\/\//i.test(product.image)?`<img src="${escapeHtml(product.image)}" alt="" loading="lazy" referrerpolicy="no-referrer" />`:'<span class="product-lookup-placeholder" aria-hidden="true">✧</span>';
    const details=[product.brand,product.quantity,product.source].filter(Boolean).map(escapeHtml).join(' · ');
    return `<article class="product-lookup-card">${image}<div class="product-lookup-info"><b>${escapeHtml(product.name)}</b><small>${details||'公开商品目录资料'}${product.code?` · ${escapeHtml(product.code)}`:''}</small></div><button type="button" class="secondary-button" data-product-select="${index}">选用</button></article>`;
  }).join('');
  root.hidden=currentProductLookupResults.length===0;
}
function selectProductMatch(index){
  const product=currentProductLookupResults[index];if(!product)return;
  photoProductMatch=product;
  $('photoName').value=product.name;$('photoCategory').value=product.category||'其他';
  if(product.code)$('photoBarcode').value=product.code;
  const summary=[product.brand?`品牌：${product.brand}`:'',product.quantity?`规格：${product.quantity}`:'',product.source?`商品资料来源：${product.source}`:''].filter(Boolean).join('；');
  setProductLookupStatus(`已选用「${product.name}」。${summary?`${summary}。`:''}公开资料仅供参考，确认后才会写入记录；保质期和日期仍需读取包装。`);
  if($('photoResultPanel').hidden)$('photoResultPanel').hidden=false;
  updatePhotoDateBasis();
  $('photoName').focus();
}
async function runBarcodeProductLookup(){
  const raw=$('photoBarcode').value.trim()||photoBarcodes[0]?.rawValue||'';
  const code=normalizeBarcodeCode(raw);
  if(!code){setProductLookupStatus('请输入或先读取一个 8–14 位数字商品条码。',true);return}
  const button=$('lookupBarcodeButton');button.disabled=true;button.textContent='查询中…';$('productLookupResults').hidden=true;
  setProductLookupStatus('正在查询主商品目录；若没有记录，会继续尝试食品、美妆、宠物食品和日用品目录……');
  try{
    const result=await lookupBarcode(code,{request:requestPublicProductJson,timeoutMs:12000});
    if(result.status==='found'){
      renderProductLookupResults(result.products);
      setProductLookupStatus(`${result.message} 请根据品牌、规格和图片确认是否为同一商品。`);
    }else{
      renderProductLookupResults([]);setProductLookupStatus(result.message,result.status==='error'||result.status==='invalid');
    }
  }catch(error){setProductLookupStatus(error.message||'商品查询失败，请稍后重试。',true)}
  finally{button.disabled=false;button.textContent='查条码资料'}
}
async function runProductNameSearch(){
  const query=$('productSearchQuery').value.trim();
  if(query.length<2){setProductLookupStatus('至少输入 2 个字符再搜索。',true);return}
  const button=$('searchProductButton');button.disabled=true;button.textContent='搜索中…';$('productLookupResults').hidden=true;
  setProductLookupStatus('正在按商品名称搜索公开目录。此操作由你手动触发，不会在输入时自动请求。');
  try{
    const result=await searchProducts(query,{request:requestPublicProductJson,timeoutMs:15000});
    if(result.status==='found'){
      renderProductLookupResults(result.products);
      setProductLookupStatus(`${result.message} 结果来自公开目录，名称相似不代表规格相同，请检查后选用。`);
    }else{
      renderProductLookupResults([]);setProductLookupStatus(result.message,result.status==='error'||result.status==='invalid');
      if(result.status==='not-found'){
        const root=$('productLookupResults');root.innerHTML='<button type="button" class="secondary-button" id="useSearchNameButton">用这个名称建立待识别草稿</button>';root.hidden=false;
      }
    }
  }catch(error){setProductLookupStatus(error.message||'名称搜索失败，请稍后重试。',true)}
  finally{button.disabled=false;button.textContent='搜名称'}
}
function useSearchNameAsDraft(){
  const name=$('productSearchQuery').value.trim();if(name.length<2)return;
  $('photoName').value=name;$('photoCategory').value='其他';photoProductMatch=null;
  $('photoResultPanel').hidden=false;setProductLookupStatus(`已将「${name}」作为手动草稿名称。仍需拍照/填写包装日期，核对后才能保存有效期记录。`);
}
function scanOnePhotoBarcode(dataUrl){
  if(window.ShelfieNative?.scanBarcodes){
    return new Promise((resolve,reject)=>{const id=`barcode-${Date.now()}-${Math.random().toString(36).slice(2,7)}`;window.__shelfieBarcodePending=window.__shelfieBarcodePending||{};window.__shelfieBarcodePending[id]={resolve,reject};window.ShelfieNative.scanBarcodes(id,dataUrl)});
  }
  if(!('BarcodeDetector' in window))return Promise.reject(new Error('当前浏览器没有本地条码识别能力；请在 Android 安装版中使用此功能。'));
  return (async()=>{const blob=await fetch(dataUrl).then(r=>r.blob());const bitmap=await createImageBitmap(blob);try{const detector=new BarcodeDetector({formats:['ean_13','ean_8','upc_a','upc_e','code_128','code_39','qr_code','data_matrix']});const found=await detector.detect(bitmap);return {barcodes:found.map(item=>({rawValue:item.rawValue,format:item.format}))}}finally{bitmap.close?.()}})();
}
async function scanBarcodesFromPhotos(){
  if(!selectedPhotoDataUrls.length)return;
  const button=$('scanPhotoBarcodeButton');button.disabled=true;button.textContent='正在本机识别…';
  try{
    const all=[];
    for(const photo of selectedPhotoDataUrls){const result=await scanOnePhotoBarcode(photo);if(Array.isArray(result.barcodes))all.push(...result.barcodes)}
    photoBarcodes=normalizeBarcodeResults(all);
    $('photoBarcode').value=photoBarcodes.map(item=>item.rawValue).join('；');
    if(photoBarcodes.length){setPhotoStatus(`已在本机识别到 ${photoBarcodes.length} 个条码。点击「查条码资料」尝试查询商品目录；条码本身不能证明保质期。`);$('photoBarcode').value=photoBarcodes[0].rawValue;}
    else setPhotoStatus('未在这些照片中识别到条码。可以试着让条码充满画面、减少反光后重新拍摄。',true);
  }catch(error){setPhotoStatus(error.message||'条码读取失败。',true)}
  finally{button.disabled=selectedPhotoDataUrls.length===0;button.textContent='⌗ 读取照片中的条码'}
}
function parsePhotoJson(content){
  let raw=String(content||'').trim().replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'');
  const first=raw.indexOf('{'),last=raw.lastIndexOf('}');
  if(first<0||last<=first)throw new Error('模型没有返回可读取的结构化结果。请确认所选模型支持图片输入，并重试。');
  try{return JSON.parse(raw.slice(first,last+1))}catch{throw new Error('模型返回内容不是有效 JSON。请重试，或换用支持视觉识别的模型。')}
}
function photoResponseContent(data){const content=data?.choices?.[0]?.message?.content??data?.choices?.[0]?.text??'';if(Array.isArray(content))return content.map(part=>typeof part==='string'?part:part?.text||'').join('\n');return String(content||'')}
async function recognizePackagePhoto(){
  if(!selectedPhotoDataUrls.length){showToast('请先拍摄或选择包装照片');return}
  if(!$('photoConsent').checked){showToast('请先勾选照片发送授权');return}
  if(!apiConfig.baseUrl||!apiConfig.model||!effectiveApiKey()){setPhotoStatus('尚未配置 AI API。请先设置支持图片输入的视觉模型。',true);return}
  const button=$('recognizePhotoButton');button.disabled=true;button.textContent='正在识别…';$('photoResultPanel').hidden=true;setPhotoStatus(`正在把 ${selectedPhotoDataUrls.length} 张压缩照片一起发送给你配置的 AI 服务商。识别期间请保持页面打开……`);
  try{
    const response=await callVisionCompletion(selectedPhotoDataUrls,$('photoBarcode').value.split(/[；;,\s]+/).filter(Boolean).slice(0,10));
    const raw=parsePhotoJson(photoResponseContent(response));
    photoExtraction=Array.isArray(raw.perPhoto)&&raw.perPhoto.length?mergePhotoExtractions(raw.perPhoto):normalizePhotoExtraction(raw.merged||raw);
    if(raw.merged&&Array.isArray(raw.merged.warnings))photoExtraction.warnings=[...new Set([...photoExtraction.warnings,...normalizePhotoExtraction(raw.merged).warnings])].slice(0,12);
    if(raw.merged&&Array.isArray(raw.merged.conflicts))photoExtraction.conflicts=[...new Set([...(photoExtraction.conflicts||[]),...normalizePhotoExtraction(raw.merged).conflicts])].slice(0,8);
    if(Array.isArray(raw.perPhoto)&&raw.perPhoto.length!==selectedPhotoDataUrls.length)photoExtraction.warnings.push('模型返回的逐张照片结果数量与已选照片数量不同，请重点核对联合识别结果。');
    renderPhotoExtraction(photoExtraction);
    const conflictCount=(photoExtraction.conflicts||[]).length;const conflicts=conflictCount?` 合并时发现 ${conflictCount} 项需核对的冲突。`:'';
    setPhotoStatus(`多图识别完成。请逐项对照原包装核对。${conflicts}日期不清楚时请手动补充；确认前不会写入物品清单。`);
  }catch(error){const message=String(error.message||'图片识别失败').replace(/Bearer\s+\S+/gi,'Bearer [隐藏]').slice(0,260);setPhotoStatus(`${message}\n\n如果普通聊天可用但图片识别失败，请确认模型确实支持视觉输入，并检查服务商的多模态接口格式。`,true)}
  finally{button.disabled=selectedPhotoDataUrls.length===0||!$('photoConsent').checked;button.textContent='✧ 重新识别包装信息'}
}
function renderPhotoExtraction(result){
  if(photoProductMatch&&result.name&&result.name.trim().toLowerCase()!==String(photoProductMatch.name||'').trim().toLowerCase())photoProductMatch=null;
  $('photoName').value=result.name;$('photoCategory').value=result.category;
  $('photoManufacture').value=result.manufacture;$('photoExpiry').value=result.expiry;
  $('photoShelfLife').value=result.shelfLife??'';$('photoShelfUnit').value=result.shelfUnit;
  $('photoPaoValue').value=result.afterOpeningValue??'';$('photoPaoUnit').value=result.afterOpeningUnit;
  $('photoOpenedDate').value='';$('photoBatchCode').value=result.batchCode;
  const visible=[...result.visibleText];if(result.manufactureText)visible.unshift(`生产日期原文：${result.manufactureText}`);if(result.expiryText)visible.unshift(`到期日期原文：${result.expiryText}`);
  $('photoEvidence').value=[result.evidence,visible.join('；')].filter(Boolean).join('。').slice(0,260);
  const labels={name:'名称',manufacture:'生产日期',expiry:'到期日期',shelfLife:'保质期',pao:'开封后期限'};
  const confidenceLabels={high:'清晰',medium:'较清晰',low:'需核对',unreadable:'未识别'};
  $('photoConfidence').innerHTML=Object.entries(result.fieldConfidence).map(([key,value])=>`<span class="confidence-${value}">${labels[key]||key}：${confidenceLabels[value]}</span>`).join('');
  const warnings=[...result.warnings];
  if(result.manufactureText&&!result.manufacture)warnings.push(`生产日期原文「${result.manufactureText}」未确认为完整日期，请核对。`);
  if(result.expiryText&&!result.expiry)warnings.push(`到期日期原文「${result.expiryText}」未确认为完整日期，请核对。`);
  if(!result.name)warnings.push('未可靠识别商品名称，请手动填写。');
  $('photoWarnings').innerHTML=warnings.length?warnings.map(value=>`<div>${escapeHtml(value)}</div>`).join(''):'';$('photoWarnings').hidden=!warnings.length;
  $('photoResultPanel').hidden=false;updatePhotoDateBasis();updatePhotoMissingGuidance();
}
function currentPhotoDraft(){return {manufacture:$('photoManufacture').value,expiry:$('photoExpiry').value,shelfLife:$('photoShelfLife').value?Number($('photoShelfLife').value):null,shelfUnit:$('photoShelfUnit').value,openedDate:$('photoOpenedDate').value,afterOpeningValue:$('photoPaoValue').value?Number($('photoPaoValue').value):null,afterOpeningUnit:$('photoPaoUnit').value}}
function updatePhotoDateBasis(){const draft=currentPhotoDraft();$('photoDateBasis').textContent=photoDateBasisLabel(draft,draft.openedDate);const ready=hasPhotoExpiryBasis(draft,draft.openedDate);$('photoDateBasis').dataset.ready=ready?'true':'false';updatePhotoMissingGuidance()}
function updatePhotoMissingGuidance(){
  const requirements=photoMissingRequirements(currentPhotoDraft(),$('photoOpenedDate').value);
  const target=$('photoMissingGuidance');
  if(!requirements.length){target.textContent='日期依据已具备，请核对包装原文及日期后保存。';target.classList.remove('needs-info');return}
  target.textContent=`还需要确认：${requirements.join('；')}。拾期不会替你猜日期。`;
  target.classList.add('needs-info');
}
function askPhotoAssistantForMissingInfo(){
  const draft=currentPhotoDraft(),requirements=photoMissingRequirements(draft,draft.openedDate);
  const summary=[`商品名称：${$('photoName').value.trim()||'尚未识别'}`,`生产日期：${draft.manufacture||$('photoEvidence').value}`,`到期日期：${draft.expiry||$('photoEvidence').value}`,`包装保质期：${draft.shelfLife?`${draft.shelfLife}${draft.shelfUnit}`:'未识别'}`,`开封后期限：${draft.afterOpeningValue?`${draft.afterOpeningValue}${draft.afterOpeningUnit}`:'未识别'}`,`开封日期：${draft.openedDate||'未填写'}`,`包装可见文字：${$('photoEvidence').value.trim()||'无'}`,`待确认信息：${requirements.join('；')||'请复核日期依据'}`].join('\n');
  const prompt=`我正在通过包装照片登记一件物品，当前识别草稿如下：\n${summary}\n请帮我用温和、简明的方式指出我应该从包装上核对哪些内容，并一次只问最关键的 1–2 个问题。绝对不要猜测或补全任何日期、保质期，也不要创建、修改或保存物品记录；等我明确提供信息后再整理。`;
  closeModal('photoScanModal');goToView('assistant');sendChat(prompt);
}
function savePhotoRecord(){
  const draft=currentPhotoDraft(),name=$('photoName').value.trim();
  if(!name){showToast('请填写或核对物品名称');return}
  if(!hasPhotoExpiryBasis(draft,draft.openedDate)){showToast('日期依据不足：请补充完整到期日、生产日期+保质期，或开封日期+PAO。');updatePhotoDateBasis();return}
  if(draft.expiry&&draft.manufacture&&draft.expiry<draft.manufacture){showToast('到期日期早于生产日期，请先核对包装');return}
  const evidence=$('photoEvidence').value.trim();const batch=$('photoBatchCode').value.trim();const barcode=$('photoBarcode').value.trim();
  const product=photoProductMatch;
  const note=[batch?`包装批号：${batch}`:'',barcode?`商品条码：${barcode}`:'',product?.brand?`品牌（待核对）：${product.brand}`:'',product?.quantity?`包装规格（待核对）：${product.quantity}`:'',product?.source?`商品资料来源：${product.source}`:'',evidence?`包装文字：${evidence}`:'','商品名称与有效期依据经用户核对'].filter(Boolean).join('；').slice(0,360);
  const item=normalizeAiItem({name,category:$('photoCategory').value,quantity:1,manufacture:draft.manufacture,shelfLife:draft.shelfLife,shelfUnit:draft.shelfUnit,expiry:draft.expiry,openedDate:draft.openedDate,afterOpeningValue:draft.afterOpeningValue,afterOpeningUnit:draft.afterOpeningUnit,location:'',note,reminderDays:7,source:'photo-scan'});
  if(!item){showToast('当前日期信息无法形成有效到期日，请再核对日期字段');return}
  const previous=items;items=[...items,item];
  if(!saveItems()){items=previous;return}
  closeModal('photoScanModal');render();addMessage('assistant',`已将你核对的「${item.name}」加入清单。当前有效到期日：${fmtDate(getExpiryInfo(item).date)}。`);showToast('已确认保存照片识别记录');
}
function wirePhotoRecognition(){
  $('openPhotoScanButton').onclick=openPhotoScan;
  $('photoCameraButton').onclick=()=>$('photoCameraInput').click();
  $('photoGalleryButton').onclick=()=>$('photoGalleryInput').click();
  $('photoCameraInput').addEventListener('change',e=>{handlePhotoFiles(e.target.files);e.target.value=''});
  $('photoGalleryInput').addEventListener('change',e=>{handlePhotoFiles(e.target.files);e.target.value=''});
  $('photoPreviewGrid').addEventListener('click',e=>{const remove=e.target.closest('[data-photo-remove]');if(!remove)return;const index=Number(remove.dataset.photoRemove);selectedPhotoDataUrls.splice(index,1);selectedPhotoNames.splice(index,1);photoExtraction=null;photoBarcodes=[];$('photoBarcode').value='';$('photoResultPanel').hidden=true;$('photoConsent').checked=false;renderPhotoPreviews();setPhotoStatus('已移除照片。条码信息已清空，请对剩余照片重新读取并授权识别。')});
  $('photoConsent').addEventListener('change',e=>{$('recognizePhotoButton').disabled=!selectedPhotoDataUrls.length||!e.target.checked});
  $('recognizePhotoButton').onclick=recognizePackagePhoto;
  $('scanPhotoBarcodeButton').onclick=scanBarcodesFromPhotos;
  $('lookupBarcodeButton').onclick=runBarcodeProductLookup;
  $('searchProductButton').onclick=runProductNameSearch;
  $('productSearchQuery').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();runProductNameSearch()}});
  $('productLookupResults').addEventListener('click',e=>{const pick=e.target.closest('[data-product-select]');if(pick){selectProductMatch(Number(pick.dataset.productSelect));return}if(e.target.closest('#useSearchNameButton'))useSearchNameAsDraft()});
  $('photoBarcode').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();runBarcodeProductLookup()}});
  $('photoAskAssistantButton').onclick=askPhotoAssistantForMissingInfo;
  $('photoRetakeButton').onclick=()=>{resetPhotoScan();$('photoCameraInput').click()};
  $('savePhotoRecordButton').onclick=savePhotoRecord;
  $('photoName').addEventListener('input',()=>{if(photoProductMatch&&$('photoName').value.trim().toLowerCase()!==String(photoProductMatch.name||'').trim().toLowerCase())photoProductMatch=null});
  ['photoName','photoManufacture','photoExpiry','photoShelfLife','photoShelfUnit','photoOpenedDate','photoPaoValue','photoPaoUnit'].forEach(id=>$(id).addEventListener('input',updatePhotoDateBasis));
}

// Date calculation: manual printed expiry takes precedence; after-opening expiry is compared separately.
$('manufactureDate').addEventListener('change',()=>{expiryWasManuallyEdited=false;updateCalculatedExpiry()});
$('shelfLife').addEventListener('input',()=>{expiryWasManuallyEdited=false;updateCalculatedExpiry()});
$('shelfUnit').addEventListener('change',()=>{expiryWasManuallyEdited=false;updateCalculatedExpiry()});
$('expiryDate').addEventListener('change',()=>{expiryWasManuallyEdited=true;updateCalculatedExpiry()});
['openedDate','afterOpeningValue','afterOpeningUnit'].forEach(id=>$(id).addEventListener('change',updateCalculatedExpiry));
function updateCalculatedExpiry(){
  const exp=addShelfLife($('manufactureDate').value,$('shelfLife').value,$('shelfUnit').value);
  if(exp&&!expiryWasManuallyEdited){$('expiryDate').value=exp;}
  const preview={expiry:$('expiryDate').value,openedDate:$('openedDate').value,afterOpeningValue:$('afterOpeningValue').value,afterOpeningUnit:$('afterOpeningUnit').value};
  const info=getExpiryInfo(preview);
  if(info.date){$('calculatedHint').textContent=info.basis==='after-opening'?`按开封后期限计算，当前有效到期日：${fmtDate(info.date)}。若产品标注日期更早，会以更早日期为准。`:`当前有效到期日：${fmtDate(info.date)}。${info.afterOpeningExpiry?'开封后期限也已纳入比较。':'仍可补充开封后期限。'}`;}
  else {$('calculatedHint').textContent='填写产品标注到期日，或生产日期+保质期；也可以填写开封日期+开封后期限。';}
}
$('itemForm').addEventListener('submit',e=>{
  e.preventDefault();
  const name=$('itemName').value.trim();
  const id=$('editingId').value||newId();
  const existing=items.find(x=>x.id===id);
  const item={id,name,category:$('itemCategory').value,quantity:Math.max(1,Math.min(999,Number($('itemQuantity').value)||1)),manufacture:$('manufactureDate').value,shelfLife:$('shelfLife').value?Number($('shelfLife').value):null,shelfUnit:$('shelfUnit').value,expiry:$('expiryDate').value,openedDate:$('openedDate').value,afterOpeningValue:$('afterOpeningValue').value?Number($('afterOpeningValue').value):null,afterOpeningUnit:$('afterOpeningUnit').value,location:$('itemLocation').value.trim(),reminderDays:Number($('reminderDays').value),note:$('itemNote').value.trim(),createdAt:existing?.createdAt||new Date().toISOString()};
  if(!name){showToast('请填写物品名称');return;}
  if(!isValidExpiryRecord(item)){showToast('请填写产品标注到期日、生产日期+保质期，或开封日期+开封后期限');return;}
  const previous=items;
  if(existing)items=items.map(x=>x.id===id?item:x);else items=[...items,item];
  if(!saveItems()){items=previous;return;}
  closeModal('itemModal');render();showToast(existing?'记录已更新':'已加入你的物品清单');
});
// UI wiring
$('topAddButton').onclick=startAdd;$('composerAdd').onclick=startAdd;$('addItemButton').onclick=startAdd;$('emptyAddButton').onclick=startAdd;$('topSettingsButton').onclick=()=>goToView('settings');$('openApiFromChat').onclick=()=>goToView('settings');
wirePhotoRecognition();
$('chatForm').addEventListener('submit',e=>{e.preventDefault();sendChat($('chatInput').value)});
$('chatInput').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('chatForm').requestSubmit()}});
$('chatInput').addEventListener('input',resizeChatInput);
function resizeChatInput(){const el=$('chatInput');el.style.height='auto';el.style.height=Math.min(el.scrollHeight,100)+'px'}
$('quickPrompts').addEventListener('click',e=>{const b=e.target.closest('[data-prompt]');if(b)sendChat(b.dataset.prompt)});
$('chatMessages').addEventListener('click',e=>{const yes=e.target.closest('[data-ai-confirm]'),no=e.target.closest('[data-ai-cancel]');if(yes)commitAiItem(yes.dataset.aiConfirm);if(no)cancelAiItem(no.dataset.aiCancel)});
$('clearChat').onclick=()=>{chatHistory=[];$('chatMessages').innerHTML='';addMessage('assistant','对话已经清空啦。你可以告诉我想记录的物品，也可以问我哪些东西快到期了。')};
$('apiForm').addEventListener('submit',e=>{e.preventDefault();if(!$('apiBaseUrl').value.trim()||!$('apiModel').value.trim()||!$('apiKey').value.trim()&&!sessionApiKey){showToast('请填写 Base URL、模型名称和 API Key');return}saveApiConfig()});
$('testApiButton').onclick=testApi;$('requestNotificationPermission').onclick=requestNotificationPermission;
$('reminderManager').addEventListener('change',e=>{const select=e.target.closest('[data-reminder-days]');if(select)updateReminderDays(select.dataset.reminderDays,select.value)});
$('refreshReminderSchedule').onclick=()=>{if(!window.ShelfieNative?.refreshReminders){showToast('重新同步系统提醒需要 Android 安装版');return}window.ShelfieNative.refreshReminders();showToast('已请求重新同步全部物品提醒')};
$('searchInput').addEventListener('input',e=>{searchQuery=e.target.value;renderInventory()});
document.querySelectorAll('.chip').forEach(c=>c.addEventListener('click',()=>setFilter(c.dataset.filter)));
document.querySelectorAll('.stat-card').forEach(c=>c.addEventListener('click',()=>{setFilter(c.dataset.filter);goToView('inventory')}));
$('filterButton').onclick=()=>showToast('请使用“全部、7 天内、30 天内、已过期”标签筛选。');
$('calendarPrevMonth').onclick=()=>{calendarMonth=new Date(calendarMonth.getFullYear(),calendarMonth.getMonth()-1,1,12);selectedCalendarDate=localDate(calendarMonth);renderCalendar()};
$('calendarNextMonth').onclick=()=>{calendarMonth=new Date(calendarMonth.getFullYear(),calendarMonth.getMonth()+1,1,12);selectedCalendarDate=localDate(calendarMonth);renderCalendar()};
$('calendarTodayButton').onclick=()=>{calendarMonth=new Date(new Date().getFullYear(),new Date().getMonth(),1,12);selectedCalendarDate=localDate(new Date());renderCalendar()};
$('calendarGrid').addEventListener('click',e=>{const day=e.target.closest('[data-calendar-date]');if(day){selectedCalendarDate=day.dataset.calendarDate;renderCalendar()}});
document.querySelectorAll('[data-nav]').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();goToView(b.dataset.nav)}));
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>closeModal(b.dataset.close)));
document.querySelectorAll('.modal-backdrop').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)closeModal(m.id)}));
document.querySelectorAll('[data-theme-choice]').forEach(b=>b.addEventListener('click',()=>{applyTheme(b.dataset.themeChoice);showToast('主题已切换')}));
document.querySelectorAll('[data-open-item]').forEach(el=>el.addEventListener('click',()=>showDetails(el.dataset.openItem)));
$('inventoryList').addEventListener('click',e=>{const card=e.target.closest('[data-open-item]');if(card)showDetails(card.dataset.openItem)});
$('calendarUpcoming').addEventListener('click',e=>{const card=e.target.closest('[data-open-item]');if(card)showDetails(card.dataset.openItem)});
$('calendarSelected').addEventListener('click',e=>{const card=e.target.closest('[data-open-item]');if(card)showDetails(card.dataset.openItem)});
document.querySelectorAll('.view').forEach(v=>v.addEventListener('click',e=>{const b=e.target.closest('[data-nav]');if(b)goToView(b.dataset.nav)}));
$('exportBackup').onclick=exportData;$('importBackupButton').onclick=()=>$('importBackupFile').click();$('importBackupFile').addEventListener('change',e=>{const f=e.target.files?.[0];if(f)importData(f);e.target.value=''});
$('cancelImportButton').onclick=cancelImport;$('confirmImportButton').onclick=confirmImport;

$('todayLabel')?.textContent;applyTheme(localStorage.getItem(THEME_KEY)||'rose');populateApiForm();render();goToView('assistant');
if('serviceWorker' in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
