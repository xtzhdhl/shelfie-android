# 拾期 SHELFIE Android 工程（V1.1）

这是可由 Android Studio 打开的原生 Android WebView 工程，页面与图片离线打包在 `app/src/main/assets/www/`。这是源码工程，不是已编译 APK。

## 构建环境
- Android Studio（推荐近期稳定版）
- JDK 17
- Android SDK Platform 35 与 Build Tools 35.x
- Gradle Wrapper 8.9 / Android Gradle Plugin 8.7.3

## 生成 Debug APK
1. 解压完整工程 ZIP。
2. 用 Android Studio 打开 `android/` 文件夹。
3. 等待 Gradle Sync 完成并安装缺少的 SDK 组件。
4. 选择 **Build → Build Bundle(s) / APK(s) → Build APK(s)**。
5. APK 输出位置：`android/app/build/outputs/apk/debug/app-debug.apk`。

也可以在 `android/` 目录运行：

```bash
./gradlew assembleDebug
```

Windows 使用 `gradlew.bat assembleDebug`。GitHub Actions 工作流位于 `.github/workflows/android-debug-apk.yml`，成功后会上传 `shiqi-debug-apk` artifact。

## V1.1 新增能力
- WebView 文件选择器支持相册多选（上限 3 张），相机仍逐张拍摄。
- Google ML Kit bundled Barcode Scanning 17.3.0 在设备本地分析所选图片；不上传图片。支持常见 EAN/UPC、Code 128/39、QR 与 Data Matrix。
- 多张包装照片联合送入用户自配的视觉 API；识别结果需要人工核对，冲突日期/期限字段会清空。
- 条码只作为商品编号备注，不是日期、保质期或产品身份的权威证明；本版没有条码商品库查询。

## V0.7 Android 能力
- WebViewAssetLoader 使用 HTTPS 虚拟域名加载本地页面，离线页面支持 ES Modules 与相对资源。
- `ShelfieDatabase` 使用 SQLite 保存物品字段；旧版 WebView localStorage 中已有记录会在首次打开时迁移。网页模式仍以 localStorage 作为后备。
- 保存、编辑、删除、导入备份时会同步 SQLite，并取消/重建对应物品的提醒工作。
- WorkManager 为每条物品记录建立唯一的一次性提醒任务；任务以用户设置的提前天数计算提醒日期，目标为该日当地时间 09:00。修改记录会替换旧任务，删除记录会取消任务。
- Android 13+ 请求 `POST_NOTIFICATIONS`；设置页面提供权限状态和跳转入口。
- 系统重启、日期或时区变更时重新排程。
- 系统文件选择器导入 JSON、系统“另存为”导出 JSON。

## 通知准确性边界
通知使用 WorkManager，是可靠的可延迟后台任务机制，不是精确闹钟。省电模式、厂商后台管理、应用休眠或用户关闭通知，都可能导致通知延迟或不显示；不要将其宣传为 09:00 分钟级准时。OnePlus 设备应在安装后实际测试，并确认系统通知权限和后台运行设置。

## 数据迁移与隐私
- SQLite 数据库位于应用私有目录。卸载应用或清除应用数据会清除数据库；重要记录应定期导出 JSON 备份。
- 物品清单会保存在本机 SQLite；AI 对话发送到用户自行配置的 HTTPS API 服务商。
- API Key 的“记住”选项使用 Android Keystore AES-GCM 加密；密钥由设备保护，不会写入 WebView localStorage。

## 尚未完成/尚未验证
- 本次改动尚未在当前环境执行成功的 Gradle APK 编译。
- 尚未在 OnePlus 12 真机验证通知送达、重启重排程、权限拒绝/恢复流程。
- 尚未在 OnePlus 12 真机验证多选返回、ML Kit 扫描表现与图片旋转兼容性；Release 签名仍待开发。


## V0.8 安全与助手操作
- Android 版 API Key 可选择保存在设备 Android Keystore：使用 AES-256/GCM 加密，密钥不离开 Keystore；取消勾选会清除已保存密钥，但当前运行会话仍可使用已输入的 Key。
- 旧版保存在 WebView localStorage 配置中的 API Key 会在启动时尝试迁移至 Keystore，并从旧配置 JSON 中移除。若 Keystore 无法加密，Key 仅留在当前会话内存。
- AI 助手可以提出修改/删除物品操作，但会先显示确认卡片，只有用户点击确认才写入 SQLite。
- 设置页“提醒管理中心”逐件管理提前 7/3/1 天提醒或关闭；更改会通过 Native Bridge 重排 WorkManager。
- 当前仍使用 WorkManager 可延迟任务，不保证精确到分钟；设备厂商后台限制可能影响送达时机。
