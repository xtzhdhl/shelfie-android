import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const root = new URL('../', import.meta.url);
const read = path => readFile(new URL(path, root), 'utf8');

test('Android app is versioned 1.2 and includes camera capture plus WorkManager', async () => {
  const gradle = await read('android/app/build.gradle');
  assert.match(gradle, /versionCode\s+10/);
  assert.match(gradle, /versionName\s+'1\.2\.0'/);
  assert.match(gradle, /androidx\.work:work-runtime:2\.11\.2/);
});

test('Android manifest declares notification permission and reschedule receiver', async () => {
  const manifest = await read('android/app/src/main/AndroidManifest.xml');
  assert.match(manifest, /android\.permission\.POST_NOTIFICATIONS/);
  assert.match(manifest, /android\.permission\.RECEIVE_BOOT_COMPLETED/);
  assert.match(manifest, /ReminderRescheduleReceiver/);
});

test('SQLite schema stores core item fields and uses a transaction', async () => {
  const db = await read('android/app/src/main/java/com/shelfie/expiry/ShelfieDatabase.java');
  for (const column of ['manufacture', 'shelf_life', 'expiry', 'opened_date', 'after_opening_value', 'reminder_days', 'effective_expiry', 'reminder_date']) {
    assert.ok(db.includes(column), `missing SQLite column ${column}`);
  }
  assert.match(db, /beginTransaction\(\)/);
  assert.match(db, /setTransactionSuccessful\(\)/);
  assert.match(db, /endTransaction\(\)/);
});

test('native bridge exposes SQLite read/write and notification permission methods', async () => {
  const activity = await read('android/app/src/main/java/com/shelfie/expiry/MainActivity.java');
  assert.match(activity, /public String getItemsJson\(\)/);
  assert.match(activity, /public boolean saveItemsJson\(String rawJson\)/);
  assert.match(activity, /public boolean areNotificationsEnabled\(\)/);
  assert.match(activity, /public void requestNotificationPermission\(\)/);
});

test('reminders use unique WorkManager jobs and a local 09:00 trigger target', async () => {
  const scheduler = await read('android/app/src/main/java/com/shelfie/expiry/ShelfieReminderScheduler.java');
  assert.match(scheduler, /set\(Calendar\.HOUR_OF_DAY, 9\)/);
  assert.match(scheduler, /enqueueUniqueWork/);
  assert.match(scheduler, /ExistingWorkPolicy\.REPLACE/);
  assert.match(scheduler, /cancelUniqueWork/);
});

test('WebView uses SQLite bridge on Android and keeps localStorage for browser preview/migration', async () => {
  const js = await read('www/app.js');
  assert.match(js, /ShelfieNative\.getItemsJson/);
  assert.match(js, /ShelfieNative\.saveItemsJson/);
  assert.match(js, /One-time migration/);
  assert.match(js, /localStorage\.setItem\(STORAGE_KEY/);
});


test('Android API key vault uses Android Keystore AES-GCM and exposes secure bridge methods', async () => {
  const vault = await read('android/app/src/main/java/com/shelfie/expiry/ApiKeyVault.java');
  const activity = await read('android/app/src/main/java/com/shelfie/expiry/MainActivity.java');
  assert.match(vault, /AndroidKeyStore/);
  assert.match(vault, /AES\/GCM\/NoPadding/);
  assert.match(vault, /setRandomizedEncryptionRequired\(true\)/);
  assert.match(activity, /public boolean saveApiKey\(String value\)/);
  assert.match(activity, /public String getSavedApiKey\(\)/);
  assert.match(activity, /public boolean clearApiKey\(\)/);
  assert.match(activity, /MediaStore\.ACTION_IMAGE_CAPTURE/);
  assert.match(activity, /FileProvider\.getUriForFile/);
});

test('AI update/delete proposals are validated against item IDs and require confirmation UI', async () => {
  const js = await read('www/app.js');
  const html = await read('www/index.html');
  assert.match(js, /prepareAiMutation/);
  assert.match(js, /createAiMutationCard/);
  assert.match(js, /确认修改/);
  assert.match(js, /确认删除/);
  assert.match(html, /id="reminderManager"/);
});

test('Android API key is not written into the persisted API config object', async () => {
  const js = await read('www/app.js');
  const saveFunction = js.slice(js.indexOf('function saveApiConfig()'), js.indexOf('function effectiveApiKey()'));
  assert.doesNotMatch(saveFunction, /apiKey\s*:/);
  assert.match(saveFunction, /ShelfieNative\.saveApiKey/);
  assert.match(js, /delete config\.apiKey/);
});


test('Reminder center exposes per-item lead-time controls and a reschedule action', async () => {
  const html = await read('www/index.html');
  const js = await read('www/app.js');
  assert.match(html, /id="reminderManagerSummary"/);
  assert.match(html, /id="refreshReminderSchedule"/);
  assert.match(js, /data-reminder-days/);
  assert.match(js, /updateReminderDays/);
  assert.match(js, /ShelfieNative\.refreshReminders/);
});


test('camera capture avoids package-visibility preflight and cleans private cache files', async () => {
  const activity = await read('android/app/src/main/java/com/shelfie/expiry/MainActivity.java');
  assert.doesNotMatch(activity, /camera\.resolveActivity\(/);
  assert.match(activity, /lastSelectedCameraFile/);
  assert.match(activity, /pendingCameraFile\.delete\(\)/);
});


test('Android includes bundled on-device ML Kit barcode scanning without a network permission', async () => {
  const gradle = await read('android/app/build.gradle');
  const activity = await read('android/app/src/main/java/com/shelfie/expiry/MainActivity.java');
  const manifest = await read('android/app/src/main/AndroidManifest.xml');
  assert.match(gradle, /com\.google\.mlkit:barcode-scanning:17\.3\.0/);
  assert.match(activity, /BarcodeScanning\.getClient/);
  assert.match(activity, /InputImage\.fromBitmap/);
  assert.match(activity, /public void scanBarcodes\(String requestId, String imageDataUrl\)/);
  assert.match(activity, /deliverBarcodeResult/);
  assert.match(manifest, /uses-permission android:name="android.permission.INTERNET"/);
  assert.doesNotMatch(activity, /new URL\(.*barcode/i);
});
