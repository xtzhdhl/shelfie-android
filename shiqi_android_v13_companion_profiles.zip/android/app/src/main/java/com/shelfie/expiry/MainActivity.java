package com.shelfie.expiry;

import android.app.Activity;
import android.content.Intent;
import android.content.ClipData;
import android.os.Bundle;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.provider.MediaStore;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import androidx.webkit.WebViewAssetLoader;
import androidx.core.content.FileProvider;
import androidx.core.app.NotificationManagerCompat;

import java.io.OutputStream;
import java.io.File;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.Set;
import java.util.Locale;
import java.util.List;
import java.util.ArrayList;

import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

public class MainActivity extends Activity {
    private static final int CREATE_BACKUP_REQUEST = 4101;
    private static final int OPEN_BACKUP_REQUEST = 4102;
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/www/index.html";

    private WebView webView;
    private ShelfieDatabase shelfieDatabase;
    private static final int REQUEST_POST_NOTIFICATIONS = 4201;
    private ValueCallback<Uri[]> fileChooserCallback;
    private boolean fileChooserIsImage = false;
    private boolean fileChooserMultiple = false;
    private Uri pendingCameraUri;
    private File pendingCameraFile;
    private File lastSelectedCameraFile;
    private String pendingBackupJson;
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService barcodeExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService productLookupExecutor = Executors.newFixedThreadPool(4);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applySystemBarColors("#F7E7EC", "#FFF9FB");

        shelfieDatabase = new ShelfieDatabase(this);
        webView = new WebView(this);
        setContentView(webView);

        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new ShelfieBridge(), "ShelfieNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep the app inside its bundled local pages; no external navigation is needed.
                return !request.getUrl().getHost().equals("appassets.androidplatform.net");
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                fileChooserMultiple = params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE;
                String[] accepted = params.getAcceptTypes();
                boolean wantsImage = false;
                if (accepted != null) {
                    for (String type : accepted) {
                        if (type != null && (type.toLowerCase(Locale.ROOT).contains("image/") || type.equals("*/*"))) {
                            wantsImage = true;
                            break;
                        }
                    }
                }
                fileChooserIsImage = wantsImage;
                if (wantsImage && params.isCaptureEnabled()) {
                    launchPackageCamera(callback);
                    return true;
                }
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(wantsImage ? "image/*" : "application/json");
                if (fileChooserMultiple) intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(intent, OPEN_BACKUP_REQUEST);
                } catch (Exception e) {
                    fileChooserCallback = null;
                    fileChooserIsImage = false;
                    fileChooserMultiple = false;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "无法打开文件选择器", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });

        if (savedInstanceState == null) {
            webView.loadUrl(APP_URL);
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private void launchPackageCamera(ValueCallback<Uri[]> callback) {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Do not preflight with resolveActivity(): Android 11+ package visibility can
        // hide camera handlers unless an extra <queries> declaration is present.
        // Launch directly and handle ActivityNotFoundException in this guarded block.
        try {
            File directory = new File(getCacheDir(), "camera");
            if (!directory.exists() && !directory.mkdirs()) throw new IllegalStateException("无法创建照片缓存目录");
            File[] oldPhotos = directory.listFiles();
            if (oldPhotos != null) for (File old : oldPhotos) if (old.getName().startsWith("shelfie_scan_")) old.delete();
            lastSelectedCameraFile = null;
            pendingCameraFile = File.createTempFile("shelfie_scan_", ".jpg", directory);
            pendingCameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", pendingCameraFile);
            camera.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
            camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            camera.setClipData(ClipData.newUri(getContentResolver(), "Shelfie package photo", pendingCameraUri));
            startActivityForResult(camera, OPEN_BACKUP_REQUEST);
        } catch (Exception e) {
            fileChooserCallback = null;
            fileChooserIsImage = false;
            pendingCameraUri = null;
            pendingCameraFile = null;
            callback.onReceiveValue(null);
            Toast.makeText(this, "无法启动相机，请从相册选择照片", Toast.LENGTH_LONG).show();
        }
    }

    private void clearCameraTempReference() {
        pendingCameraUri = null;
        pendingCameraFile = null;
    }

    private void deletePendingCameraFile() {
        if (pendingCameraFile != null && pendingCameraFile.exists()) {
            // The WebView has no longer been given this URI (cancel/error path).
            // Successful captures are reclaimed on the next camera launch or app teardown.
            pendingCameraFile.delete();
        }
        clearCameraTempReference();
    }

    private void applySystemBarColors(String statusHex, String navigationHex) {
        try {
            int status = android.graphics.Color.parseColor(statusHex);
            int navigation = android.graphics.Color.parseColor(navigationHex);
            getWindow().setStatusBarColor(status);
            getWindow().setNavigationBarColor(navigation);
            if (Build.VERSION.SDK_INT >= 29) {
                getWindow().setStatusBarContrastEnforced(false);
                getWindow().setNavigationBarContrastEnforced(false);
            }
            getWindow().getDecorView().setSystemUiVisibility(
                    android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR |
                    android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            );
        } catch (IllegalArgumentException error) {
            android.util.Log.w("Shelfie", "Invalid theme system bar color", error);
        }
    }

    private class ShelfieBridge {
        /** Keep native Android status/navigation bars in sync with the selected web theme. */
        @JavascriptInterface
        public void setSystemBars(String statusHex, String navigationHex) {
            final String safeStatus = statusHex == null ? "#F7E7EC" : statusHex;
            final String safeNavigation = navigationHex == null ? "#FFF9FB" : navigationHex;
            if (!safeStatus.matches("^#[0-9A-Fa-f]{6}$") || !safeNavigation.matches("^#[0-9A-Fa-f]{6}$")) return;
            runOnUiThread(() -> applySystemBarColors(safeStatus, safeNavigation));
        }

        /** SQLite is the source of truth on Android; localStorage remains a web fallback. */
        @JavascriptInterface
        public String getItemsJson() {
            try {
                return shelfieDatabase.readAll().toString();
            } catch (Exception e) {
                android.util.Log.e("Shelfie", "Unable to read SQLite records", e);
                return "[]";
            }
        }

        @JavascriptInterface
        public boolean saveItemsJson(String rawJson) {
            try {
                JSONArray records = new JSONArray(rawJson == null ? "[]" : rawJson);
                Set<String> removedIds = shelfieDatabase.replaceAll(records);
                for (String id : removedIds) ShelfieReminderScheduler.cancel(MainActivity.this, id);
                try {
                    ShelfieReminderScheduler.scheduleAll(MainActivity.this, records);
                } catch (Exception scheduleError) {
                    // A scheduler issue must never roll back a successfully saved item record.
                    android.util.Log.e("Shelfie", "Reminder scheduling failed", scheduleError);
                }
                return true;
            } catch (Exception e) {
                android.util.Log.e("Shelfie", "Unable to save SQLite records", e);
                return false;
            }
        }

        /** API secrets are stored encrypted with a device-bound AES key in Android Keystore. */
        @JavascriptInterface
        public boolean saveApiKey(String value) {
            return ApiKeyVault.save(MainActivity.this, value);
        }

        @JavascriptInterface
        public String getSavedApiKey() {
            return ApiKeyVault.read(MainActivity.this);
        }

        @JavascriptInterface
        public boolean hasSavedApiKey() {
            return ApiKeyVault.hasValue(MainActivity.this);
        }

        @JavascriptInterface
        public boolean clearApiKey() {
            return ApiKeyVault.clear(MainActivity.this);
        }

        /**
         * Scan a user-selected, already-compressed photo locally with bundled ML Kit.
         * The image is never uploaded or written to persistent storage by this method.
         */
        @JavascriptInterface
        public void scanBarcodes(String requestId, String imageDataUrl) {
            final String safeRequestId = requestId == null ? "" : requestId.substring(0, Math.min(80, requestId.length()));
            if (imageDataUrl == null || !imageDataUrl.startsWith("data:image/") || imageDataUrl.length() > 2_700_000) {
                deliverBarcodeResult(safeRequestId, false, new JSONArray(), "照片数据无效或过大，请重新选择照片。");
                return;
            }
            barcodeExecutor.execute(() -> {
                BarcodeScanner scanner = null;
                Bitmap bitmap = null;
                try {
                    int comma = imageDataUrl.indexOf(',');
                    if (comma < 0) throw new IllegalArgumentException("照片格式无法识别。");
                    byte[] bytes = Base64.decode(imageDataUrl.substring(comma + 1), Base64.DEFAULT);
                    if (bytes.length == 0 || bytes.length > 2_000_000) throw new IllegalArgumentException("照片数据为空或过大。");
                    bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (bitmap == null) throw new IllegalArgumentException("无法读取照片，请使用 JPG 或 PNG 图片。");

                    BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                            .setBarcodeFormats(
                                    Barcode.FORMAT_EAN_13,
                                    Barcode.FORMAT_EAN_8,
                                    Barcode.FORMAT_UPC_A,
                                    Barcode.FORMAT_UPC_E,
                                    Barcode.FORMAT_CODE_128,
                                    Barcode.FORMAT_CODE_39,
                                    Barcode.FORMAT_QR_CODE,
                                    Barcode.FORMAT_DATA_MATRIX
                            )
                            .build();
                    scanner = BarcodeScanning.getClient(options);
                    final BarcodeScanner scannerRef = scanner;
                    final Bitmap bitmapRef = bitmap;
                    Task<List<Barcode>> task = scanner.process(InputImage.fromBitmap(bitmap, 0));
                    task.addOnSuccessListener(results -> {
                        JSONArray found = new JSONArray();
                        for (Barcode barcode : results) {
                            String value = barcode.getRawValue();
                            if (value == null || value.trim().isEmpty()) continue;
                            JSONObject row = new JSONObject();
                            try {
                                row.put("rawValue", value.trim());
                                row.put("format", barcodeFormatName(barcode.getFormat()));
                                found.put(row);
                            } catch (JSONException ignored) { }
                            if (found.length() >= 10) break;
                        }
                        deliverBarcodeResult(safeRequestId, true, found, "");
                    }).addOnFailureListener(error ->
                            deliverBarcodeResult(safeRequestId, false, new JSONArray(), "条码识别失败：" + safeErrorMessage(error)))
                      .addOnCompleteListener(done -> {
                          try { scannerRef.close(); } catch (Exception ignored) { }
                          if (!bitmapRef.isRecycled()) bitmapRef.recycle();
                      });
                } catch (Exception error) {
                    if (scanner != null) try { scanner.close(); } catch (Exception ignored) { }
                    if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                    deliverBarcodeResult(safeRequestId, false, new JSONArray(), safeErrorMessage(error));
                }
            });
        }

        /** Read-only product catalogue lookup. Only HTTPS Open Facts hosts are allowed. */
        @JavascriptInterface
        public void getProductJson(String requestId, String endpoint) {
            final String safeRequestId = requestId == null ? "" : requestId.substring(0, Math.min(80, requestId.length()));
            productLookupExecutor.execute(() -> {
                HttpURLConnection connection = null;
                int status = 0;
                String responseText = "{}";
                try {
                    URL url = new URL(endpoint);
                    if (!"https".equalsIgnoreCase(url.getProtocol()) || url.getUserInfo() != null
                            || (url.getPort() != -1 && url.getPort() != 443) || !isAllowedProductHost(url.getHost())
                            || !isAllowedProductPath(url.getPath())) {
                        throw new IllegalArgumentException("商品资料查询地址不在允许的公开目录范围内。");
                    }
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setInstanceFollowRedirects(true);
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(10000);
                    connection.setReadTimeout(12000);
                    connection.setRequestProperty("Accept", "application/json");
                    connection.setRequestProperty("User-Agent", "Shelfie-SHIQI/1.3.0 (Android product lookup)");
                    status = connection.getResponseCode();
                    URL finalUrl = connection.getURL();
                    if (!"https".equalsIgnoreCase(finalUrl.getProtocol()) || finalUrl.getUserInfo() != null
                            || (finalUrl.getPort() != -1 && finalUrl.getPort() != 443)
                            || !isAllowedProductHost(finalUrl.getHost()) || !isAllowedProductPath(finalUrl.getPath())) {
                        throw new IllegalArgumentException("商品数据库跳转到了未受支持的地址，已安全拦截。");
                    }
                    InputStream input = status >= 200 && status < 400 ? connection.getInputStream() : connection.getErrorStream();
                    if (input != null) {
                        try (InputStream in = input; ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                            byte[] chunk = new byte[8192];
                            int n;
                            while ((n = in.read(chunk)) != -1) {
                                if (buffer.size() + n > 1_500_000) throw new IllegalStateException("商品目录响应过大，已停止读取。");
                                buffer.write(chunk, 0, n);
                            }
                            responseText = buffer.toString("UTF-8");
                        }
                    }
                } catch (Exception error) {
                    status = status == 0 ? 599 : status;
                    try { responseText = new JSONObject().put("error", safeErrorMessage(error)).toString(); }
                    catch (Exception ignored) { responseText = "{}"; }
                } finally {
                    if (connection != null) connection.disconnect();
                }
                deliverProductLookupResult(safeRequestId, status, responseText);
            });
        }

        private boolean isAllowedProductHost(String host) {
            if (host == null) return false;
            String value = host.toLowerCase(Locale.ROOT);
            return value.equals("world.openfoodfacts.org")
                    || value.equals("world.openbeautyfacts.org")
                    || value.equals("world.openpetfoodfacts.org")
                    || value.equals("world.openproductsfacts.org");
        }

        private boolean isAllowedProductPath(String path) {
            if (path == null) return false;
            return path.matches("^/api/v[23]/product/\\d{8,14}\\.json$")
                    || path.equals("/cgi/search.pl");
        }

        @JavascriptInterface
        public boolean areNotificationsEnabled() {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
            return NotificationManagerCompat.from(MainActivity.this).areNotificationsEnabled();
        }

        @JavascriptInterface
        public void refreshReminders() {
            try {
                ShelfieReminderScheduler.scheduleAll(MainActivity.this, shelfieDatabase.readAll());
            } catch (Exception e) {
                android.util.Log.e("Shelfie", "Unable to refresh expiry reminders", e);
            }
        }

        @JavascriptInterface
        public void requestNotificationPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    boolean askedBefore = getSharedPreferences("shelfie_permissions", MODE_PRIVATE).getBoolean("post_notifications_asked", false);
                    if (!askedBefore || shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                        getSharedPreferences("shelfie_permissions", MODE_PRIVATE).edit().putBoolean("post_notifications_asked", true).apply();
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_POST_NOTIFICATIONS);
                    } else {
                        openNotificationSettings();
                    }
                } else if (!NotificationManagerCompat.from(MainActivity.this).areNotificationsEnabled()) {
                    openNotificationSettings();
                } else {
                    Toast.makeText(MainActivity.this, "拾期通知权限已经开启", Toast.LENGTH_SHORT).show();
                }
            });
        }
        @JavascriptInterface
        public void chatCompletion(String requestId, String endpoint, String apiKey, String requestBody) {
            networkExecutor.execute(() -> {
                int status = 0;
                String responseText = "{}";
                HttpURLConnection connection = null;
                try {
                    URL url = new URL(endpoint);
                    if (!"https".equalsIgnoreCase(url.getProtocol())) {
                        throw new IllegalArgumentException("为保护 API Key，请使用 HTTPS 接口地址。");
                    }
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(20000);
                    connection.setReadTimeout(60000);
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    connection.setRequestProperty("Accept", "application/json");
                    connection.setRequestProperty("Authorization", "Bearer " + apiKey);
                    byte[] body = requestBody.getBytes(StandardCharsets.UTF_8);
                    connection.setFixedLengthStreamingMode(body.length);
                    try (OutputStream out = connection.getOutputStream()) {
                        out.write(body);
                    }
                    status = connection.getResponseCode();
                    InputStream input = status >= 200 && status < 400
                            ? connection.getInputStream() : connection.getErrorStream();
                    if (input != null) {
                        try (InputStream in = input; ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                            byte[] chunk = new byte[8192];
                            int n;
                            while ((n = in.read(chunk)) != -1) buffer.write(chunk, 0, n);
                            responseText = buffer.toString("UTF-8");
                        }
                    }
                } catch (Exception e) {
                    try {
                        JSONObject error = new JSONObject();
                        error.put("error", new JSONObject().put("message", e.getMessage() == null ? "网络连接失败" : e.getMessage()));
                        responseText = error.toString();
                    } catch (Exception ignored) { responseText = "{\"error\":{\"message\":\"网络连接失败\"}}"; }
                    if (status == 0) status = 599;
                } finally {
                    if (connection != null) connection.disconnect();
                }
                final int resultStatus = status;
                final String resultText = responseText;
                runOnUiThread(() -> {
                    if (webView != null) {
                        String js = "window.ShelfieNativeResult && window.ShelfieNativeResult("
                                + JSONObject.quote(requestId) + "," + resultStatus + ","
                                + JSONObject.quote(resultText) + ");";
                        webView.evaluateJavascript(js, null);
                    }
                });
            });
        }

        @JavascriptInterface
        public void exportBackup(String json) {
            runOnUiThread(() -> {
                pendingBackupJson = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "拾期备份.json");
                try {
                    startActivityForResult(intent, CREATE_BACKUP_REQUEST);
                } catch (Exception e) {
                    pendingBackupJson = null;
                    Toast.makeText(MainActivity.this, "无法打开系统保存窗口", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private String barcodeFormatName(int format) {
        switch (format) {
            case Barcode.FORMAT_EAN_13: return "EAN-13";
            case Barcode.FORMAT_EAN_8: return "EAN-8";
            case Barcode.FORMAT_UPC_A: return "UPC-A";
            case Barcode.FORMAT_UPC_E: return "UPC-E";
            case Barcode.FORMAT_CODE_128: return "CODE-128";
            case Barcode.FORMAT_CODE_39: return "CODE-39";
            case Barcode.FORMAT_QR_CODE: return "QR";
            case Barcode.FORMAT_DATA_MATRIX: return "DATA-MATRIX";
            default: return "UNKNOWN";
        }
    }

    private String safeErrorMessage(Exception error) {
        String message = error == null ? "未知错误" : error.getMessage();
        if (message == null || message.trim().isEmpty()) return "无法读取条码，请换个角度重试。";
        return message.length() > 160 ? message.substring(0, 160) : message;
    }

    private void deliverProductLookupResult(String requestId, int status, String responseText) {
        final String encodedId = JSONObject.quote(requestId == null ? "" : requestId);
        final String encodedResponse = JSONObject.quote(responseText == null ? "{}" : responseText);
        if (webView == null) return;
        webView.post(() -> {
            if (webView == null || isFinishing()) return;
            webView.evaluateJavascript(
                    "window.ShelfieProductLookupResult && window.ShelfieProductLookupResult(" + encodedId + "," + status + "," + encodedResponse + ");",
                    null
            );
        });
    }

    private void deliverBarcodeResult(String requestId, boolean success, JSONArray barcodes, String error) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("barcodes", barcodes == null ? new JSONArray() : barcodes);
            if (error != null && !error.isEmpty()) payload.put("error", error);
        } catch (JSONException ignored) { }
        final String encodedId = JSONObject.quote(requestId == null ? "" : requestId);
        final String encodedPayload = JSONObject.quote(payload.toString());
        if (webView == null) return;
        webView.post(() -> {
            if (webView == null || isFinishing()) return;
            webView.evaluateJavascript(
                    "window.ShelfieBarcodeResult && window.ShelfieBarcodeResult(" + encodedId + "," + success + "," + encodedPayload + ");",
                    null
            );
        });
    }

    private void openNotificationSettings() {
        Intent intent;
        if (Build.VERSION.SDK_INT >= 26) {
            intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        } else {
            intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
        }
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OPEN_BACKUP_REQUEST) {
            if (fileChooserCallback != null) {
                ArrayList<Uri> selectedUris = new ArrayList<>();
                if (resultCode == RESULT_OK) {
                    if (fileChooserIsImage && pendingCameraUri != null && pendingCameraFile != null
                            && pendingCameraFile.exists() && pendingCameraFile.length() > 0) {
                        selectedUris.add(pendingCameraUri);
                    } else if (data != null && data.getClipData() != null) {
                        for (int i = 0; i < data.getClipData().getItemCount() && selectedUris.size() < 36; i++) {
                            Uri uri = data.getClipData().getItemAt(i).getUri();
                            if (uri != null && !selectedUris.contains(uri)) selectedUris.add(uri);
                        }
                        if (selectedUris.isEmpty() && data.getData() != null) selectedUris.add(data.getData());
                    } else if (data != null && data.getData() != null) {
                        selectedUris.add(data.getData());
                    }
                }
                Uri[] result = selectedUris.isEmpty() ? null : selectedUris.toArray(new Uri[0]);
                fileChooserCallback.onReceiveValue(result);
                fileChooserCallback = null;
                if (result == null) {
                    deletePendingCameraFile();
                } else if (pendingCameraFile != null) {
                    // Keep a camera temp file available while Chromium reads the content URI.
                    // Gallery URIs are managed by the system document provider.
                    lastSelectedCameraFile = pendingCameraFile;
                    clearCameraTempReference();
                }
            } else {
                deletePendingCameraFile();
            }
            fileChooserIsImage = false;
            fileChooserMultiple = false;
            return;
        }
        if (requestCode == CREATE_BACKUP_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IllegalStateException("No output stream");
                    out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "备份已保存", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "保存失败，请重试", Toast.LENGTH_LONG).show();
                }
            }
            pendingBackupJson = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_POST_NOTIFICATIONS) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                try {
                    ShelfieReminderScheduler.scheduleAll(this, shelfieDatabase.readAll());
                    Toast.makeText(this, "通知已开启，现有物品提醒已重新安排", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    android.util.Log.e("Shelfie", "Unable to restore reminders after permission grant", e);
                }
            } else {
                Toast.makeText(this, "未开启通知；你仍可正常使用物品记录，之后可在设置里开启提醒", Toast.LENGTH_LONG).show();
            }
            if (webView != null) {
                webView.evaluateJavascript("window.shelfieNotificationPermissionChanged && window.shelfieNotificationPermissionChanged(" + granted + ");", null);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.evaluateJavascript("window.shelfieRefreshNotificationUi && window.shelfieRefreshNotificationUi();", null);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
        fileChooserMultiple = false;
        if (pendingCameraFile != null && pendingCameraFile.exists()) pendingCameraFile.delete();
        if (lastSelectedCameraFile != null && lastSelectedCameraFile.exists()) lastSelectedCameraFile.delete();
        clearCameraTempReference();
        lastSelectedCameraFile = null;
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.removeJavascriptInterface("ShelfieNative");
            webView.destroy();
        }
        networkExecutor.shutdownNow();
        barcodeExecutor.shutdownNow();
        productLookupExecutor.shutdownNow();
        if (shelfieDatabase != null) shelfieDatabase.close();
        super.onDestroy();
    }
}
