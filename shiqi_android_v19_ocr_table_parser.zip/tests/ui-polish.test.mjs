import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const html = readFileSync(new URL('../www/index.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('../www/styles.css', import.meta.url), 'utf8');
const app = readFileSync(new URL('../www/app.js', import.meta.url), 'utf8');
const gradle = readFileSync(new URL('../android/app/build.gradle', import.meta.url), 'utf8');

test('avatar shape selector offers circle and rectangle', () => {
  assert.match(html, /data-avatar-shape-choice="circle"/);
  assert.match(html, /data-avatar-shape-choice="rectangle"/);
  assert.match(app, /chatAvatarShape:'circle'/);
  assert.match(app, /document\.body\.dataset\.chatAvatarShape=avatarShape/);
});

test('avatar shape preference persists and is applied to future chat avatars', () => {
  assert.match(app, /profileSettings\.chatAvatarShape=button\.dataset\.avatarShapeChoice/);
  assert.match(app, /persistProfileSettings\(\).*applyProfileToUi\(\)/s);
  assert.match(css, /body\[data-chat-avatar-shape="rectangle"\] \.message-avatar/);
  assert.match(css, /\.profile-avatar-preview img,\.assistant-avatar img,\.message-avatar img\{[^}]*border-radius:inherit/);
  assert.match(css, /body\[data-chat-avatar-shape="rectangle"\] \.assistant-avatar/);
});

test('composer plus uses a centered vector icon instead of a font glyph', () => {
  assert.match(html, /id="composerAdd"[^>]*>\s*<svg/);
  assert.match(css, /\.composer-plus\{display:grid;place-items:center/);
});

test('sheet close buttons use centered vector icons', () => {
  assert.ok((html.match(/class="close-button"/g) || []).length >= 3);
  assert.match(html, /class="close-button"[^>]*>\s*<svg/);
  assert.match(app, /data-close=\"detailModal\"[^>]*><svg/);
  assert.match(css, /\.close-button\{display:grid;place-items:center/);
});

test('V1.9.0 retains V1.5.2 avatar image clipping to the selected parent shape', () => {
  assert.match(css, /\.profile-avatar-preview img,\.assistant-avatar img,\.message-avatar img\{[^}]*border-radius:inherit/);
});

test('V1.9.0 retains V1.5.2 square circle-avatar geometry to a square geometry on desktop and mobile', () => {
  assert.match(css, /body\[data-chat-avatar-shape=\"circle\"\] \.message-avatar,?/);
  assert.match(css, /flex: 0 0 29px/);
  assert.match(css, /flex: 0 0 25px/);
  assert.match(css, /aspect-ratio: 1 \/ 1/);
  assert.match(css, /position: absolute;\s*inset: 0;/);
});

test('V1.9.0 keeps the application identity and increments versionCode', () => {
  assert.match(gradle, /applicationId 'com\.shelfie\.expiry'/);
  assert.match(gradle, /applicationIdSuffix '\.debug'/);
  assert.match(gradle, /versionCode 19/);
  assert.match(gradle, /versionName '1\.9\.0'/);
  assert.match(gradle, /signingConfig signingConfigs\.shelfieUpload/);
});


test('API configuration nudge only appears when required configuration is missing', () => {
  assert.match(html, /id="apiNudge" hidden/);
  assert.match(html, /id="apiNudgeText"/);
  assert.match(html, /id="apiNudgeAction"/);
  assert.match(css, /\[hidden\]\s*\{\s*display:\s*none\s*!important/);
  assert.match(app, /function updateApiStatus\(\).*nudge\.hidden=ready&&!failed/s);
});

test('API status distinguishes configured credentials from a tested live connection', () => {
  assert.match(app, /let apiConnectionState='unknown'/);
  assert.match(app, /apiConnectionState==='connected'\?'连接正常'/);
  assert.match(app, /failed\?'连接失败'/);
  assert.match(app, /apiConnectionState='connected'/);
  assert.match(app, /apiConnectionState='failed'/);
  assert.match(app, /最近一次连接没有成功/);
});

test('V1.9.0 increments version while preserving Android application identity', () => {
  assert.match(gradle, /applicationId 'com\.shelfie\.expiry'/);
  assert.match(gradle, /applicationIdSuffix '\.debug'/);
  assert.match(gradle, /versionCode 19/);
  assert.match(gradle, /versionName '1\.9\.0'/);
  assert.match(gradle, /signingConfig signingConfigs\.shelfieUpload/);
});
