const EXPIRY_MARKERS = /到期|有效期|截止|失效|食用期限|保质期至|exp(?:iry)?|best\s*before|use\s*by|bb\b/i;
const MANUFACTURE_MARKERS = /生产日期|制造日期|出厂日期|mfg|mfd|manufactur(?:ed|e)?\s*date/i;
const META_LINE = /^(?:物品|商品|产品|名称|日期|到期日期|有效期|保质期|生产日期|序号|数量|备注|剩余|天数|分类|批次|清单|库存|提醒|expiry|expiration|name|date|item|product|qty|quantity|mfg|mfd|exp)$/i;
const DATE_PATTERNS = [
  { regex: /(?:^|[^\d])(20\d{2})\s*[年./-]\s*(\d{1,2})\s*[月./-]\s*(\d{1,2})\s*日?(?!\d)/g, kind: 'ymd' },
  { regex: /(?:^|[^\d])(20\d{2})(\d{2})(\d{2})(?!\d)/g, kind: 'compact' },
  { regex: /(?:^|[^\d])(\d{1,2})\s*[./-]\s*(\d{1,2})\s*[./-]\s*(20\d{2})(?!\d)/g, kind: 'dmy' }
];

function pad2(value) { return String(value).padStart(2, '0'); }
function validDate(year, month, day) {
  if (!Number.isInteger(year) || year < 2000 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) return '';
  const date = new Date(Date.UTC(year, month - 1, day));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) return '';
  return `${year}-${pad2(month)}-${pad2(day)}`;
}

export function parseOcrDateTokens(text) {
  const source = String(text || '');
  const found = [];
  for (const pattern of DATE_PATTERNS) {
    pattern.regex.lastIndex = 0;
    let match;
    while ((match = pattern.regex.exec(source))) {
      let year, month, day;
      if (pattern.kind === 'ymd') [, year, month, day] = match;
      else if (pattern.kind === 'compact') [, year, month, day] = match;
      else {
        let first = Number(match[1]), second = Number(match[2]);
        year = match[3];
        // A trailing-year date is only accepted when its day/month order is unambiguous.
        if (first <= 12 && second <= 12) continue;
        if (first > 12) { day = first; month = second; }
        else { month = first; day = second; }
      }
      const iso = validDate(Number(year), Number(month), Number(day));
      if (!iso) continue;
      const offset = Math.max(0, match[0].search(/[0-9]/));
      const full = match[0].slice(offset);
      const start = match.index + offset;
      found.push({ date: iso, raw: full, start, end: start + full.length });
    }
  }
  found.sort((a, b) => a.start - b.start || a.end - b.end);
  return found.filter((entry, index, all) => !all.slice(0, index).some(prev => prev.date === entry.date && Math.abs(prev.start - entry.start) < 3));
}

function tidyName(value) {
  return String(value || '')
    .replace(/20\d{2}\s*[年./-]\s*\d{1,2}\s*[月./-]\s*\d{1,2}\s*日?/g, ' ')
    .replace(/\b20\d{6}\b/g, ' ')
    .replace(/\b(?:\d{1,2})[./-](?:\d{1,2})[./-]20\d{2}\b/g, ' ')
    .replace(/\b(?:EXP(?:IRY)?|MFG|MFD|BEST\s*BEFORE|USE\s*BY)\b/gi, ' ')
    .replace(/生产日期|制造日期|出厂日期|到期日期|有效期至|有效期|保质期至|保质期|截止日期|截止|expiry|expiration|date/gi, ' ')
    .replace(/[：:：|｜,，;；·•\-—_\s]+/g, ' ')
    .trim();
}
function looksLikeProductName(text) {
  const value = tidyName(text);
  if (value.length < 2 || value.length > 48 || META_LINE.test(value)) return false;
  if (/^(?:\d+[号#]?|第?\d+项)$/.test(value)) return false;
  if (/(?:到期|有效期|生产日期|保质期|EXP|MFG|MFD|剩余\s*\d+)/i.test(value)) return false;
  return /[\p{L}]/u.test(value);
}
function categoryFor(name) {
  const value = String(name || '');
  if (/牛奶|酸奶|饮料|食品|面包|麦片|燕麦|零食|果汁|饼干|罐头|咖啡|茶/.test(value)) return '食品饮料';
  if (/面霜|精华|护肤|口红|洗面奶|乳液|防晒|化妆/.test(value)) return '护肤美妆';
  if (/药|维生素|胶囊|片剂|药膏/.test(value)) return '药品保健';
  if (/洗衣|清洁|纸巾|洗涤|洗洁精|消毒/.test(value)) return '日用百货';
  return '其他';
}
function lineBox(line) {
  const box = line?.box || line || {};
  const x = Number(box.x ?? box.left ?? 0) || 0;
  const y = Number(box.y ?? box.top ?? 0) || 0;
  const width = Number(box.width ?? (Number(box.right) - x) ?? 0) || 0;
  const height = Number(box.height ?? (Number(box.bottom) - y) ?? 0) || 0;
  return { x, y, width: Math.max(0, width), height: Math.max(0, height) };
}
function normalizeLines(input) {
  const lines = Array.isArray(input) ? input : [];
  const cleaned = lines.map((line, index) => ({
    text: String(line?.text || '').replace(/\s+/g, ' ').trim(),
    confidence: Number.isFinite(Number(line?.confidence)) ? Number(line.confidence) : 0.65,
    imageIndex: Number.isInteger(line?.imageIndex) ? line.imageIndex : 0,
    index,
    ...lineBox(line)
  })).filter(line => line.text);
  // Chinese and Latin recognizers may report the same line; keep the clearer copy.
  const unique = [];
  for (const line of cleaned) {
    const duplicateIndex = unique.findIndex(prev => prev.imageIndex === line.imageIndex
      && prev.text.toLowerCase() === line.text.toLowerCase()
      && Math.abs((prev.y + prev.height / 2) - (line.y + line.height / 2)) <= Math.max(12, line.height, prev.height));
    if (duplicateIndex < 0) unique.push(line);
    else if (line.confidence > unique[duplicateIndex].confidence) unique[duplicateIndex] = line;
  }
  return unique;
}
function getLabelType(text, token) {
  const around = `${text.slice(Math.max(0, token.start - 18), token.start)} ${text.slice(token.end, token.end + 10)}`;
  if (MANUFACTURE_MARKERS.test(around)) return 'manufacture';
  if (EXPIRY_MARKERS.test(around) || EXPIRY_MARKERS.test(text)) return 'expiry';
  return 'unknown';
}
function extractInlineName(text, token) {
  const before = tidyName(text.slice(0, token.start));
  const after = tidyName(text.slice(token.end));
  if (looksLikeProductName(before)) return before;
  if (looksLikeProductName(after)) return after;
  return '';
}
function closestProductName(dateLine, allLines, imageHeight, imageWidth) {
  const candidates = allLines.filter(line => line.imageIndex === dateLine.imageIndex
    && line !== dateLine && parseOcrDateTokens(line.text).length === 0 && looksLikeProductName(line.text));
  const maxDistance = Math.max(100, imageHeight * 0.055, dateLine.height * 6);
  let best = null;
  for (const candidate of candidates) {
    const dy = Math.abs((candidate.y + candidate.height / 2) - (dateLine.y + dateLine.height / 2));
    if (dy > maxDistance) continue;
    const overlap = Math.max(0, Math.min(dateLine.x + dateLine.width, candidate.x + candidate.width) - Math.max(dateLine.x, candidate.x));
    const minWidth = Math.max(1, Math.min(dateLine.width || 1, candidate.width || 1));
    const sameColumnBonus = overlap / minWidth;
    const dateCenterX = dateLine.x + dateLine.width / 2;
    const candidateCenterX = candidate.x + candidate.width / 2;
    const dx = Math.abs(dateCenterX - candidateCenterX);
    const horizontalPenalty = dx / Math.max(160, imageWidth * 0.5);
    const score = dy / Math.max(18, (dateLine.height + candidate.height) / 2) + horizontalPenalty * 0.9 - sameColumnBonus * 0.35;
    if (!best || score < best.score) best = { name: tidyName(candidate.text), score, line: candidate };
  }
  return best?.name || '';
}

export function extractExpiryRecords(ocrLines, dimensions = {}) {
  const lines = normalizeLines(ocrLines);
  const imageHeight = Number(dimensions.height) || Math.max(1, ...lines.map(line => line.y + line.height));
  const imageWidth = Number(dimensions.width) || Math.max(1, ...lines.map(line => line.x + line.width));
  const groups = new Map();
  const warnings = [];

  for (const line of lines) {
    const tokens = parseOcrDateTokens(line.text);
    if (!tokens.length) continue;
    for (const token of tokens) {
      const type = getLabelType(line.text, token);
      const inlineName = extractInlineName(line.text, token);
      const name = inlineName || closestProductName(line, lines, imageHeight, imageWidth);
      if (!name) {
        warnings.push(`未能为日期 ${token.date} 找到明确的物品名称，请在原图中核对。`);
        continue;
      }
      const key = `${line.imageIndex}:${name.toLocaleLowerCase()}`;
      if (!groups.has(key)) groups.set(key, {
        name,
        category: categoryFor(name),
        expiry: '',
        manufacture: '',
        confidence: line.confidence,
        sourceLines: [line.text],
        warnings: []
      });
      const record = groups.get(key);
      record.confidence = Math.min(record.confidence, line.confidence);
      if (!record.sourceLines.includes(line.text)) record.sourceLines.push(line.text);
      const field = type === 'manufacture' ? 'manufacture' : 'expiry';
      if (type === 'unknown') record.warnings.push('截图没有明确标注这是生产日期还是到期日期，暂按到期日期整理，请核对。');
      if (record[field] && record[field] !== token.date) {
        record[field] = '';
        record.warnings.push(`${field === 'expiry' ? '到期日期' : '生产日期'}出现多个不同值，请手动核对。`);
      } else if (!record.warnings.some(w => w.includes('出现多个不同值'))) {
        record[field] = token.date;
      }
    }
  }

  const mapped = [...groups.values()].map((record, index) => ({
    id: `ocr-${index + 1}`,
    ...record,
    selected: Boolean(record.name && record.expiry),
    warnings: [...new Set(record.warnings)],
    sourceText: record.sourceLines.join(' / ')
  }));
  const deduplicated = new Map();
  for (const record of mapped) {
    const key = `${record.name.toLocaleLowerCase()}|${record.expiry}|${record.manufacture}`;
    if (!deduplicated.has(key)) deduplicated.set(key, record);
    else {
      const previous = deduplicated.get(key);
      previous.sourceText = [...new Set([previous.sourceText, record.sourceText].filter(Boolean))].join(' / ');
      previous.warnings = [...new Set([...previous.warnings, ...record.warnings])];
      previous.confidence = Math.min(previous.confidence, record.confidence);
    }
  }
  const records = [...deduplicated.values()];
  return {
    records,
    rawText: lines.map(line => line.text).join('\n'),
    lineCount: lines.length,
    warnings: [...new Set(warnings)]
  };
}
