const CACHE_NAME = 'shelfie-cache-v8';
const FILES = [
  './', './index.html', './styles.css', './app.js', './ai-mutations.js', './date-utils.js', './photo-recognition.js', './product-lookup.js', './backup-utils.js', './ocr-import.js', './manifest.webmanifest',
  './assets/moon-mascot.png', './assets/moon-mascot-smile.png', './assets/hourglass.png',
  './assets/calendar.png', './assets/jar.png', './assets/milk.png', './assets/serum.png',
  './assets/medicine.png', './assets/food-box.png', './assets/cream.png', './assets/mini-fridge.png',
  './assets/bell.png', './assets/leaves.png', './assets/tag.png', './assets/organizer.png', './assets/search.png'
];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(FILES))));
self.addEventListener('activate', event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))))));
self.addEventListener('fetch', event => event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request))));
