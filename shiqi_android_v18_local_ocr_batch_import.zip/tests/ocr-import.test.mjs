import test from 'node:test';
import assert from 'node:assert/strict';
import { parseOcrDateTokens, extractExpiryRecords } from '../www/ocr-import.js';

test('OCR date parser accepts year-first ISO, Chinese and compact dates', () => {
  assert.deepEqual(parseOcrDateTokens('EXP 2026/11/28'), [{ date: '2026-11-28', raw: '2026/11/28', start: 4, end: 14 }]);
  assert.equal(parseOcrDateTokens('到期日：2026年12月5日')[0].date, '2026-12-05');
  assert.equal(parseOcrDateTokens('有效期至 20261208')[0].date, '2026-12-08');
});

test('OCR date parser rejects impossible and ambiguous dates', () => {
  assert.equal(parseOcrDateTokens('2026-02-30').length, 0);
  assert.equal(parseOcrDateTokens('01/02/2027').length, 0);
});

test('OCR pairs same-row product names with expiry dates', () => {
  const result = extractExpiryRecords([
    { text: '燕麦牛奶', x: 40, y: 100, width: 180, height: 32, confidence: 0.96 },
    { text: '到期 2026-11-28', x: 330, y: 101, width: 220, height: 32, confidence: 0.94 }
  ], { height: 600 });
  assert.equal(result.records.length, 1);
  assert.equal(result.records[0].name, '燕麦牛奶');
  assert.equal(result.records[0].expiry, '2026-11-28');
  assert.equal(result.records[0].category, '食品饮料');
});

test('OCR pairs vertically adjacent product and date rows', () => {
  const result = extractExpiryRecords([
    { text: '草莓酸奶', x: 40, y: 100, width: 180, height: 30, confidence: 0.91 },
    { text: '有效期至 2026年11月25日', x: 40, y: 138, width: 300, height: 30, confidence: 0.93 }
  ], { height: 900 });
  assert.equal(result.records[0].name, '草莓酸奶');
  assert.equal(result.records[0].expiry, '2026-11-25');
});

test('OCR retains production date separately from expiry date', () => {
  const result = extractExpiryRecords([
    { text: '洗面奶', x: 30, y: 50, width: 150, height: 28, confidence: 0.9 },
    { text: '生产日期 2026-11-01', x: 30, y: 82, width: 260, height: 28, confidence: 0.9 },
    { text: '有效期至 2027-11-01', x: 30, y: 114, width: 260, height: 28, confidence: 0.9 }
  ], { height: 600 });
  assert.equal(result.records.length, 1);
  assert.equal(result.records[0].manufacture, '2026-11-01');
  assert.equal(result.records[0].expiry, '2027-11-01');
});

test('OCR extracts manufacture and expiry dates from one line without mixing them', () => {
  const result = extractExpiryRecords([
    { text: '燕麦牛奶 生产日期 2026-11-01 有效期至 2027-11-01', x: 12, y: 24, width: 560, height: 34, confidence: 0.95 }
  ], { height: 600, width: 600 });
  assert.equal(result.records.length, 1);
  assert.equal(result.records[0].name, '燕麦牛奶');
  assert.equal(result.records[0].manufacture, '2026-11-01');
  assert.equal(result.records[0].expiry, '2027-11-01');
});

test('OCR de-duplicates an identical item/date repeated in two screenshots', () => {
  const result = extractExpiryRecords([
    { text: '草莓酸奶', x: 10, y: 20, width: 120, height: 26, confidence: 0.9, imageIndex: 0 },
    { text: '到期 2026-11-25', x: 180, y: 20, width: 180, height: 26, confidence: 0.9, imageIndex: 0 },
    { text: '草莓酸奶', x: 10, y: 20, width: 120, height: 26, confidence: 0.92, imageIndex: 1 },
    { text: '到期 2026-11-25', x: 180, y: 20, width: 180, height: 26, confidence: 0.93, imageIndex: 1 }
  ], { height: 600, width: 600 });
  assert.equal(result.records.length, 1);
  assert.equal(result.records[0].expiry, '2026-11-25');
});
