import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const root = new URL('../', import.meta.url);
const read = path => readFile(new URL(path, root), 'utf8');

test('Android app is versioned 1.5.2 and includes camera capture plus WorkManager', async () => {
  const gradle = await read('android/app/build.gradle');
  assert.match(gradle, /versionCode\s+15/);
  assert.match(gradle, /versionName\s+'1\.5\.2'/);
  assert.match(gradle, /androidx\.work:work-runtime:2\.11\.2/);
});

test('Android bridge updates native status and navigation bars from the selected theme', async () => {
  const activity = await read('android/app/src/main/java/com/shelfie/expiry/MainActivity.java');
  const js = await read('www/app.js');
  assert.match(activity, /public void setSystemBars\(String statusHex, String navigationHex\)/);
  assert.match(activity, /setStatusBarColor\(status\)/);
  assert.match(activity, /setNavigationBarColor\(navigation\)/);
  assert.match(js, /window\.ShelfieNative\?\.setSystemBars/);
  assert.match(js, /blue:\{page:'#e8f3f9',status:'#e8f3f9',navigation:'#fbfeff'\}/);
});

test('assistant and user profiles include a local avatar library and editable display names', async () => {
  const html = await read('www/index.html');
  const js = await read('www/app.js');
  assert.match(html, /id="assistantNameInput"/);
  assert.match(html, /id="assistantNicknameInput"/);
  assert.match(html, /id="userNameInput"/);
  assert.match(html, /id="avatarUploadInput"[^>]*multiple/);
  assert.match(js, /indexedDB\.open\(AVATAR_DB_NAME,1\)/);
  assert.match(js, /async function handleAvatarUpload/);
  assert.match(js, /function randomAssistantAvatar/);
  assert.match(js, /function saveAssistantProfile/);
  assert.match(js, /function saveUserProfile/);
  assert.match(js, /assistantAvatarId/);
  assert.match(js, /userAvatarId/);
});

test('chat composer plus and sheet close buttons use precise centered alignment', async () => {
  const css = await read('www/styles.css');
  const html = await read('www/index.html');
  assert.match(css, /\.composer-plus\{display:grid;place-items:center/);
  assert.match(css, /\.close-button\{display:grid;place-items:center/);
  assert.match(html, /id=\"composerAdd\"[^>]*>\s*<svg/);
});

test('Android manifest declares notification permission and reschedule receiver', async () => {
  const manifest = await read('android/app/src/main/AndroidManifest.xml');
  assert.match(manifest, /android\.permission\.POST_NOTIFICATIONS/);
  assert.match(manifest, /android\.permission\.RECEIVE_BOOT_COMPLETED/);
  assert.match(manifest, /ReminderRescheduleReceiver/);
});

test('SQLite schema stores core item fields and uses a transaction', async () => {
  const db = await read('android/app/src/main/java/com/shelfie/expiry/ShelfieDatabase.java');
  for (const column of ['manufacture', 'shelf_life', 'expiry', 'opened_date', 'after_opening_value', 'reminder_days', 'effective_expiry', 'reminder_date']) {
    assert.ok(db.includes(column), `missing SQLite column ${column}`);
  }
  assert.match(db, /beginTransaction\(\)/);
  assert.match(db, /setTransactionSuccessful\(\)/);
  assert.match(db, /endTransaction\(\)/);
});

test('native bridge exposes SQLite read/write and notification permission methods', async () => {
  const activity = await read('android/app/src/main/java/com/shelfie/expiry/MainActivity.java');
  assert.match(activity, /public String getItemsJson\(\)/);
  assert.match(activity, /public boolean saveItemsJson\(String rawJson\)/);
  assert.match(activity, /public boolean areNotificationsEnabled\(\)/);
  assert.match(activity, /public void requestNotificationPermission\(\)/);
});

test('reminders use unique WorkManager jobs and a local 09:00 trigger target', async () => {
  const scheduler = await read('android/app/src/main/java/com/shelfie/expiry/ShelfieReminderScheduler.java');
  assert.match(scheduler, /set\(Calendar\.HOUR_OF_DAY, 9\)/);
  assert.match(scheduler, /enqueueUniqueWork/);
  assert.match(scheduler, /ExistingWorkPolicy\.REPLACE/);
  assert.match(scheduler, /cancelUniqueWork/);
});

test('WebView uses SQLite bridge on Android and keeps localStorage for browser preview/migration', async () => {
  const js = await read('www/app.js');
  assert.match(js, /ShelfieNative\.getItemsJson/);
  assert.match(js, /ShelfieNative\.saveItemsJson/);
  assert.match(js, /One-time migration/);
  assert.match(js, /localStorage\.setItem\(STORAGE_KEY/);
});


test('Android API key vault uses Android Keystore AES-GCM and exposes secure bridge methods', async () => {
  const vault = await read('android/app/src/main/java/com/shelfie/expiry/ApiKeyVault.java');
  const activity = await read('android/app/src/main/java/com/shelfie/expiry/MainActivity.java');
  assert.match(vault, /AndroidKeyStore/);
  assert.match(vault, /AES\/GCM\/NoPadding/);
  assert.match(vault, /setRandomizedEncryptionRequired\(true\)/);
  assert.match(activity, /public boolean saveApiKey\(String value\)/);
  assert.match(activity, /public String getSavedApiKey\(\)/);
  assert.match(activity, /public boolean clearApiKey\(\)/);
  assert.match(activity, /MediaStore\.ACTION_IMAGE_CAPTURE/);
  assert.match(activity, /FileProvider\.getUriForFile/);
});

test('AI update/delete proposals are validated against item IDs and require confirmation UI', async () => {
  const js = await read('www/app.js');
  const html = await read('www/index.html');
  assert.match(js, /prepareAiMutation/);
  assert.match(js, /createAiMutationCard/);
  assert.match(js, /确认修改/);
  assert.match(js, /确认删除/);
  assert.match(html, /id="reminderManager"/);
});

test('Android API key is not written into the persisted API config object', async () => {
  const js = await read('www/app.js');
  const saveFunction = js.slice(js.indexOf('function saveApiConfig()'), js.indexOf('function effectiveApiKey()'));
  assert.doesNotMatch(saveFunction, /apiKey\s*:/);
  assert.match(saveFunction, /ShelfieNative\.saveApiKey/);
  assert.match(js, /delete config\.apiKey/);
});


test('Reminder center exposes per-item lead-time controls and a reschedule action', async () => {
  const html = await read('www/index.html');
  const js = await read('www/app.js');
  assert.match(html, /id="reminderManagerSummary"/);
  assert.match(html, /id="refreshReminderSchedule"/);
  assert.match(js, /data-reminder-days/);
  assert.match(js, /updateReminderDays/);
  assert.match(js, /ShelfieNative\.refreshReminders/);
});


test('camera capture avoids package-visibility preflight and cleans private cache files', async () => {
  const activity = await read('android/app/src/main/java/com/shelfie/expiry/MainActivity.java');
  assert.doesNotMatch(activity, /camera\.resolveActivity\(/);
  assert.match(activity, /lastSelectedCameraFile/);
  assert.match(activity, /pendingCameraFile\.delete\(\)/);
});


test('Android includes bundled on-device ML Kit barcode scanning without a network permission', async () => {
  const gradle = await read('android/app/build.gradle');
  const activity = await read('android/app/src/main/java/com/shelfie/expiry/MainActivity.java');
  const manifest = await read('android/app/src/main/AndroidManifest.xml');
  assert.match(gradle, /com\.google\.mlkit:barcode-scanning:17\.3\.0/);
  assert.match(activity, /BarcodeScanning\.getClient/);
  assert.match(activity, /InputImage\.fromBitmap/);
  assert.match(activity, /public void scanBarcodes\(String requestId, String imageDataUrl\)/);
  assert.match(activity, /deliverBarcodeResult/);
  assert.match(manifest, /uses-permission android:name="android.permission.INTERNET"/);
  assert.doesNotMatch(activity, /new URL\(.*barcode/i);
});

test('Android system backup excludes device-bound Keystore ciphertext but keeps app backup enabled', async () => {
  const manifest = await read('android/app/src/main/AndroidManifest.xml');
  const legacyRules = await read('android/app/src/main/res/xml/backup_rules.xml');
  const modernRules = await read('android/app/src/main/res/xml/data_extraction_rules.xml');
  assert.match(manifest, /android:allowBackup=\"true\"/);
  assert.match(manifest, /android:fullBackupContent=\"@xml\/backup_rules\"/);
  assert.match(manifest, /android:dataExtractionRules=\"@xml\/data_extraction_rules\"/);
  assert.match(legacyRules, /domain=\"sharedpref\" path=\"shelfie_secure_secrets\.xml\"/);
  assert.match(modernRules, /cloud-backup>[\s\S]*shelfie_secure_secrets\.xml/);
  assert.match(modernRules, /device-transfer>[\s\S]*shelfie_secure_secrets\.xml/);
});

test('Android CI build uses a persistent private signing key while keeping the installed debug package ID stable', async () => {
  const gradle = await read('android/app/build.gradle');
  assert.match(gradle, /applicationIdSuffix '\.debug'/);
  assert.match(gradle, /SHELFIE_KEYSTORE_PATH/);
  assert.match(gradle, /signingConfig signingConfigs\.shelfieUpload/);
  const workflow = await read('.github/workflows/build-apk.yml');
  for (const secret of ['SHELFIE_KEYSTORE_BASE64', 'SHELFIE_KEYSTORE_PASSWORD']) {
    assert.ok(workflow.includes(secret), `missing signing secret ${secret}`);
  }
  assert.match(workflow, /shiqi_android_v15_chat_avatar_polish\.zip/);
  assert.match(workflow, /unzip -q shiqi_android_v15_chat_avatar_polish\.zip -d source/);
  assert.match(workflow, /softprops\/action-gh-release@v3/);
  assert.match(workflow, /buildFeatures/);
  assert.match(workflow, /build-tools\/35\.0\.0/);
  assert.match(workflow, /apksigner/);
  assert.match(workflow, /make_latest: true/);
});

test('Android native updater checks the official latest release and uses a user-confirmed APK installer', async () => {
  const activity = await read('android/app/src/main/java/com/shelfie/expiry/MainActivity.java');
  const manifest = await read('android/app/src/main/AndroidManifest.xml');
  const paths = await read('android/app/src/main/res/xml/file_paths.xml');
  assert.match(activity, /public String getAppVersion\(\)/);
  assert.match(activity, /repos\/xtzhdhl\/shelfie-android\/releases\/latest/);
  assert.match(activity, /public void downloadAndInstallUpdate/);
  assert.match(activity, /isTrustedReleaseDownload/);
  assert.match(activity, /application\/vnd\.android\.package-archive/);
  assert.match(activity, /hasSameSigningCertificate/);
  assert.match(activity, /signature_mismatch/);
  assert.match(manifest, /android\.permission\.REQUEST_INSTALL_PACKAGES/);
  assert.match(paths, /name="app_updates" path="updates\/"/);
});

test('settings UI includes manual and automatic update checking plus full encrypted backup', async () => {
  const html = await read('www/index.html');
  const js = await read('www/app.js');
  assert.match(html, /id="checkUpdatesButton"/);
  assert.match(html, /id="installUpdateButton"/);
  assert.match(js, /checkAppUpdates\(true\)/);
  assert.match(js, /encryptBackupPayload/);
  assert.match(js, /decryptBackupPayload/);
  assert.match(js, /apiKey:key/);
  assert.match(js, /avatars:Array\.isArray\(avatars\)\?avatars:\[\]/);
});
