const EXPIRY_MARKERS = /到期|有效期|截止|失效|过期|食用期限|保质期至|exp(?:iry)?|best\s*before|use\s*by|bb\b/i;
const MANUFACTURE_MARKERS = /生产日期|制造日期|出厂日期|生产时间|mfg|mfd|manufactur(?:ed|e)?\s*date/i;
const NAME_HEADERS = /^(?:物品名称|商品名称|产品名称|物品名|商品名|名称|物品|商品|产品|品名|item(?:\s*name)?|product(?:\s*name)?)$/i;
const CATEGORY_HEADERS = /^(?:物品种类|商品种类|产品种类|物品类别|商品类别|产品类别|物品分类|商品分类|产品分类|类别|分类|品类|种类|类型|category|type)$/i;
const EXPIRY_HEADERS = /^(?:到期日期|到期日|到期|过期日期|过期日|失效日期|有效日期|有效期至|有效期|保质期至|保质期|截止日期|expiry(?:\s*date)?|expiration(?:\s*date)?|best\s*before|use\s*by)$/i;
const MANUFACTURE_HEADERS = /^(?:生产日期|制造日期|出厂日期|生产时间|manufacture(?:d)?\s*date|mfg|mfd)$/i;
const GENERIC_DATE_HEADERS = /^(?:日期|相关日期|到期时间|时间|date)$/i;
const META_LINE = /^(?:物品|商品|产品|名称|日期|到期日期|有效期|保质期|生产日期|序号|数量|备注|剩余|天数|分类|批次|清单|库存|提醒|expiry|expiration|name|item|product|qty|quantity|mfg|mfd|exp)$/i;
const DATE_PATTERNS = [
  { regex: /(?:^|[^\d])(20\d{2})\s*[年./-]\s*(\d{1,2})\s*[月./-]\s*(\d{1,2})\s*日?(?!\d)/g, kind: 'ymd' },
  { regex: /(?:^|[^\d])(20\d{2})(\d{2})(\d{2})(?!\d)/g, kind: 'compact' },
  { regex: /(?:^|[^\d])(\d{1,2})\s*[./-]\s*(\d{1,2})\s*[./-]\s*(20\d{2})(?!\d)/g, kind: 'dmy' }
];
const CATEGORY_VALUES = [
  { pattern: /^(?:食品饮料|食品|食物|饮料|零食|生鲜|乳制品|粮油|烘焙|宠物食品|食品类|饮料类|食品及饮料)$/i, value: '食品饮料' },
  { pattern: /^(?:护肤美妆|护肤|美妆|化妆品|个护|个人护理|护肤品类|美妆类)$/i, value: '护肤美妆' },
  { pattern: /^(?:药品保健|药品|药物|保健品|医疗用品|药品类|保健品类)$/i, value: '药品保健' },
  { pattern: /^(?:日用百货|日用品|日用|清洁用品|家居用品|生活用品|日用品类|家居类)$/i, value: '日用百货' },
  { pattern: /^(?:其他|其它|未分类)$/i, value: '其他' }
];

function pad2(value) { return String(value).padStart(2, '0'); }
function validDate(year, month, day) {
  if (!Number.isInteger(year) || year < 2000 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) return '';
  const date = new Date(Date.UTC(year, month - 1, day));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) return '';
  return `${year}-${pad2(month)}-${pad2(day)}`;
}

export function parseOcrDateTokens(text) {
  const source = String(text || '');
  const found = [];
  for (const pattern of DATE_PATTERNS) {
    pattern.regex.lastIndex = 0;
    let match;
    while ((match = pattern.regex.exec(source))) {
      let year, month, day;
      if (pattern.kind === 'ymd' || pattern.kind === 'compact') [, year, month, day] = match;
      else {
        const first = Number(match[1]), second = Number(match[2]);
        year = match[3];
        if (first <= 12 && second <= 12) continue;
        if (first > 12) { day = first; month = second; }
        else { month = first; day = second; }
      }
      const iso = validDate(Number(year), Number(month), Number(day));
      if (!iso) continue;
      const offset = Math.max(0, match[0].search(/[0-9]/));
      const full = match[0].slice(offset);
      const start = match.index + offset;
      found.push({ date: iso, raw: full, start, end: start + full.length });
    }
  }
  found.sort((a, b) => a.start - b.start || a.end - b.end);
  return found.filter((entry, index, all) => !all.slice(0, index).some(prev => prev.date === entry.date && Math.abs(prev.start - entry.start) < 3));
}

function lineBox(line) {
  const box = line?.box || line || {};
  const x = Number(box.x ?? box.left ?? 0) || 0;
  const y = Number(box.y ?? box.top ?? 0) || 0;
  const width = Number(box.width ?? (Number(box.right) - x) ?? 0) || 0;
  const height = Number(box.height ?? (Number(box.bottom) - y) ?? 0) || 0;
  return { x, y, width: Math.max(0, width), height: Math.max(0, height) };
}
function hasChinese(text) { return /[\u3400-\u9fff]/.test(String(text || '')); }
function rectOverlap(a, b) {
  const left = Math.max(a.x, b.x), right = Math.min(a.x + a.width, b.x + b.width);
  const top = Math.max(a.y, b.y), bottom = Math.min(a.y + a.height, b.y + b.height);
  const intersection = Math.max(0, right - left) * Math.max(0, bottom - top);
  const area = Math.max(1, Math.min(a.width * a.height, b.width * b.height));
  return intersection / area;
}
function normalizeLines(input) {
  const lines = Array.isArray(input) ? input : [];
  const cleaned = lines.map((line, index) => ({
    text: String(line?.text || '').replace(/\s+/g, ' ').trim(),
    confidence: Number.isFinite(Number(line?.confidence)) ? Number(line?.confidence) : 0.65,
    imageIndex: Number.isInteger(line?.imageIndex) ? line.imageIndex : 0,
    script: String(line?.script || ''),
    index,
    ...lineBox(line)
  })).filter(line => line.text);
  const unique = [];
  for (const line of cleaned) {
    const duplicateIndex = unique.findIndex(prev => prev.imageIndex === line.imageIndex && (
      prev.text.toLowerCase() === line.text.toLowerCase() &&
      Math.abs((prev.y + prev.height / 2) - (line.y + line.height / 2)) <= Math.max(12, line.height, prev.height)
    ));
    if (duplicateIndex < 0) {
      const spatialIndex = unique.findIndex(prev => prev.imageIndex === line.imageIndex
        && rectOverlap(prev, line) >= 0.62
        && Math.abs((prev.y + prev.height / 2) - (line.y + line.height / 2)) <= Math.max(10, line.height * 0.65, prev.height * 0.65));
      if (spatialIndex < 0) unique.push(line);
      else {
        const previous = unique[spatialIndex];
        const previousChinese = hasChinese(previous.text), currentChinese = hasChinese(line.text);
        // The Chinese recognizer is preferred for CJK text; Latin recognizer is preferred only
        // when the competing text is numeric/ASCII-only (e.g. an EXP date).
        const replace = (currentChinese && !previousChinese)
          || (currentChinese === previousChinese && line.confidence > previous.confidence);
        if (replace) unique[spatialIndex] = line;
      }
    } else if (line.confidence > unique[duplicateIndex].confidence) unique[duplicateIndex] = line;
  }
  return unique;
}
function tidyName(value) {
  return String(value || '')
    .replace(/20\d{2}\s*[年./-]\s*\d{1,2}\s*[月./-]\s*\d{1,2}\s*日?/g, ' ')
    .replace(/\b20\d{6}\b/g, ' ')
    .replace(/\b(?:\d{1,2})[./-](?:\d{1,2})[./-]20\d{2}\b/g, ' ')
    .replace(/\b(?:EXP(?:IRY)?|MFG|MFD|BEST\s*BEFORE|USE\s*BY)\b/gi, ' ')
    .replace(/生产日期|制造日期|出厂日期|生产时间|到期日期|有效期至|有效期|保质期至|保质期|截止日期|截止|过期日期|expiry|expiration|date/gi, ' ')
    .replace(/[：:：|｜,，;；·•\-—_\s]+/g, ' ')
    .trim();
}
function normalizeCategory(value) {
  const text = String(value || '').replace(/[：:|｜,，;；\s]/g, '').trim();
  if (!text) return '';
  const match = CATEGORY_VALUES.find(entry => entry.pattern.test(text));
  return match?.value || '';
}
function isCategoryText(text) {
  const value = String(text || '').replace(/[：:|｜,，;；\s]/g, '').trim();
  return CATEGORY_VALUES.some(entry => entry.pattern.test(value))
    || /^(?:食品类|饮料类|日用品类|护肤品类|药品类|美妆类|家居类|个人护理类|母婴类|宠物类|服饰类|数码类|清洁类)$/.test(value)
    || /^[\u3400-\u9fff]{2,8}类$/.test(value);
}
function isHeader(text) {
  const value = String(text || '').replace(/[：:：\s]/g, '').trim();
  return NAME_HEADERS.test(value) || CATEGORY_HEADERS.test(value) || EXPIRY_HEADERS.test(value)
    || MANUFACTURE_HEADERS.test(value) || GENERIC_DATE_HEADERS.test(value) || META_LINE.test(value);
}
function looksLikeProductName(text) {
  const value = tidyName(text);
  if (value.length < 2 || value.length > 48 || META_LINE.test(value) || isCategoryText(value) || isHeader(value)) return false;
  if (/^(?:\d+[号#]?|第?\d+项)$/.test(value)) return false;
  if (/(?:到期|有效期|生产日期|保质期|EXP|MFG|MFD|剩余\s*\d+)/i.test(value)) return false;
  return /[\p{L}]/u.test(value);
}
function categoryFor(name) {
  const value = String(name || '');
  if (/牛奶|酸奶|饮料|食品|面包|麦片|燕麦|零食|果汁|饼干|罐头|咖啡|茶|粮油|宠物粮/.test(value)) return '食品饮料';
  if (/面霜|精华|护肤|口红|洗面奶|乳液|防晒|化妆/.test(value)) return '护肤美妆';
  if (/药|维生素|胶囊|片剂|药膏/.test(value)) return '药品保健';
  if (/洗衣|清洁|纸巾|洗涤|洗洁精|消毒/.test(value)) return '日用百货';
  return '其他';
}
function getLabelType(text, token, headerType = '') {
  const around = `${text.slice(Math.max(0, token.start - 18), token.start)} ${text.slice(token.end, token.end + 10)}`;
  if (MANUFACTURE_MARKERS.test(around) || (headerType === 'manufacture' && !EXPIRY_MARKERS.test(around))) return 'manufacture';
  if (EXPIRY_MARKERS.test(around) || EXPIRY_MARKERS.test(text) || headerType === 'expiry') return 'expiry';
  return 'unknown';
}
function extractInlineName(text, token) {
  const before = tidyName(text.slice(0, token.start));
  const after = tidyName(text.slice(token.end));
  const beforeName = removeCategoryWords(before);
  const afterName = removeCategoryWords(after);
  if (looksLikeProductName(beforeName)) return beforeName;
  if (looksLikeProductName(afterName)) return afterName;
  return '';
}
function removeCategoryWords(value) {
  let result = String(value || '');
  for (const entry of CATEGORY_VALUES) {
    // Only remove whole category labels, never arbitrary substrings of a product name.
    if (entry.pattern.test(result.replace(/[\s：:]/g, ''))) return '';
  }
  result = result.replace(/(?:食品饮料|护肤美妆|药品保健|日用百货|食品类|饮料类|日用品类|护肤品类|药品类|美妆类|家居类|个人护理类|母婴类|宠物类|服饰类|数码类|清洁类)/g, ' ');
  return result.replace(/[：:|｜,，;；\s]+/g, ' ').trim();
}
function closestProductName(dateLine, allLines, imageHeight, imageWidth) {
  const candidates = allLines.filter(line => line.imageIndex === dateLine.imageIndex
    && line !== dateLine && parseOcrDateTokens(line.text).length === 0 && looksLikeProductName(line.text));
  const maxDistance = Math.max(100, imageHeight * 0.055, dateLine.height * 6);
  let best = null;
  for (const candidate of candidates) {
    const dy = Math.abs((candidate.y + candidate.height / 2) - (dateLine.y + dateLine.height / 2));
    if (dy > maxDistance) continue;
    const overlap = Math.max(0, Math.min(dateLine.x + dateLine.width, candidate.x + candidate.width) - Math.max(dateLine.x, candidate.x));
    const minWidth = Math.max(1, Math.min(dateLine.width || 1, candidate.width || 1));
    const sameColumnBonus = overlap / minWidth;
    const dateCenterX = dateLine.x + dateLine.width / 2;
    const candidateCenterX = candidate.x + candidate.width / 2;
    const dx = Math.abs(dateCenterX - candidateCenterX);
    const horizontalPenalty = dx / Math.max(160, imageWidth * 0.5);
    const score = dy / Math.max(18, (dateLine.height + candidate.height) / 2) + horizontalPenalty * 0.9 - sameColumnBonus * 0.35;
    if (!best || score < best.score) best = { name: tidyName(candidate.text), score, line: candidate };
  }
  return best?.name || '';
}
function classifyHeader(text) {
  const value = String(text || '').replace(/[：:：\s]/g, '').trim();
  if (NAME_HEADERS.test(value)) return 'name';
  if (CATEGORY_HEADERS.test(value)) return 'category';
  if (MANUFACTURE_HEADERS.test(value)) return 'manufacture';
  if (EXPIRY_HEADERS.test(value)) return 'expiry';
  if (GENERIC_DATE_HEADERS.test(value)) return 'date';
  return '';
}
function groupRowsByY(lines, multiplier = 1.25) {
  const sorted = [...lines].sort((a, b) => (a.y + a.height / 2) - (b.y + b.height / 2));
  const groups = [];
  for (const line of sorted) {
    const center = line.y + line.height / 2;
    const threshold = Math.max(9, line.height * multiplier);
    let group = groups.find(entry => Math.abs(entry.center - center) <= Math.max(threshold, entry.maxHeight * multiplier));
    if (!group) {
      group = { center, maxHeight: line.height, lines: [] };
      groups.push(group);
    }
    group.lines.push(line);
    group.center = group.lines.reduce((sum, item) => sum + item.y + item.height / 2, 0) / group.lines.length;
    group.maxHeight = Math.max(group.maxHeight, line.height);
  }
  return groups.sort((a, b) => a.center - b.center);
}
function detectTableHeader(lines) {
  const rows = groupRowsByY(lines, 1.05);
  let best = null;
  for (const row of rows) {
    const headers = row.lines.map(line => ({ line, type: classifyHeader(line.text) })).filter(item => item.type);
    const types = new Set(headers.map(item => item.type));
    const hasName = types.has('name');
    const hasCategory = types.has('category');
    const hasDate = types.has('expiry') || types.has('manufacture') || types.has('date');
    if (hasName && hasDate && (!best || headers.length > best.headers.length)) best = { row, headers };
  }
  return best;
}
function extractTableRecords(lines, dimensions, header) {
  const headers = header.headers.map(({ line, type }) => ({ type, centerX: line.x + line.width / 2, y: line.y + line.height / 2 }));
  headers.sort((a, b) => a.centerX - b.centerX);
  const boundaries = headers.map((item, index) => ({
    ...item,
    left: index === 0 ? -Infinity : (headers[index - 1].centerX + item.centerX) / 2,
    right: index === headers.length - 1 ? Infinity : (item.centerX + headers[index + 1].centerX) / 2
  }));
  const nameColumn = boundaries.find(item => item.type === 'name');
  const categoryColumn = boundaries.find(item => item.type === 'category');
  const expiryColumn = boundaries.find(item => item.type === 'expiry' || item.type === 'date');
  const manufactureColumn = boundaries.find(item => item.type === 'manufacture');
  const tableLines = lines.filter(line => line.imageIndex === header.row.lines[0].imageIndex
    && (line.y + line.height / 2) > header.row.center + header.row.maxHeight * 0.35
    && !classifyHeader(line.text));
  const rowGroups = groupRowsByY(tableLines, 1.35);
  const records = [];
  const warnings = [];

  for (const row of rowGroups) {
    const inColumn = column => column ? row.lines.filter(line => {
      const x = line.x + line.width / 2;
      return x >= column.left && x < column.right;
    }) : [];
    const nameLines = inColumn(nameColumn).filter(line => parseOcrDateTokens(line.text).length === 0 && looksLikeProductName(line.text));
    const categoryLines = inColumn(categoryColumn);
    const dateLines = [...new Set([...inColumn(expiryColumn), ...inColumn(manufactureColumn)])];
    const name = removeCategoryWords(nameLines.map(line => tidyName(line.text)).filter(Boolean).join(' ')).trim();
    const categoryRaw = categoryLines.map(line => line.text).join(' ');
    const explicitCategory = normalizeCategory(categoryRaw);
    const dateValues = [];
    for (const line of dateLines) {
      for (const token of parseOcrDateTokens(line.text)) {
        const column = inColumn(manufactureColumn).includes(line) ? 'manufacture' : 'expiry';
        const type = getLabelType(line.text, token, column);
        dateValues.push({ token, type, line });
      }
    }
    if (!dateValues.length) continue;
    if (!looksLikeProductName(name)) {
      warnings.push(`表格第 ${records.length + 1} 行识别到了日期，但物品名称列无法可靠读取。请核对原图。`);
      continue;
    }
    const record = {
      id: `ocr-table-${records.length + 1}`,
      name,
      category: explicitCategory || categoryFor(name),
      expiry: '',
      manufacture: '',
      confidence: Math.min(...[...nameLines, ...dateLines].map(line => line.confidence)),
      sourceLines: [...new Set(row.lines.map(line => line.text))],
      warnings: []
    };
    if (categoryRaw && !explicitCategory) record.warnings.push(`类别栏识别为“${categoryRaw}”，未能映射到拾期分类，请手动选择。`);
    for (const entry of dateValues) {
      let field = entry.type;
      if (field === 'unknown') field = 'expiry';
      if (record[field] && record[field] !== entry.token.date) {
        record[field] = '';
        record.warnings.push(`${field === 'expiry' ? '到期日期' : '生产日期'}出现多个不同值，请手动核对。`);
      } else if (!record.warnings.some(w => w.includes('出现多个不同值'))) {
        record[field] = entry.token.date;
      }
      if (entry.type === 'unknown') record.warnings.push('日期列未明确标注生产或到期，已暂列为到期日期，请核对。');
    }
    record.sourceText = record.sourceLines.join(' / ');
    record.selected = Boolean(record.expiry && record.confidence >= 0.72);
    if (record.confidence < 0.72) record.warnings.push('文字置信度偏低，已取消默认勾选，请对照原图核对名称和日期。');
    record.warnings = [...new Set(record.warnings)];
    records.push(record);
  }
  return { records, warnings, columns: boundaries.map(item => item.type) };
}

function extractProximityRecords(lines, imageHeight, imageWidth) {
  const groups = new Map();
  const warnings = [];
  for (const line of lines) {
    const tokens = parseOcrDateTokens(line.text);
    if (!tokens.length) continue;
    for (const token of tokens) {
      const type = getLabelType(line.text, token);
      const inlineName = extractInlineName(line.text, token);
      const name = inlineName || closestProductName(line, lines, imageHeight, imageWidth);
      if (!name || isCategoryText(name)) {
        warnings.push(`未能为日期 ${token.date} 找到明确的物品名称，请在原图中核对。`);
        continue;
      }
      const key = `${line.imageIndex}:${name.toLocaleLowerCase()}`;
      if (!groups.has(key)) groups.set(key, {
        id: `ocr-${groups.size + 1}`,
        name,
        category: categoryFor(name),
        expiry: '',
        manufacture: '',
        confidence: line.confidence,
        sourceLines: [line.text],
        warnings: []
      });
      const record = groups.get(key);
      record.confidence = Math.min(record.confidence, line.confidence);
      if (!record.sourceLines.includes(line.text)) record.sourceLines.push(line.text);
      const field = type === 'manufacture' ? 'manufacture' : 'expiry';
      if (type === 'unknown') record.warnings.push('截图没有明确标注这是生产日期还是到期日期，暂按到期日期整理，请核对。');
      if (record[field] && record[field] !== token.date) {
        record[field] = '';
        record.warnings.push(`${field === 'expiry' ? '到期日期' : '生产日期'}出现多个不同值，请手动核对。`);
      } else if (!record.warnings.some(w => w.includes('出现多个不同值'))) {
        record[field] = token.date;
      }
    }
  }
  const records = [...groups.values()].map(record => ({
    ...record,
    sourceText: record.sourceLines.join(' / '),
    selected: Boolean(record.name && record.expiry && record.confidence >= 0.72),
    warnings: [...new Set([...record.warnings, ...(record.confidence < 0.72 ? ['文字置信度偏低，已取消默认勾选，请对照原图核对名称和日期。'] : [])])]
  }));
  return { records, warnings };
}

export function extractExpiryRecords(ocrLines, dimensions = {}) {
  const lines = normalizeLines(ocrLines);
  const imageHeight = Number(dimensions.height) || Math.max(1, ...lines.map(line => line.y + line.height));
  const imageWidth = Number(dimensions.width) || Math.max(1, ...lines.map(line => line.x + line.width));
  const imageIndexes = [...new Set(lines.map(line => line.imageIndex))];
  const records = [];
  const warnings = [];
  let usedTable = false;
  let usedProximity = false;

  // Parse each selected screenshot independently. A header detected in screenshot 1
  // must never cause screenshot 2..6 to be ignored or interpreted with the wrong columns.
  for (const imageIndex of imageIndexes) {
    const imageLines = lines.filter(line => line.imageIndex === imageIndex);
    const header = detectTableHeader(imageLines);
    if (header) {
      const table = extractTableRecords(imageLines, dimensions, header);
      if (table.records.length) {
        records.push(...table.records);
        warnings.push(...table.warnings);
        usedTable = true;
        continue;
      }
    }
    const fallback = extractProximityRecords(imageLines, imageHeight, imageWidth);
    records.push(...fallback.records);
    warnings.push(...fallback.warnings);
    usedProximity = true;
  }

  const deduplicated = new Map();
  for (const record of records) {
    const key = `${record.name.toLocaleLowerCase()}|${record.expiry}|${record.manufacture}`;
    if (!deduplicated.has(key)) deduplicated.set(key, record);
    else {
      const previous = deduplicated.get(key);
      previous.sourceText = [...new Set([previous.sourceText, record.sourceText].filter(Boolean))].join(' / ');
      previous.warnings = [...new Set([...previous.warnings, ...record.warnings])];
      previous.confidence = Math.min(previous.confidence, record.confidence);
      if (previous.confidence < 0.72) {
        previous.selected = false;
        previous.warnings = [...new Set([...previous.warnings, '合并后的文字置信度偏低，已取消默认勾选，请对照原图核对。'])];
      }
    }
  }
  const finalRecords = [...deduplicated.values()].map((record, index) => ({ ...record, id: `ocr-${index + 1}` }));
  return {
    records: finalRecords,
    rawText: lines.map(line => line.text).join('\n'),
    lineCount: lines.length,
    layout: usedTable && usedProximity ? 'mixed' : usedTable ? 'table' : 'proximity',
    warnings: [...new Set(warnings)]
  };
}
