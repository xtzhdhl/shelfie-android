import test from 'node:test';
import assert from 'node:assert/strict';
import { parseOcrDateTokens, extractExpiryRecords } from '../www/ocr-import.js';

test('OCR date parser accepts year-first ISO, Chinese and compact dates', () => {
  assert.deepEqual(parseOcrDateTokens('EXP 2026/11/28'), [{ date: '2026-11-28', raw: '2026/11/28', start: 4, end: 14 }]);
  assert.equal(parseOcrDateTokens('到期日：2026年12月5日')[0].date, '2026-12-05');
  assert.equal(parseOcrDateTokens('有效期至 20261208')[0].date, '2026-12-08');
});

test('OCR date parser rejects impossible and ambiguous dates', () => {
  assert.equal(parseOcrDateTokens('2026-02-30').length, 0);
  assert.equal(parseOcrDateTokens('01/02/2027').length, 0);
});

test('OCR pairs same-row product names with expiry dates', () => {
  const result = extractExpiryRecords([
    { text: '燕麦牛奶', x: 40, y: 100, width: 180, height: 32, confidence: 0.96 },
    { text: '到期 2026-11-28', x: 330, y: 101, width: 220, height: 32, confidence: 0.94 }
  ], { height: 600 });
  assert.equal(result.records.length, 1);
  assert.equal(result.records[0].name, '燕麦牛奶');
  assert.equal(result.records[0].expiry, '2026-11-28');
  assert.equal(result.records[0].category, '食品饮料');
});

test('OCR pairs vertically adjacent product and date rows', () => {
  const result = extractExpiryRecords([
    { text: '草莓酸奶', x: 40, y: 100, width: 180, height: 30, confidence: 0.91 },
    { text: '有效期至 2026年11月25日', x: 40, y: 138, width: 300, height: 30, confidence: 0.93 }
  ], { height: 900 });
  assert.equal(result.records[0].name, '草莓酸奶');
  assert.equal(result.records[0].expiry, '2026-11-25');
});

test('OCR retains production date separately from expiry date', () => {
  const result = extractExpiryRecords([
    { text: '洗面奶', x: 30, y: 50, width: 150, height: 28, confidence: 0.9 },
    { text: '生产日期 2026-11-01', x: 30, y: 82, width: 260, height: 28, confidence: 0.9 },
    { text: '有效期至 2027-11-01', x: 30, y: 114, width: 260, height: 28, confidence: 0.9 }
  ], { height: 600 });
  assert.equal(result.records.length, 1);
  assert.equal(result.records[0].manufacture, '2026-11-01');
  assert.equal(result.records[0].expiry, '2027-11-01');
});

test('OCR extracts manufacture and expiry dates from one line without mixing them', () => {
  const result = extractExpiryRecords([
    { text: '燕麦牛奶 生产日期 2026-11-01 有效期至 2027-11-01', x: 12, y: 24, width: 560, height: 34, confidence: 0.95 }
  ], { height: 600, width: 600 });
  assert.equal(result.records.length, 1);
  assert.equal(result.records[0].name, '燕麦牛奶');
  assert.equal(result.records[0].manufacture, '2026-11-01');
  assert.equal(result.records[0].expiry, '2027-11-01');
});

test('OCR de-duplicates an identical item/date repeated in two screenshots', () => {
  const result = extractExpiryRecords([
    { text: '草莓酸奶', x: 10, y: 20, width: 120, height: 26, confidence: 0.9, imageIndex: 0 },
    { text: '到期 2026-11-25', x: 180, y: 20, width: 180, height: 26, confidence: 0.9, imageIndex: 0 },
    { text: '草莓酸奶', x: 10, y: 20, width: 120, height: 26, confidence: 0.92, imageIndex: 1 },
    { text: '到期 2026-11-25', x: 180, y: 20, width: 180, height: 26, confidence: 0.93, imageIndex: 1 }
  ], { height: 600, width: 600 });
  assert.equal(result.records.length, 1);
  assert.equal(result.records[0].expiry, '2026-11-25');
});

test('table headers map item name, category and expiry columns instead of mistaking category for name', () => {
  const result = extractExpiryRecords([
    { text: '物品名称', x: 20, y: 20, width: 100, height: 24, confidence: 0.96 },
    { text: '物品种类', x: 190, y: 20, width: 100, height: 24, confidence: 0.95 },
    { text: '到期日期', x: 390, y: 20, width: 100, height: 24, confidence: 0.97 },
    { text: '维生素C', x: 20, y: 65, width: 110, height: 26, confidence: 0.91 },
    { text: '药品保健', x: 190, y: 65, width: 100, height: 26, confidence: 0.94 },
    { text: '2026-12-15', x: 390, y: 65, width: 130, height: 26, confidence: 0.98 },
    { text: '燕麦牛奶', x: 20, y: 112, width: 110, height: 26, confidence: 0.93 },
    { text: '食品饮料', x: 190, y: 112, width: 100, height: 26, confidence: 0.95 },
    { text: '2026-12-20', x: 390, y: 112, width: 130, height: 26, confidence: 0.98 }
  ], { width: 600, height: 300 });

  assert.equal(result.layout, 'table');
  assert.equal(result.records.length, 2);
  assert.equal(result.records[0].name, '维生素C');
  assert.equal(result.records[0].category, '药品保健');
  assert.equal(result.records[0].expiry, '2026-12-15');
  assert.equal(result.records[1].name, '燕麦牛奶');
  assert.equal(result.records[1].category, '食品饮料');
  assert.equal(result.records[1].expiry, '2026-12-20');
});

test('category values are never used as product names in proximity fallback', () => {
  const result = extractExpiryRecords([
    { text: '食品饮料', x: 30, y: 100, width: 120, height: 28, confidence: 0.96 },
    { text: '燕麦牛奶', x: 185, y: 100, width: 130, height: 28, confidence: 0.94 },
    { text: '到期日期 2026-12-28', x: 390, y: 101, width: 180, height: 28, confidence: 0.95 }
  ], { width: 640, height: 400 });
  assert.equal(result.records.length, 1);
  assert.equal(result.records[0].name, '燕麦牛奶');
  assert.notEqual(result.records[0].name, '食品饮料');
});

test('table layout keeps manufacture and expiry columns separate', () => {
  const result = extractExpiryRecords([
    { text: '商品名称', x: 20, y: 20, width: 100, height: 22, confidence: 0.95 },
    { text: '类别', x: 170, y: 20, width: 70, height: 22, confidence: 0.95 },
    { text: '生产日期', x: 300, y: 20, width: 100, height: 22, confidence: 0.95 },
    { text: '有效期至', x: 470, y: 20, width: 100, height: 22, confidence: 0.95 },
    { text: '洗面奶', x: 20, y: 70, width: 100, height: 24, confidence: 0.94 },
    { text: '护肤美妆', x: 170, y: 70, width: 90, height: 24, confidence: 0.92 },
    { text: '2026-11-01', x: 300, y: 70, width: 120, height: 24, confidence: 0.98 },
    { text: '2027-11-01', x: 470, y: 70, width: 120, height: 24, confidence: 0.98 }
  ], { width: 640, height: 300 });
  assert.equal(result.layout, 'table');
  assert.equal(result.records.length, 1);
  assert.equal(result.records[0].name, '洗面奶');
  assert.equal(result.records[0].category, '护肤美妆');
  assert.equal(result.records[0].manufacture, '2026-11-01');
  assert.equal(result.records[0].expiry, '2027-11-01');
});

test('OCR accepts alternate Chinese table headers used by inventory screenshots', () => {
  const result = extractExpiryRecords([
    { text: '物品名', x: 15, y: 15, width: 90, height: 22, confidence: 0.95 },
    { text: '类别', x: 170, y: 15, width: 60, height: 22, confidence: 0.95 },
    { text: '到期日', x: 340, y: 15, width: 80, height: 22, confidence: 0.95 },
    { text: '叶黄素', x: 15, y: 60, width: 85, height: 24, confidence: 0.96 },
    { text: '保健品类', x: 170, y: 60, width: 100, height: 24, confidence: 0.96 },
    { text: '2027-01-12', x: 340, y: 60, width: 120, height: 24, confidence: 0.98 }
  ], { width: 520, height: 260 });
  assert.equal(result.layout, 'table');
  assert.equal(result.records.length, 1);
  assert.equal(result.records[0].name, '叶黄素');
  assert.equal(result.records[0].category, '药品保健');
  assert.equal(result.records[0].expiry, '2027-01-12');
});

test('each screenshot in a multi-image import gets its own table header mapping', () => {
  const result = extractExpiryRecords([
    { text: '物品名称', x: 20, y: 20, width: 100, height: 24, confidence: 0.96, imageIndex: 0 },
    { text: '物品种类', x: 190, y: 20, width: 100, height: 24, confidence: 0.95, imageIndex: 0 },
    { text: '到期日期', x: 390, y: 20, width: 100, height: 24, confidence: 0.97, imageIndex: 0 },
    { text: '维生素C', x: 20, y: 65, width: 110, height: 26, confidence: 0.91, imageIndex: 0 },
    { text: '药品保健', x: 190, y: 65, width: 100, height: 26, confidence: 0.94, imageIndex: 0 },
    { text: '2026-12-15', x: 390, y: 65, width: 130, height: 26, confidence: 0.98, imageIndex: 0 },
    { text: '商品名称', x: 25, y: 18, width: 100, height: 24, confidence: 0.96, imageIndex: 1 },
    { text: '类别', x: 195, y: 18, width: 70, height: 24, confidence: 0.95, imageIndex: 1 },
    { text: '有效期', x: 395, y: 18, width: 90, height: 24, confidence: 0.97, imageIndex: 1 },
    { text: '燕麦牛奶', x: 25, y: 63, width: 110, height: 26, confidence: 0.93, imageIndex: 1 },
    { text: '食品饮料', x: 195, y: 63, width: 100, height: 26, confidence: 0.95, imageIndex: 1 },
    { text: '2026-12-20', x: 395, y: 63, width: 130, height: 26, confidence: 0.98, imageIndex: 1 }
  ], { width: 600, height: 300 });

  assert.equal(result.layout, 'table');
  assert.equal(result.records.length, 2);
  assert.equal(result.records[0].name, '维生素C');
  assert.equal(result.records[1].name, '燕麦牛奶');
  assert.equal(result.records[1].category, '食品饮料');
});
