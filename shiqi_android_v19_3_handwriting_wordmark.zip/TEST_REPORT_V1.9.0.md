# SHELFIE V1.9.0 自动化测试报告

- Node.js test suite: **103 passed, 0 failed**
- JavaScript syntax: `www/app.js`、`www/ocr-import.js` 均通过 `node --check`
- OCR table parsing: 物品名称／类别／到期日期三列解析通过
- OCR alternate headers: `物品名`、`类别`、`到期日` 等表头解析通过
- OCR multi-image: 每张截图独立检测表头和列布局通过
- OCR category filtering: 类别字段不会误填为物品名称通过
- OCR date parsing: 生产日期与到期日期分列、同一行双日期解析通过
- OCR proximity fallback: 无表头截图的文字位置配对回归通过
- Low-confidence handling: 低置信度候选不默认勾选
- Android WebView assets: `www` 与 `android/app/src/main/assets/www` 同步，无不一致
- Android XML: 全部 XML 文件解析通过
- Android Gradle version: `1.9.0` / `versionCode 19`
- Fixed signing config: 沿用现有 V1.4 起的固定 JKS 配置
- ZIP: 压缩包完整性检查通过

## OCR 识别限制

本版本没有更换 ML Kit 中文识别模型。改进集中在截图输入保真、低置信度的增强识别复核、表格列解析、类别字段隔离、多截图独立表头映射和人工校对保护。若模型本身将中文名称中的字稳定误识为其他字，仍不能保证自动纠错正确；必须保留原始 OCR 文本和人工编辑，最好使用用户实际截图继续校准。

## 尚未完成

当前执行环境没有 Android SDK/Gradle 可执行环境，因此尚未在这里实际构建 APK。GitHub Actions 构建及 OnePlus 12 真机截图识别仍需验证。
