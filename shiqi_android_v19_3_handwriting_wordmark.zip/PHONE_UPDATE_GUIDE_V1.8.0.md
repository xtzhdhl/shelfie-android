# 手机端更新拾期 V1.8.0

1. 下载本轮提供的 `shiqi_android_v18_local_ocr_batch_import.zip`。
2. 打开 GitHub 仓库桌面版网站，在仓库根目录使用 Add file → Upload files 上传该 ZIP。
3. 编辑 `.github/workflows/build-apk.yml`，使用本轮提供的完整 V1.8.0 工作流内容替换原内容并 Commit changes。
4. 打开 Actions，运行 `Build and Publish SHELFIE V1.8.0`，分支选 `main`。
5. 确认自动测试、签名指纹验证、APK Artifact 上传和 GitHub Release 发布全部成功。
6. 在 V1.7 安装版中尝试通过应用内更新下载 V1.8；若暂时走 Actions 下载，必须使用同一固定签名。若 Android 提示签名不一致，取消安装，不要卸载旧版。
7. 安装后打开小助手快捷入口的「截图批量导入」，选取截图进行本机 OCR；识别结果先编辑核对，确认后才保存。

本轮不会要求用户重新设置两个 GitHub Secrets；继续使用 `SHELFIE_KEYSTORE_BASE64` 和 `SHELFIE_KEYSTORE_PASSWORD`。
