# SHELFIE V1.9.3 检查报告

## 变更
- 启动标题在 HTML 中明确包含「拾」「期」两个独立文本节点，彻底移除 SVG clipPath 字符遮罩。
- 主标题、中文标语、英文小字及底部小字统一使用离线内嵌的小赖手写字体。
- 两个汉字依次轻弹显现；字体加载完成后再启动动效；系统减少动态效果时显示静态完整字标。
- 构建时下载固定版本的小赖字体，验证 SHA-256，子集化为 WOFF2，重命名字体族并同步到 Android WebView 资源。字体 SIL OFL 1.1 许可文本随资源一起打包。
- 保留 `com.shelfie.expiry.debug`、versionCode 22、固定签名密钥及个人数据。

## 本地验证
- Node 自动化测试：108 项通过，0 项失败。
- JavaScript 语法检查：通过（`app.js`、`ocr-import.js`）。
- Android XML 资源解析：通过。
- Web 与 Android WebView 的 HTML/CSS/JS 资源同步：通过。
- 字体构建脚本 Bash 语法检查：通过。

## 仍需 CI / 真机验证
- 字体二进制下载、SHA-256、WOFF2 子集化及实际字形渲染将在 GitHub Actions 构建中验证。
- Android APK 构建、固定证书和包名校验由现有唯一 workflow 验证。
- OnePlus 12 真机启动画面需安装 V1.9.3 后验收。
