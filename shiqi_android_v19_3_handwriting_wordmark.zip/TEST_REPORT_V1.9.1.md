# SHELFIE V1.9.1 自动化测试报告

## 本次变更
- 更新 Android 与 PWA 桌面图标为柔雾蔷薇日历收纳图形。
- 新增轻量启动页：图标淡入，手写笔迹依次绘出「拾期」，完成后轻柔回弹并淡出进入首页。
- 支持系统减少动态效果设置。
- 保持 `com.shelfie.expiry.debug`、versionCode 20 与原固定签名配置。

## 验证
- `npm test`：107 项通过，0 项失败。
- `node --check www/app.js` 与 `node --check www/ocr-import.js` 均通过。
- `www/` 与 `android/app/src/main/assets/www/` 已同步；Android 图标的五档密度 PNG 尺寸均已核验。
- Android APK 编译及真机安装验收由 GitHub Actions / OnePlus 12 完成。
