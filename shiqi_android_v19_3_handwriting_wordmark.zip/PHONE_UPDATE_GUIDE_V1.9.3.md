# 拾期 V1.9.3 手机更新说明

1. 在 GitHub 仓库根目录上传 `shiqi_android_v19_3_handwriting_wordmark.zip` 并提交到 `main`。
2. 维护者会更新唯一的 `.github/workflows/build-apk.yml`，加入离线手写字体准备步骤。
3. Actions 自动执行字体下载与 SHA-256 校验、WOFF2 子集化、108 项自动化测试、Android APK 构建、固定证书签名校验与 Release 发布。
4. 构建成功后，从 GitHub Release 下载 `shelfie-v1.9.3.apk` 并直接覆盖安装。不要卸载旧版，也不要清除应用数据。

包名保持 `com.shelfie.expiry.debug`，版本号 `1.9.3 / 22`，固定签名不变。
