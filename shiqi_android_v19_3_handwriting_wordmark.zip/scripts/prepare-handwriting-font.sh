#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FONT_DIR="$ROOT/www/assets/fonts"
ANDROID_FONT_DIR="$ROOT/android/app/src/main/assets/www/assets/fonts"
TMP_DIR="${RUNNER_TEMP:-${TMPDIR:-/tmp}}/shelfie-handwriting"
FONT_URL="https://github.com/lxgw/kose-font/releases/download/v3.126/Xiaolai-Regular.ttf"
LICENSE_URL="https://raw.githubusercontent.com/lxgw/kose-font/v3.126/OFL.txt"
EXPECTED_SHA256="e2f68daf0e72777a8cf58bc83de1b98634b251e537ddbfca24b0ae50d1802da2"
mkdir -p "$FONT_DIR" "$ANDROID_FONT_DIR" "$TMP_DIR"
curl --fail --location --silent --show-error --retry 3 "$FONT_URL" -o "$TMP_DIR/Xiaolai-Regular.ttf"
printf '%s  %s\n' "$EXPECTED_SHA256" "$TMP_DIR/Xiaolai-Regular.ttf" | sha256sum --check --status
curl --fail --location --silent --show-error --retry 3 "$LICENSE_URL" -o "$FONT_DIR/OFL-Xiaolai.txt"
python3 -m venv "$TMP_DIR/venv"
FONT_PYTHON="$TMP_DIR/venv/bin/python"
"$FONT_PYTHON" -m pip install --disable-pip-version-check --quiet fonttools brotli
cat > "$TMP_DIR/required-text.txt" <<'FONT_TEXT'
拾期
把容易忘记的日期，交给拾期记着。
A LITTLE EXPIRY COMPANION
SHELFIE · EST. FOR EVERYDAY
FONT_TEXT
"$FONT_PYTHON" -m fontTools.subset "$TMP_DIR/Xiaolai-Regular.ttf" \
  --output-file="$FONT_DIR/shelfie-handwriting.woff2" \
  --flavor=woff2 \
  --text-file="$TMP_DIR/required-text.txt" \
  --layout-features='*' \
  --name-IDs='*' \
  --name-languages='*' \
  --notdef-glyph \
  --notdef-outline \
  --recommended-glyphs
"$FONT_PYTHON" - "$FONT_DIR/shelfie-handwriting.woff2" <<'PYRENAME'
import sys
from fontTools.ttLib import TTFont
path = sys.argv[1]
font = TTFont(path)
replacements = {1:'Shelfie Handwriting',2:'Regular',3:'Shelfie Handwriting 1.0',4:'Shelfie Handwriting Regular',6:'ShelfieHandwriting-Regular',16:'Shelfie Handwriting',17:'Regular'}
for record in font['name'].names:
    if record.nameID in replacements:
        record.string = replacements[record.nameID].encode(record.getEncoding(), errors='replace')
font.save(path)
needed = set('拾期把容易忘记的日期，交给记着。A LITTLE EXPIRY COMPANIONSHELFIE·EST.FOREVERYDAY')
cmap = set()
for table in font['cmap'].tables:
    if table.isUnicode(): cmap.update(table.cmap)
missing = sorted(ch for ch in needed if ord(ch) not in cmap)
if missing: raise SystemExit('Missing glyphs: ' + ''.join(missing))
print(f'Embedded handwriting font prepared; {len(needed)} distinct characters verified.')
PYRENAME
cp "$FONT_DIR/shelfie-handwriting.woff2" "$ANDROID_FONT_DIR/shelfie-handwriting.woff2"
cp "$FONT_DIR/OFL-Xiaolai.txt" "$ANDROID_FONT_DIR/OFL-Xiaolai.txt"
test -s "$FONT_DIR/shelfie-handwriting.woff2"
test -s "$ANDROID_FONT_DIR/shelfie-handwriting.woff2"
cmp -s "$FONT_DIR/shelfie-handwriting.woff2" "$ANDROID_FONT_DIR/shelfie-handwriting.woff2"
