# Third-party notices

## Xiaolai / 小赖字体

- Upstream: https://github.com/lxgw/kose-font
- Pinned release: v3.126 (`Xiaolai-Regular.ttf`)
- License: SIL Open Font License 1.1
- The build workflow subsets the upstream font to the Chinese and Latin glyphs used on the splash screen, renames the subset family to `Shelfie Handwriting`, and embeds it locally for offline Android WebView use.
- The full OFL license text is copied into `www/assets/fonts/OFL-Xiaolai.txt` and the packaged Android WebView assets at build time.
