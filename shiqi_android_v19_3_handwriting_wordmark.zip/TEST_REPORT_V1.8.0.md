# V1.8.0 自动化测试报告

## 结果

- Node.js 自动化测试：98/98 通过，0 失败。
- JavaScript 语法检查：`app.js`、`photo-recognition.js`、`product-lookup.js`、`ai-mutations.js`、`date-utils.js`、`backup-utils.js`、`ocr-import.js` 全部通过。
- AndroidManifest XML 解析通过。
- HTML ID 检查：160 个 ID，未发现重复。
- Web 与 Android assets：8 个关键文件逐字节同步。
- GitHub Actions YAML 解析通过。

## OCR 覆盖点

- 中文日期、ISO/斜线日期、紧凑日期提取。
- 非法日历日期与有歧义的日/月/年格式拒绝自动采用。
- 同行和相邻行商品名称/到期日配对。
- 生产日期与到期日期分离。
- 同行出现生产日和到期日时分别提取。
- 多张截图重复商品/日期去重。
- 结果必须经过编辑/勾选/人工确认才进入物品清单。
- OCR 调用本机 Android bridge，不调用聊天 API。

## 未完成的设备验收

当前执行环境没有可用 Android SDK/Gradle 安装，未在本环境编译 APK。需通过用户 GitHub Actions 工作流构建签名 APK，再在 OnePlus 12 上验收相册多选、中文 OCR 精度、日期配对、截图内存占用及批量保存。
