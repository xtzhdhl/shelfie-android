# 拾期 SHELFIE V1.8.0

## 新增：本机离线 OCR 截图批量导入

- 新增「截图批量导入」入口，可一次选择最多 6 张截图。
- 集成 Google ML Kit Text Recognition v2 中文与 Latin bundled 模型；模型随 APK 提供，OCR 本身不依赖网络或用户配置的 AI API。
- Android 原生 OCR bridge 在内存中解码图片并返回识别文字、行坐标、置信度和图像尺寸；图片不写入物品记录或备份，也不上传到 AI/API 服务。
- 本地规则解析 ISO、斜线、点分隔、中文年月日和 YYYYMMDD 日期。
- 按“到期、有效期、截止、EXP、Best before”等标记识别到期日；按“生产日期、MFG/MFD”等标记识别生产日期。
- 结合文字行位置、同一行信息与相邻行关系，将名称与日期整理为候选记录。
- 支持多个截图间相同物品/相同日期去重；日期冲突时清空冲突字段并提示用户核对。
- 所有结果先进入可编辑草稿，只有用户勾选并确认后才批量写入 SQLite。

## Android 版本与兼容性

- versionName：1.8.0
- versionCode：18
- applicationId：com.shelfie.expiry（Debug 安装包后缀为 `.debug`）
- 沿用 V1.4 起的固定 JKS 签名配置与两个 GitHub Repository Secrets。
- 保持既有本机数据库、Keystore API Key、头像库、昵称和主题设置的应用身份不变；正常同签名覆盖升级不需要卸载。

## 注意事项

OCR 是文字读取而非视觉理解。复杂表格、多列布局、模糊小字、拍摄倾斜、手写内容、无标签日期或名称/日期距离过远时可能无法正确配对。未知日期含义会提示核对，批量保存前必须由用户检查。自动化测试通过不代表已完成 OnePlus 12 真机识别效果验收。
