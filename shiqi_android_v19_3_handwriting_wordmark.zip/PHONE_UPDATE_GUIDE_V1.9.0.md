# 拾期 V1.9.0 手机端更新步骤

1. 上传 `shiqi_android_v19_ocr_table_parser.zip` 到 GitHub 仓库根目录。
2. 打开 `.github/workflows/build-apk.yml`，全部替换为本版本提供的完整 YAML。
3. Commit changes。
4. 打开 Actions，手动运行 `Build and Publish SHELFIE V1.9.0`。
5. 确认自动化测试、APK 构建、签名指纹比对、Artifact 上传和 Release 发布全部成功。
6. 从拾期设置页检查更新并覆盖安装；不要卸载旧版。

本版保持 `com.shelfie.expiry.debug` 包名、versionCode 19，并使用既有 `SHELFIE_KEYSTORE_BASE64` 与 `SHELFIE_KEYSTORE_PASSWORD` Secrets。若签名校验失败或系统提示签名不一致，取消安装并保留旧版数据。
