# 拾期 V1.9.5 手机更新说明

1. 上传 `shiqi_android_v19_5_bouncy_wordmark.zip` 到 GitHub 仓库根目录并提交。
2. 由维护流程更新现有唯一的 `.github/workflows/build-apk.yml`，不要创建重复工作流。
3. Actions 自动运行测试、手写字体校验、资源同步、APK 构建和固定签名验证，并发布 `shelfie-v1.9.5.apk`。

包名保持 `com.shelfie.expiry.debug`，版本号 `1.9.5 / 24`，固定签名不变。升级无需卸载，不会因正常覆盖升级清空 SQLite、API Key、头像库和偏好设置。
