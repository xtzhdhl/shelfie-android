# 拾期 SHELFIE V1.9.5 检查报告

## 自动化检查
- `npm test`：108 项通过，0 项失败。
- JavaScript 语法检查：`app.js`、`photo-recognition.js`、`product-lookup.js`、`ai-mutations.js`、`date-utils.js`、`backup-utils.js`、`ocr-import.js` 全部通过。
- Android WebView 资源镜像：`index.html`、`styles.css`、`app.js`、`sw.js` 与 `www/` 源文件逐字节一致。
- 应用版本：`1.9.5 / 24`。
- 安装身份：`com.shelfie.expiry.debug`、固定签名 alias `shelfie-upload`，保持不变。
- PWA 缓存键：`shelfie-cache-v11`，避免旧启动页样式缓存。

## 启动页动画目标
- 主标题为两个真实文本字「拾」「期」，沿用已经验收的小赖离线手写字体；不改变字形、字体和颜色。
- 「拾」先起跳，「期」稍后跟上，形成轻微错峰和连贯节奏。
- 每个字经历轻微蓄力、弹起、落地压缩和两次幅度递减的回弹，使用轻微旋转、拉伸与压缩表现弹性。
- 标语、英文副标题和底部品牌字样只做轻柔淡入，不与主标题争抢注意力。
- `prefers-reduced-motion: reduce` 下关闭全部动画并直接显示完整文字。

## 尚待验证
- 本地环境未执行字体下载与 WOFF2 子集化；GitHub Actions 会下载固定版本字体、核对 SHA-256、子集化并检查 Android/Web 资源一致。
- 本地未重新执行 Android Gradle APK 编译；请由 GitHub Actions 构建及签名验证。
- 尚未在 OnePlus 12 真机上验收最终弹跳手感，需安装 CI 发布 APK 实际确认。
