# 首批 AI 视觉资产目录

- `moon-mascot.png`：月相沙漏精灵主角插画
- `moon-mascot-smile.png`：微笑状态，用于空状态
- `hourglass.png`：沙漏时间装饰
- `calendar.png`：日期记录装饰
- `jar.png`：收纳罐 / 通用物品
- `milk.png`：食品饮料
- `serum.png`：护肤品
- `medicine.png`：药品保健
- `food-box.png`：食物收纳盒
- `cream.png`：日用品 / 护理用品
- `mini-fridge.png`：冰箱 / 冷藏场景
- `bell.png`：提醒装饰
- `leaves.png`：自然装饰
- `tag.png`：物品标签
- `organizer.png`：收纳场景
- `search.png`：查找装饰

`ai-icon-sheet.png` 保存原始整张图，便于后续重新切图。正式 UI 的中文文字、数字、日期和表单控件由代码绘制，AI 图片只承担插画与装饰，不把乱码文字烧录进图片。
