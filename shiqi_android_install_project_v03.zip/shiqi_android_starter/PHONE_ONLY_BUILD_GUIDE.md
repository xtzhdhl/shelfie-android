# 拾期 SHELFIE：只有安卓手机时获取 APK

本方案使用 GitHub 云端编译，不需要在手机安装 Android Studio、Java 或 Android SDK。

## 1. 上传工程 ZIP 到 GitHub
1. 用手机浏览器打开 https://github.com 并登录/注册。
2. 点右上角 `+` → `New repository`，仓库名填写 `shelfie-android`，设为 `Private`，创建仓库。
3. 在仓库页面选择 `Add file` → `Upload files`，上传本项目 ZIP 文件 `shiqi_android_install_project_v03.zip`。上传 ZIP 本身不会触发构建，下一步需要用 Codespaces 解压并提交工程文件。

## 2. 打开云端 Codespaces
1. 仓库页面点绿色 `Code` → `Codespaces` → `Create codespace on main`。
2. 等待云端 VS Code 页面加载。
3. 打开 `Terminal` → `New Terminal`，复制粘贴以下命令（假设 ZIP 文件位于仓库根目录）：

```bash
unzip -o shiqi_android_install_project_v03.zip
cp -a shiqi_android_starter/. .
rm -rf shiqi_android_starter shiqi_android_install_project_v03.zip
```

4. 提交并推送：

```bash
git add -A
git commit -m "Add SHELFIE Android project"
git push
```

## 3. 云端编译并下载 APK
1. 回到 GitHub 仓库 → `Actions`。
2. 选择 `Build SHELFIE Android APK` 工作流。
3. 若没有自动运行，点击 `Run workflow` → `Run workflow`。
4. 等待工作流显示绿色成功勾号。
5. 打开成功的运行记录，页面底部 `Artifacts` 下载 `shiqi-debug-apk`。
6. 下载 ZIP 并解压，里面的 `app-debug.apk` 即安装包。
7. 在手机文件管理器中点击 APK；若提示权限，在系统设置允许当前文件管理器“安装未知应用”，然后继续安装。

## 说明
- GitHub/Codespaces 可能有额度或账户验证要求；界面名称可能随版本略有变化。
- 该包是 Debug APK，适合个人试装，不是 Play 商店发布包。
- 若 Actions 失败，请打开失败步骤，复制错误日志发回给助手协助排查。
- 此版本暂未实现系统到期通知，记录数据保存在应用本地；卸载或清除应用数据会丢失记录，建议定期导出 JSON 备份。
