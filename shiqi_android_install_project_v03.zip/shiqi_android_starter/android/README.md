# 拾期 SHELFIE Android 安装包工程（V0.3）

这是一个 Android Studio 可打开的原生 WebView 工程，已将当前 `www/` 前端完整复制进应用 assets。它不是已经编译的 APK。

## 构建环境
- Android Studio（推荐 Ladybug 或更新版本）
- JDK 17
- Android SDK Platform 35 与 Build Tools 35.x
- 首次 Gradle Sync 需要网络下载 Android Gradle Plugin 8.7.3 和 AndroidX WebKit 1.12.1

## 生成可安装 Debug APK
1. 解压整个项目 ZIP。
2. 用 Android Studio 打开 `android/` 文件夹。
3. 等待 Gradle Sync 完成；若提示安装 Android SDK Platform 35 / Build Tools 35，点击安装。
4. 选择菜单 **Build → Build Bundle(s) / APK(s) → Build APK(s)**。
5. APK 输出位置：`android/app/build/outputs/apk/debug/app-debug.apk`。
6. 将 `app-debug.apk` 传到 Android 手机，允许该来源安装应用后点击安装。

也可以双击项目根目录的 `打包APK-Windows.bat`；它会运行 Gradle 构建并把 APK 复制到项目根目录。Linux/macOS 可在 `android/` 目录运行 `./gradlew assembleDebug`。

## 本版包含
- 原生 Android 启动入口、应用图标、启动状态栏配色。
- WebViewAssetLoader 使用 HTTPS 虚拟域名加载本地页面，支持 ES Modules 与相对资源。
- WebView DOM Storage：现有记录/主题保存于应用 WebView 本地存储。卸载 App 或清除 App 数据会删除这些记录。
- 系统文件选择器导入 JSON 备份。
- 系统“另存为”窗口导出 JSON 备份。
- 无网络权限；应用页面与图片均随 APK 离线打包。

## 尚未完成（请勿误认为已支持）
- Android 系统级定时通知。
- SQLite 数据库（此版暂用 WebView localStorage）。
- 相机 OCR、条码扫描、日历与统计页面。
- Release 签名与商店发布。

## 不方便安装 Android Studio 时：GitHub Actions 自动构建
项目包含 `.github/workflows/android-debug-apk.yml`。将整个项目上传到自己的 GitHub 仓库后，在仓库 Actions 页面运行 **Build SHELFIE Android APK** 工作流，成功后从 Artifacts 下载 `shiqi-debug-apk`，解压即可得到 `app-debug.apk`。该方式仍需要你自己的 GitHub 账号和上传操作。

## 当前构建状态
本开发容器没有 Android SDK / Gradle，并且不能访问 Google Maven/Android 下载站，所以未在此处编译或验证 APK。Android Studio 首次构建会下载所需构建组件。
