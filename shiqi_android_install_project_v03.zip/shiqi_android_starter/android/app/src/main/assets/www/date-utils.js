/** Date-only helpers. Noon-local parsing avoids DST midnight edge cases. */
export function localDate(date) {
  const y=date.getFullYear(),m=String(date.getMonth()+1).padStart(2,'0'),d=String(date.getDate()).padStart(2,'0');
  return `${y}-${m}-${d}`;
}
export function parseDate(value) {
  if(!/^\d{4}-\d{2}-\d{2}$/.test(value||'')) return null;
  const [y,m,d]=value.split('-').map(Number);
  const date=new Date(y,m-1,d,12,0,0,0);
  return date.getFullYear()===y && date.getMonth()===m-1 && date.getDate()===d ? date : null;
}
export function diffDays(value, today=new Date()) {
  const target=parseDate(value); if(!target) return null;
  const current=new Date(today.getFullYear(),today.getMonth(),today.getDate(),12);
  return Math.round((target-current)/86400000);
}
export function addShelfLife(dateValue, amount, unit) {
  const d=parseDate(dateValue), n=Number(amount);
  if(!d||!Number.isInteger(n)||n<1||!['days','months','years'].includes(unit)) return '';
  if(unit==='days') d.setDate(d.getDate()+n);
  else {
    const originalDay=d.getDate(), originalMonth=d.getMonth();
    d.setDate(1);
    if(unit==='months') d.setMonth(d.getMonth()+n);
    else d.setFullYear(d.getFullYear()+n);
    const lastDay=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();
    d.setDate(Math.min(originalDay,lastDay));
    // Explicitly retain the original month for year arithmetic (including leap-day clamping).
    if(unit==='years' && d.getMonth()!==originalMonth) d.setMonth(originalMonth,1);
  }
  return localDate(d);
}
