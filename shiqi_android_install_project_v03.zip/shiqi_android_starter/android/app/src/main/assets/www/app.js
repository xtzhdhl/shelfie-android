const STORAGE_KEY='shelfie_items_v1';
const THEME_KEY='shelfie_theme_v1';
const $=(id)=>document.getElementById(id);
const newId=()=>globalThis.crypto?.randomUUID?.()||`item-${Date.now()}-${Math.random().toString(36).slice(2,9)}`;
const icons={
  '食品饮料':'milk.png','护肤美妆':'serum.png','药品保健':'medicine.png','日用百货':'cream.png','其他':'jar.png'
};
let items=loadItems();
let currentFilter='all';
let searchQuery='';
let toastTimer;

function loadItems(){try{return JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]')}catch{return []}}
function saveItems(){localStorage.setItem(STORAGE_KEY,JSON.stringify(items))}
import {localDate,parseDate,diffDays,addShelfLife} from './date-utils.js';
function statusOf(item){const d=diffDays(item.expiry);if(d<0)return {kind:'expired',count:`${Math.abs(d)}天`,label:'已过期'};if(d===0)return {kind:'today',count:'今天',label:'到期日'};if(d<=7)return {kind:'soon',count:`${d}天`,label:'即将到期'};if(d<=30)return {kind:'month',count:`${d}天`,label:'30 天内'};return {kind:'safe',count:`${d}天`,label:'剩余时间'}}
function fmtDate(value){if(!value)return '未填写';const d=parseDate(value);return `${d.getFullYear()}.${String(d.getMonth()+1).padStart(2,'0')}.${String(d.getDate()).padStart(2,'0')}`}
function showToast(message){const t=$('toast');t.textContent=message;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),2200)}
function escapeHtml(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function render(){
  const counts={total:items.length,soon:0,expired:0};
  items.forEach(i=>{const s=statusOf(i);if(s.kind==='soon'||s.kind==='today')counts.soon++;if(s.kind==='expired')counts.expired++});
  $('totalCount').textContent=counts.total;$('soonCount').textContent=counts.soon;$('expiredCount').textContent=counts.expired;
  const filtered=items.filter(i=>{
    const s=statusOf(i);const matchFilter=currentFilter==='all'||(currentFilter==='soon'&&(s.kind==='soon'||s.kind==='today'))||(currentFilter==='month'&&(s.kind==='soon'||s.kind==='today'||s.kind==='month'))||(currentFilter==='expired'&&s.kind==='expired');
    const q=searchQuery.trim().toLowerCase();const matchQuery=!q||i.name.toLowerCase().includes(q)||i.category.toLowerCase().includes(q)||(i.location||'').toLowerCase().includes(q);
    return matchFilter&&matchQuery;
  }).sort((a,b)=>a.expiry.localeCompare(b.expiry));
  $('visibleCount').textContent=filtered.length;
  $('inventoryList').innerHTML=filtered.map(item=>{
    const s=statusOf(item),icon=icons[item.category]||'jar.png';
    return `<article class="item-card" data-open-item="${item.id}" tabindex="0" role="button" aria-label="查看${escapeHtml(item.name)}详情"><div class="item-art"><img src="assets/${icon}" alt="" /></div><div class="item-main"><div class="item-title-row"><span class="item-title">${escapeHtml(item.name)}</span><span class="category-label">${escapeHtml(item.category)}</span></div><div class="item-meta">到期 ${fmtDate(item.expiry)} · ${item.quantity||1} 件<span class="item-location">${escapeHtml(item.location||'尚未设置存放位置')}</span></div></div><div class="item-status status-${s.kind}"><strong class="status-count">${s.count}</strong><span class="status-label">${s.label}</span></div></article>`;
  }).join('');
  $('emptyState').hidden=filtered.length!==0;
  $('inventoryList').style.display=filtered.length?'grid':'none';
}
function setFilter(filter){currentFilter=filter;document.querySelectorAll('.chip').forEach(c=>c.classList.toggle('active',c.dataset.filter===filter));render()}
function openModal(id){$(id).hidden=false;document.body.style.overflow='hidden'}
function closeModal(id){$(id).hidden=true;document.body.style.overflow=''}
function resetForm(){ $('itemForm').reset();$('editingId').value='';$('itemQuantity').value='1';$('modalTitle').textContent='添加一件物品';$('calculatedHint').textContent='填写生产日期和保质期，拾期会帮你计算到期日。';$('expiryDate').value=''; }
function startAdd(){resetForm();$('manufactureDate').value=localDate(new Date());openModal('itemModal')}
function editItem(id){const i=items.find(x=>x.id===id);if(!i)return;resetForm();$('editingId').value=i.id;$('modalTitle').textContent='编辑物品记录';$('itemName').value=i.name;$('itemCategory').value=i.category;$('itemQuantity').value=i.quantity||1;$('manufactureDate').value=i.manufacture||'';$('shelfLife').value=i.shelfLife||'';$('shelfUnit').value=i.shelfUnit||'days';$('expiryDate').value=i.expiry;$('itemLocation').value=i.location||'';$('reminderDays').value=String(i.reminderDays??7);$('itemNote').value=i.note||'';$('calculatedHint').textContent=`到期日期：${fmtDate(i.expiry)}。你可以直接修改日期。`;closeModal('detailModal');openModal('itemModal')}
function showDetails(id){const i=items.find(x=>x.id===id);if(!i)return;const s=statusOf(i);const icon=icons[i.category]||'jar.png';$('detailContent').innerHTML=`<div class="sheet-heading"><div><p class="eyebrow">ITEM DETAILS</p><h2 id="detailTitle">物品记录</h2></div><button class="close-button" data-close="detailModal">×</button></div><div class="detail-hero"><div class="item-art"><img src="assets/${icon}" alt="" /></div><div><h2>${escapeHtml(i.name)}</h2><p>${escapeHtml(i.category)} · ${i.quantity||1} 件</p></div></div><div class="detail-grid"><div class="detail-cell"><small>生产日期</small><strong>${fmtDate(i.manufacture)}</strong></div><div class="detail-cell"><small>到期日期</small><strong>${fmtDate(i.expiry)}</strong></div><div class="detail-cell"><small>保质期限</small><strong>${i.shelfLife?`${i.shelfLife}${i.shelfUnit==='days'?'天':i.shelfUnit==='months'?'个月':'年'}`:'未填写'}</strong></div><div class="detail-cell"><small>当前状态</small><strong>${s.label} · ${s.count}</strong></div><div class="detail-cell"><small>存放位置</small><strong>${escapeHtml(i.location||'未设置')}</strong></div><div class="detail-cell"><small>提前提醒</small><strong>${i.reminderDays>0?`提前 ${i.reminderDays} 天`:'关闭'}</strong></div></div><p class="detail-note">${i.note?escapeHtml(i.note):'还没有添加备注。'}</p><div class="detail-actions"><button class="danger-button" id="deleteCurrent">删除记录</button><button class="primary-button" id="editCurrent">编辑记录　↗</button></div>`;openModal('detailModal');$('deleteCurrent').onclick=()=>{items=items.filter(x=>x.id!==id);saveItems();closeModal('detailModal');render();showToast('这件物品已从清单移除')};$('editCurrent').onclick=()=>editItem(id)}
function applyTheme(theme){document.body.dataset.theme=theme;localStorage.setItem(THEME_KEY,theme);document.querySelectorAll('.theme-option').forEach(el=>el.classList.toggle('selected',el.dataset.themeChoice===theme));const colors={rose:'#f6dce4',blue:'#dceef7',cream:'#efe4d2'};document.querySelector('meta[name="theme-color"]').content=colors[theme]||colors.rose}
function exportData(){const payload={app:'SHELFIE',version:1,exportedAt:new Date().toISOString(),items};if(window.ShelfieNative?.exportBackup){window.ShelfieNative.exportBackup(JSON.stringify(payload,null,2));showToast('已打开系统保存窗口');return}const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`拾期备份-${localDate(new Date())}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);showToast('备份文件已导出')}
function importData(file){const r=new FileReader();r.onload=()=>{try{const parsed=JSON.parse(r.result);const incoming=Array.isArray(parsed)?parsed:parsed.items;if(!Array.isArray(incoming))throw new Error('bad');items=incoming.map(i=>({...i,id:i.id||newId()}));saveItems();render();showToast(`已导入 ${items.length} 条记录`)}catch{showToast('文件格式不正确，未能导入')}};r.readAsText(file)}

// Date calculation preview. Manual expiry edits are preserved until source dates change again.
let expiryWasManuallyEdited=false;
$('manufactureDate').addEventListener('change',()=>{expiryWasManuallyEdited=false;updateCalculatedExpiry()});$('shelfLife').addEventListener('input',()=>{expiryWasManuallyEdited=false;updateCalculatedExpiry()});$('shelfUnit').addEventListener('change',()=>{expiryWasManuallyEdited=false;updateCalculatedExpiry()});$('expiryDate').addEventListener('change',()=>{expiryWasManuallyEdited=true;$('calculatedHint').textContent='已使用你手动设置的到期日期。'})
function updateCalculatedExpiry(){const exp=addShelfLife($('manufactureDate').value,$('shelfLife').value,$('shelfUnit').value);if(exp&&!expiryWasManuallyEdited){$('expiryDate').value=exp;$('calculatedHint').textContent=`已根据生产日期和保质期计算：${fmtDate(exp)}。仍可手动修改。`}else if(!$('shelfLife').value){$('calculatedHint').textContent='填写生产日期和保质期，拾期会帮你计算到期日。'}}

$('itemForm').addEventListener('submit',e=>{e.preventDefault();const name=$('itemName').value.trim(),expiry=$('expiryDate').value;if(!name||!expiry){showToast('请填写物品名称和到期日期');return}const id=$('editingId').value||newId();const existing=items.find(x=>x.id===id);const item={id,name,category:$('itemCategory').value,quantity:Math.max(1,Number($('itemQuantity').value)||1),manufacture:$('manufactureDate').value,shelfLife:$('shelfLife').value?Number($('shelfLife').value):null,shelfUnit:$('shelfUnit').value,expiry,location:$('itemLocation').value.trim(),reminderDays:Number($('reminderDays').value),note:$('itemNote').value.trim(),createdAt:existing?.createdAt||new Date().toISOString()};if(existing)items=items.map(x=>x.id===id?item:x);else items.push(item);saveItems();closeModal('itemModal');render();showToast(existing?'记录已更新':'已加入你的物品清单')});
$('addItemButton').onclick=startAdd;$('emptyAddButton').onclick=startAdd;$('openThemes').onclick=()=>openModal('themesModal');
$('searchInput').addEventListener('input',e=>{searchQuery=e.target.value;render()});
document.querySelectorAll('.chip').forEach(c=>c.addEventListener('click',()=>setFilter(c.dataset.filter)));
document.querySelectorAll('.stat-card').forEach(c=>c.addEventListener('click',()=>{setFilter(c.dataset.filter);$('inventorySection').scrollIntoView({behavior:'smooth'})}));
$('focusExpiry').onclick=()=>{setFilter('soon');$('inventorySection').scrollIntoView({behavior:'smooth'})};
$('inventoryList').addEventListener('click',e=>{const card=e.target.closest('[data-open-item]');if(card)showDetails(card.dataset.openItem)});$('inventoryList').addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches('[data-open-item]')){e.preventDefault();showDetails(e.target.dataset.openItem)}});
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>closeModal(b.dataset.close)));document.querySelectorAll('.modal-backdrop').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)closeModal(m.id)}));
document.querySelectorAll('[data-theme-choice]').forEach(b=>b.addEventListener('click',()=>{applyTheme(b.dataset.themeChoice);showToast('主题已切换');setTimeout(()=>closeModal('themesModal'),180)}));
document.querySelectorAll('[data-nav]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-nav]').forEach(x=>x.classList.toggle('active',x===b));if(b.dataset.nav==='settings')openModal('themesModal');else if(b.dataset.nav==='collection')$('inventorySection').scrollIntoView({behavior:'smooth'});else if(b.dataset.nav==='calendar')showToast('日历视图将在下一阶段加入');else window.scrollTo({top:0,behavior:'smooth'})}));
$('filterButton').onclick=()=>showToast('可使用上方标签筛选临期和已过期物品');
$('exportBackup').onclick=exportData;$('importBackupButton').onclick=()=>$('importBackupFile').click();$('importBackupFile').addEventListener('change',e=>{const file=e.target.files?.[0];if(file)importData(file);e.target.value=''});
$('todayLabel').textContent=`TODAY · ${new Intl.DateTimeFormat('zh-CN',{year:'numeric',month:'long',day:'numeric',weekday:'short'}).format(new Date()).toUpperCase()}`;
applyTheme(localStorage.getItem(THEME_KEY)||'rose');render();

// Demo records are deliberately opt-in. Empty installs remain genuinely empty.

if('serviceWorker' in navigator && location.protocol.startsWith('http')){navigator.serviceWorker.register('./sw.js').catch(()=>{});}
