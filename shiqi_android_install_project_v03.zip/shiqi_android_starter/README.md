# 拾期 · SHELFIE

项目包含手机优先的保质期管理前端原型，以及可由 Android Studio 打开的 Android WebView 工程。当前交付是**可构建工程，不是已编译 APK**。

## 当前功能
- 三套主题：柔雾蔷薇、冰川蓝调、奶油手札
- 物品新增、编辑、删除、搜索、临期/过期筛选
- 生产日期 + 保质期限自动计算到期日期，支持手动修改
- 月末、闰年、跨年日期处理及 Node 自动化测试
- Android 系统文件选择器导入 JSON、系统“另存为”导出 JSON
- Android 工程内置完整离线页面、AI 图标素材、应用图标

## 安装 APK
请查看 [`android/README.md`](android/README.md)。使用 Android Studio 打开 `android/` 目录，完成首次 Gradle Sync 后执行 Build APK(s)。Debug APK 默认输出至 `android/app/build/outputs/apk/debug/app-debug.apk`。

## 重要限制
此版本先解决“能以独立 Android App 安装”的第一步。记录暂存于 WebView localStorage；还没有 SQLite、Android 系统定时通知、OCR、条码扫描或 Release 签名。卸载或清除应用数据会删除本地记录，请定期导出 JSON 备份。

## 验证
在项目根目录执行 `npm test`。当前日期计算测试 5/5 通过。当前执行环境没有 Android SDK/Gradle，并且无法访问 Android/Google Maven 下载源，因此未能在此环境编译 APK。
