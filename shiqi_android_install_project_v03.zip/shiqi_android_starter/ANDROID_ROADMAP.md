# 拾期 SHELFIE — Android 化实施路线（V0.2）

## 本阶段目标
先保证日期计算可靠，再把浏览器原型包装成 Android 应用；原型数据在 APK 内必须迁移到可靠的本地持久化，并实现真正的系统通知。

## 推荐技术组合
- **UI / 现有页面：** HTML、CSS、ES modules，继续沿用 `www/`。
- **Android 容器：** Capacitor Android；包名 `com.shelfie.expiry`。
- **数据库：** SQLite 原生插件（推荐 Capacitor SQLite 生态方案）；数据库是权威数据源，localStorage 仅作迁移入口/临时缓存。
- **通知：** Capacitor Local Notifications；通知需申请 Android 13+ 通知权限，Android 12+ 精确闹钟权限/能力需按设备与应用用途评估，不能承诺所有 OEM 都精确准时。
- **备份：** JSON 备份与恢复，恢复前预览条数并支持合并/覆盖策略；数据库版本迁移。

## 数据表草案
`items`
- `id TEXT PRIMARY KEY`
- `name TEXT NOT NULL`
- `category TEXT NOT NULL`
- `quantity INTEGER NOT NULL DEFAULT 1`
- `manufacture_date TEXT NULL` — ISO date `YYYY-MM-DD`
- `shelf_life_value INTEGER NULL`
- `shelf_life_unit TEXT NULL` — `days|months|years`
- `expiry_date TEXT NOT NULL` — ISO date，不存 UTC timestamp
- `expiry_is_manual INTEGER NOT NULL DEFAULT 0`
- `location TEXT NULL`
- `reminder_days INTEGER NOT NULL DEFAULT 7`
- `note TEXT NULL`
- `created_at TEXT NOT NULL` — ISO timestamp
- `updated_at TEXT NOT NULL`

`notification_schedule`
- `item_id TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE`
- `notification_id INTEGER NOT NULL UNIQUE`
- `trigger_date TEXT NOT NULL`
- `kind TEXT NOT NULL` — `before|day_of`
- `PRIMARY KEY(item_id, trigger_date, kind)`

## 通知规则（初始默认值）
- 物品级提前提醒天数可配置，初始默认 7 天；V1 默认额外提醒到期当天。
- 若用户选择 7 天提前提醒，则按到期日前 7 天及到期当天排程；可在后续设置中增加 3/1 天选项。
- 触发日期已经过去：不排程历史通知；物品过期仍在首页统计中显示。
- 修改/删除物品时，先取消其旧通知，再根据新日期重排；通知 ID 稳定映射到记录。
- App 启动、恢复前台、时区/日期变更时检查并重建未来通知，避免系统重启或 OEM 清理导致失效。
- 通知权限被拒：显示状态提示和设置入口，但物品管理本身仍可使用。
- 每次排程前先取消本物品旧排程，避免重复提醒。

## 日期边界原则
- 所有到期日用本地日历日期，不转换为 UTC 日期存储。
- 月/年期限按目标月份最后一天夹取，例如 1 月 31 日 + 1 个月 = 2 月末；2 月 29 日 + 1 年 = 次年 2 月 28 日（闰年则可回到 2 月 29 日）。
- 日期差计算以本地日历日为单位，不按小时差计算。
- 手动修改 expiry 后设置 `expiry_is_manual=true`；生产日期/期限改变时才重新计算，并清除此标记。

## 里程碑与验收
1. **M1 日期可靠性：** 日期工具抽离；非法日期校验；月底、闰年、跨年和日期差测试通过。
2. **M2 Android 包装：** 安装 Capacitor 依赖，生成 Android 工程，Android Studio 能成功同步。
3. **M3 持久化：** SQLite CRUD、首次迁移 localStorage、备份/恢复测试。
4. **M4 通知：** 权限流程、排程、修改取消、重建、到期提醒验证。
5. **M5 完整体验：** 日历视图、统计、分类筛选、无障碍和视觉微调。
6. **M6 发布：** 真机回归、debug APK、签名 release APK/AAB、版本号与隐私说明。

## 目前已完成 / 尚未完成
- 已完成：三主题原型、基本 CRUD、搜索与筛选、JSON 备份、AI 图资产；本轮日期工具抽离及 Node 测试。
- 未完成：Capacitor Android 工程生成、SQLite、系统通知、真机测试、APK 编译/签名。
- 当前环境检查：有 Node/npm/Java；未检测到 Gradle 命令。Android SDK/Android Studio 环境不可用，因此本阶段不能产出已验证 APK。

## V0.3 — Android 可安装工程准备
- 已生成 `android/` 原生 Android Studio 工程（WebView + WebViewAssetLoader），包名 `com.shelfie.expiry`。
- 前端页面与图标打包到 `android/app/src/main/assets/www/`，页面可离线启动。
- 已加入 Android 系统 JSON 文件选择器导入与“另存为”导出桥接。
- 已加入 Gradle 8.9 启动脚本与 Android Gradle Plugin 8.7.3 配置。
- **尚未构建 APK**：此环境无 Android SDK，且外网 DNS 不可用，无法下载构建组件。
