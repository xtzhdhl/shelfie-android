import test from 'node:test';
import assert from 'node:assert/strict';
import {parseDate,addShelfLife,diffDays} from '../www/date-utils.js';

test('strictly rejects invalid calendar dates',()=>{
  assert.equal(parseDate('2026-02-30'),null);
  assert.equal(parseDate('2026-2-03'),null);
  assert.equal(parseDate(''),null);
});
test('month addition clamps month-end without overflowing',()=>{
  assert.equal(addShelfLife('2026-01-31',1,'months'),'2026-02-28');
  assert.equal(addShelfLife('2026-03-31',1,'months'),'2026-04-30');
  assert.equal(addShelfLife('2026-01-31',2,'months'),'2026-03-31');
});
test('year addition clamps leap day',()=>{
  assert.equal(addShelfLife('2024-02-29',1,'years'),'2025-02-28');
  assert.equal(addShelfLife('2024-02-29',4,'years'),'2028-02-29');
});
test('day addition and invalid inputs',()=>{
  assert.equal(addShelfLife('2026-12-31',1,'days'),'2027-01-01');
  assert.equal(addShelfLife('2026-01-01',0,'days'),'');
  assert.equal(addShelfLife('2026-01-01',1.5,'days'),'');
  assert.equal(addShelfLife('2026-01-01',1,'weeks'),'');
});
test('date difference compares calendar days independent of time-of-day',()=>{
  assert.equal(diffDays('2026-11-21',new Date(2026,10,20,23,59)),1);
  assert.equal(diffDays('2026-11-20',new Date(2026,10,20,0,1)),0);
});
