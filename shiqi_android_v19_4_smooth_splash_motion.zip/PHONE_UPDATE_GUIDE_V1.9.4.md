# 拾期 V1.9.4 手机更新说明

1. 将 `shiqi_android_v19_4_smooth_splash_motion.zip` 上传至 GitHub 仓库根目录并提交到 `main`。
2. 更新唯一的 `.github/workflows/build-apk.yml`，切换到 V1.9.4 并保留固定签名。
3. Actions 将执行字体资源检查、自动化测试、APK 构建和签名验证，并发布 `shelfie-v1.9.4.apk`。
4. 安装时直接覆盖旧版本，不要卸载旧版或清除应用数据。

包名保持 `com.shelfie.expiry.debug`，版本号 `1.9.4 / 23`，固定签名不变。
