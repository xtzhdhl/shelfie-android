# 拾期 SHELFIE V1.9.4 检查报告

日期：2026-11-23

## 自动化检查

- `npm test`：108 项通过，0 项失败。
- JavaScript 语法检查：`app.js`、`photo-recognition.js`、`product-lookup.js`、`ai-mutations.js`、`date-utils.js`、`backup-utils.js`、`ocr-import.js` 全部通过。
- Android WebView 资源镜像：`index.html`、`styles.css`、`app.js`、`sw.js` 与 `www/` 源文件逐字节一致。
- 应用版本：`1.9.4 / 23`。
- 安装身份：保留 `com.shelfie.expiry.debug`、原固定签名 alias `shelfie-upload` 和现有数据存储实现。

## 启动页动效检查

- 保留 V1.9.3 已验收的「拾期」两个真实文本字与小赖离线手写字体；本版本不改字形、字体、字号或文案。
- 两个汉字作为同一字标整体做连续、柔和的墨迹显现，不再分别大幅缩放、旋转和弹跳。
- 中文标语在字标显现后轻柔淡入；英文副标题与底部品牌文字仅做细微淡入。
- 停止背景圆点漂浮和圆环旋转，移除移动加载条及多余装饰动效。
- 保留系统 `prefers-reduced-motion: reduce` 的无动画呈现。
- PWA 离线缓存键升为 `shelfie-cache-v10`，并加入手写字体资源路径。

## 尚待验证

- 本检查环境没有外网访问，因此没有在本地执行字体下载与 WOFF2 子集化；现有 GitHub Actions 工作流将运行 `scripts/prepare-handwriting-font.sh` 并检查 Web 与 Android 字体资源一致后再构建。
- 本次未在本地执行 Android Gradle APK 编译，也未在 OnePlus 12 真机上验收新动效。需将 V1.9.4 ZIP 上传到仓库，更新唯一工作流并完成 CI 构建后安装验证。
