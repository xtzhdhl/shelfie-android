import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, stat } from 'node:fs/promises';
const root = new URL('../', import.meta.url);
const read = path => readFile(new URL(path, root), 'utf8');

test('startup overlay contains both literal Chinese brand characters and no launcher icon', async () => {
  const html = await read('www/index.html');
  assert.match(html, /id="startupSplash"/);
  const splash = html.slice(html.indexOf('<div class="startup-splash"'), html.indexOf('<div class="app-shell">'));
  assert.match(splash, /class="startup-wordmark"[^>]*aria-label="拾期"/);
  assert.match(splash, /class="startup-word startup-word-first"[^>]*>拾<\/span>/);
  assert.match(splash, /class="startup-word startup-word-second"[^>]*>期<\/span>/);
  assert.match(splash, /把容易忘记的日期，交给拾期记着。/);
  assert.doesNotMatch(splash, /<img|shelfie-icon-512|startup-icon|startup-glyph/);
  assert.doesNotMatch(splash, /<svg/);
});

test('startup uses the bundled handwritten font for title and slogan', async () => {
  const css = await read('www/styles.css');
  const html = await read('www/index.html');
  const js = await read('www/app.js');
  assert.match(css, /font-family:'ShelfieHandwriting'/);
  assert.match(css, /assets\/fonts\/shelfie-handwriting\.woff2/);
  const sw = await read('www/sw.js');
  assert.match(sw, /shelfie-cache-v10/);
  assert.match(sw, /assets\/fonts\/shelfie-handwriting\.woff2/);
  assert.match(css, /\.startup-tagline[^}]*font-family:'ShelfieHandwriting'/);
  assert.match(css, /splashInkSweep/);
  assert.match(css, /startup-wordmark\{animation:splashInkSweep 1\.28s/);
  assert.match(css, /startup-splash\.font-ready \.startup-tagline\{animation:splashSoftAppear/);
  assert.match(css, /clip-path:none;filter:blur\(\.6px\);transform:translate3d\(0,4px,0\)/);
  assert.match(css, /cubic-bezier\(\.18,\.72,\.2,1\)/);
  assert.doesNotMatch(css, /splashHandwrite|splashFloat|splashOrbit|splashInkReveal/);
  assert.doesNotMatch(css, /scale\(1\.075\)|rotate\(2\.2deg\)|translateY\(22px\)/);
  assert.doesNotMatch(html, /startup-loading-line/);
  assert.match(css, /prefers-reduced-motion:reduce[\s\S]*?clip-path:none!important/);
  assert.match(css, /prefers-reduced-motion:reduce/);
  assert.match(html, /class="startup-caption"/);
  assert.match(js, /document\.fonts\.load\('400 120px "ShelfieHandwriting"'\)/);
  assert.match(js, /splash\.classList\.add\('font-ready'\)/);
  const script = await read('scripts/prepare-handwriting-font.sh');
  assert.match(script, /Xiaolai-Regular\.ttf/);
  assert.match(script, /EXPECTED_SHA256=/);
  assert.match(script, /fontTools\.subset/);
  assert.match(script, /OFL\.txt/);
});

test('PWA and Android launcher icon assets exist at the expected dimensions', async () => {
  const pwa = await readFile(new URL('www/assets/shelfie-icon-512.png', root));
  assert.equal(pwa.toString('hex', 0, 8), '89504e470d0a1a0a');
  assert.equal(pwa.readUInt32BE(16), 512);
  assert.equal(pwa.readUInt32BE(20), 512);
  for (const [density, size] of [['mdpi',48],['hdpi',72],['xhdpi',96],['xxhdpi',144],['xxxhdpi',192]]) {
    for (const variant of ['ic_launcher.png','ic_launcher_round.png']) {
      const icon = await readFile(new URL(`android/app/src/main/res/mipmap-${density}/${variant}`, root));
      assert.equal(icon.toString('hex', 0, 8), '89504e470d0a1a0a');
      assert.equal(icon.readUInt32BE(16), size);
      assert.equal(icon.readUInt32BE(20), size);
    }
  }
});

test('Android 12+ system splash uses a transparent icon while the launcher icon remains intact', async () => {
  const styles = await read('android/app/src/main/res/values-v31/styles.xml');
  const transparent = await read('android/app/src/main/res/drawable/splash_transparent.xml');
  assert.match(styles, /windowSplashScreenAnimatedIcon.*splash_transparent/);
  assert.match(styles, /windowSplashScreenBackground/);
  assert.match(transparent, /android:color="@android:color\/transparent"/);
  const manifest = await read('android/app/src/main/AndroidManifest.xml');
  assert.match(manifest, /android:icon="@mipmap\/ic_launcher"/);
});

test('V1.9.4 keeps the existing install identity and persistent signing alias', async () => {
  const gradle = await read('android/app/build.gradle');
  assert.match(gradle, /applicationId 'com\.shelfie\.expiry'/);
  assert.match(gradle, /applicationIdSuffix '\.debug'/);
  assert.match(gradle, /versionCode 23/);
  assert.match(gradle, /versionName '1\.9\.4'/);
  assert.match(gradle, /keyAlias System\.getenv\('SHELFIE_KEY_ALIAS'\)/);
  assert.match(gradle, /signingConfig signingConfigs\.shelfieUpload/);
});
