# 拾期 SHELFIE — Android 化实施路线（V0.2）

## 本阶段目标
先保证日期计算可靠，再把浏览器原型包装成 Android 应用；原型数据在 APK 内必须迁移到可靠的本地持久化，并实现真正的系统通知。

## 推荐技术组合
- **UI / 现有页面：** HTML、CSS、ES modules，继续沿用 `www/`。
- **Android 容器：** Capacitor Android；包名 `com.shelfie.expiry`。
- **数据库：** SQLite 原生插件（推荐 Capacitor SQLite 生态方案）；数据库是权威数据源，localStorage 仅作迁移入口/临时缓存。
- **通知：** Capacitor Local Notifications；通知需申请 Android 13+ 通知权限，Android 12+ 精确闹钟权限/能力需按设备与应用用途评估，不能承诺所有 OEM 都精确准时。
- **备份：** JSON 备份与恢复，恢复前预览条数并支持合并/覆盖策略；数据库版本迁移。

## 数据表草案
`items`
- `id TEXT PRIMARY KEY`
- `name TEXT NOT NULL`
- `category TEXT NOT NULL`
- `quantity INTEGER NOT NULL DEFAULT 1`
- `manufacture_date TEXT NULL` — ISO date `YYYY-MM-DD`
- `shelf_life_value INTEGER NULL`
- `shelf_life_unit TEXT NULL` — `days|months|years`
- `expiry_date TEXT NOT NULL` — ISO date，不存 UTC timestamp
- `expiry_is_manual INTEGER NOT NULL DEFAULT 0`
- `location TEXT NULL`
- `reminder_days INTEGER NOT NULL DEFAULT 7`
- `note TEXT NULL`
- `created_at TEXT NOT NULL` — ISO timestamp
- `updated_at TEXT NOT NULL`

`notification_schedule`
- `item_id TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE`
- `notification_id INTEGER NOT NULL UNIQUE`
- `trigger_date TEXT NOT NULL`
- `kind TEXT NOT NULL` — `before|day_of`
- `PRIMARY KEY(item_id, trigger_date, kind)`

## 通知规则（初始默认值）
- 物品级提前提醒天数可配置，初始默认 7 天；V1 默认额外提醒到期当天。
- 若用户选择 7 天提前提醒，则按到期日前 7 天及到期当天排程；可在后续设置中增加 3/1 天选项。
- 触发日期已经过去：不排程历史通知；物品过期仍在首页统计中显示。
- 修改/删除物品时，先取消其旧通知，再根据新日期重排；通知 ID 稳定映射到记录。
- App 启动、恢复前台、时区/日期变更时检查并重建未来通知，避免系统重启或 OEM 清理导致失效。
- 通知权限被拒：显示状态提示和设置入口，但物品管理本身仍可使用。
- 每次排程前先取消本物品旧排程，避免重复提醒。

## 日期边界原则
- 所有到期日用本地日历日期，不转换为 UTC 日期存储。
- 月/年期限按目标月份最后一天夹取，例如 1 月 31 日 + 1 个月 = 2 月末；2 月 29 日 + 1 年 = 次年 2 月 28 日（闰年则可回到 2 月 29 日）。
- 日期差计算以本地日历日为单位，不按小时差计算。
- 手动修改 expiry 后设置 `expiry_is_manual=true`；生产日期/期限改变时才重新计算，并清除此标记。

## 里程碑与验收
1. **M1 日期可靠性：** 日期工具抽离；非法日期校验；月底、闰年、跨年和日期差测试通过。
2. **M2 Android 包装：** 安装 Capacitor 依赖，生成 Android 工程，Android Studio 能成功同步。
3. **M3 持久化：** SQLite CRUD、首次迁移 localStorage、备份/恢复测试。
4. **M4 通知：** 权限流程、排程、修改取消、重建、到期提醒验证。
5. **M5 完整体验：** 日历视图、统计、分类筛选、无障碍和视觉微调。
6. **M6 发布：** 真机回归、debug APK、签名 release APK/AAB、版本号与隐私说明。

## 目前已完成 / 尚未完成
- 已完成：三主题原型、基本 CRUD、搜索与筛选、JSON 备份、AI 图资产；本轮日期工具抽离及 Node 测试。
- 未完成：Capacitor Android 工程生成、SQLite、系统通知、真机测试、APK 编译/签名。
- 当前环境检查：有 Node/npm/Java；未检测到 Gradle 命令。Android SDK/Android Studio 环境不可用，因此本阶段不能产出已验证 APK。

## V0.3 — Android 可安装工程准备
- 已生成 `android/` 原生 Android Studio 工程（WebView + WebViewAssetLoader），包名 `com.shelfie.expiry`。
- 前端页面与图标打包到 `android/app/src/main/assets/www/`，页面可离线启动。
- 已加入 Android 系统 JSON 文件选择器导入与“另存为”导出桥接。
- 已加入 Gradle 8.9 启动脚本与 Android Gradle Plugin 8.7.3 配置。
- **尚未构建 APK**：此环境无 Android SDK，且外网 DNS 不可用，无法下载构建组件。


## V0.4 视觉迭代（2026-11-22）
- 首页主视觉从高光 3D 贴纸转为柔和的二维人物线稿感插画，减少塑料/玻璃高光、发光轨道和漂浮动画。
- 空状态改用轻量月牙符号，避免与新人物插画风格冲突。
- 新素材已同步至 `www/assets/` 与 Android WebView assets。


## V0.6 本轮功能补齐（2026-11-22）
- 已实现：产品标注到期日、生产日期+保质期、开封日期+开封后期限三种日期来源；两种期限同时存在时采用更早的有效日期。
- 已实现：日历月视图、逐日到期物品列表、月份切换和回到今天。
- 已实现：AI 录入规则扩展到开封后期限，系统提示中加入现有物品上下文和剩余天数。
- 已实现：导入 JSON 日期/字段校验、自定义确认页面、存储失败时回滚内存修改。
- 已实现：API Base URL 强制 HTTPS，避免把 API Key 发往明文 HTTP 地址。
- 已测试：Node 日期工具测试 12 项全部通过；`node --check www/app.js` 通过。
- 尚未实现：Android 系统通知真正排程、SQLite、相机 OCR/条码、AI 编辑/删除/批量操作、Keystore 加密存储。
- 尚未验证：Android 真机 / GitHub Actions 重新构建。本次仅更新源码与 Android assets，未声称已生成新 APK。


## V0.7 进展（2026-11-22）
- 已写入 Android SQLite 数据层：物品字段持久化、列表读取、事务式同步、删除项 ID 返回。
- 已接入 WebView Native Bridge：Android 版 SQLite 优先；首次运行把旧 localStorage 记录迁移进 SQLite；浏览器预览继续使用 localStorage。
- 已接入 WorkManager 本地提醒：每件物品一条唯一工作任务，提醒日当地时间 09:00；修改替换、删除取消、导入同步。
- 已加入 Android 13+ 通知权限请求、设置页入口，以及开机/日期/时区变更时的重排程接收器。
- 当前通知为 WorkManager 可延迟任务，不是精确闹钟；厂商省电策略可能延迟。
- 待验证：Gradle 编译、OnePlus 12 真机 SQLite 重启持久化、通知权限授予/拒绝、到期提醒送达、重启/时区变化恢复。
- 本环境是否能编译尚待实际构建尝试；源码功能不等于已产出 APK。


## V0.8（2026-11-22）
- 已实现源码：Android Keystore AES-GCM API Key 加密；浏览器只保留会话 Key，不持久写入 localStorage。
- 已实现源码：AI 按 ID 提议修改/删除已有物品，变更通过确认卡片执行。
- 已实现源码：逐件提醒管理中心与 WorkManager 重新同步入口。
- 已通过：26 项 Node 自动化测试。
- 待验证：Gradle 编译、Keystore 真机加解密、AI 服务端真实响应、OnePlus 12 通知权限/送达与后台行为。


## V1.2 智能商品识别中心（2026-11-22）
- 已实现源码：条码查询公开 Open Facts v3 商品接口，并以四个类别数据库作备用查询。
- 已实现源码：用户手动提交商品名称/品牌搜索；候选展示名称、品牌、规格、图片和目录来源，选择后进入草稿。
- 已实现源码：未收录/网络错误分开提示；未收录后仍能用照片或手动名称继续；绝不从目录继承保质期/日期。
- 已实现源码：Android 只读网络桥限制 HTTPS 官方目录 host、GET 请求、连接超时与响应体限制；不发送 API Key 或清单数据。
- 已验证：63 项自动化测试通过；HTML/XML 检查及 9 个网页资源与 Android assets 的逐字节同步检查通过。
- 待验证：公开 API 真实网络响应、四目录覆盖率、OnePlus 12 真机网络和 UI。公开数据库内容由用户社区贡献，可能不完整或过时。
- 构建阻塞：当前开发容器没有 Android SDK，且下载 Gradle 8.9 时 DNS 无法解析 `services.gradle.org`，所以本轮未构建 APK。
- 待完成：在有 Android SDK 的环境构建 debug APK；真机完整回归；如需公开发布，再准备 release 签名、隐私政策和上架资产。


## V1.3 个人资料、头像库与系统栏主题（2026-11-22）
- 已实现源码：小助手可自定义正式名字与聊天昵称，用户可自定义聊天昵称。
- 已实现源码：头像上传/批量上传、512px 本地缩图、本机 IndexedDB 头像库、给助手或用户分别设置头像、随机助手头像和删除。
- 已实现源码：切换三种主题时同步修改 Android 原生状态栏与底部系统导航栏颜色。
- 已实现源码：顶部“＋ 记一件”按钮图标与文字居中对齐。
- 已通过：66 项 Node 自动化测试、JavaScript 语法、HTML ID 唯一性、Android XML 解析与 Android WebView assets 同步检查。
- 待验证：一加 12 上头像批量选择、头像重启持久化、主题状态栏颜色和导航栏颜色、布局显示。
- 暂缓：新的桌面应用图标等待图像生成额度恢复后处理；当前仍使用原 launcher icon。
