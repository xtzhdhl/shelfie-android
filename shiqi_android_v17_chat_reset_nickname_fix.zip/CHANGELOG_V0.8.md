# 拾期 SHELFIE V0.8 · API 安全、AI 修改删除与提醒管理

## 本轮实现
- Android API Key 保险库：新增 `ApiKeyVault`，通过设备 Android Keystore 生成不可导出的 AES-256 密钥，以 AES/GCM/NoPadding 加密 API Key 后存入应用私有 SharedPreferences。
- API Key 迁移：旧版本配置中的明文 `apiKey` 会在 Android 启动时尝试迁移到 Keystore，并从 WebView localStorage 配置中移除；浏览器预览不再持久化 API Key，只保留本次会话内存。
- AI 修改已有物品：助手可提出 `update_item`，必须按当前清单 ID 匹配，界面展示修改预览，用户确认后才保存。
- AI 删除已有物品：助手可提出 `delete_item`，只允许匹配清单中的精确 ID，用户再次确认后才删除；删除同步触发 SQLite/提醒更新。
- 提醒管理中心：设置页逐件列出物品，可将提前提醒设为 7 天、3 天、1 天或关闭；变更会通过原有 SQLite/WorkManager 桥接同步排程。
- WorkManager 的重新同步入口：支持从设置页请求全部物品提醒重新排程。
- Service Worker 缓存版本升级并预缓存新的 AI 操作模块。

## 安全与行为边界
- API Key 的“记住”选项在 Android 上使用 Android Keystore AES-GCM；不勾选时只在当前进程的 JS 内存中使用。
- 浏览器预览无法访问 Android Keystore，因此密钥只在当前浏览器会话中保留，不写入 localStorage。
- AI 修改/删除都必须经过 UI 确认；未知 ID、空 patch、同名无法唯一匹配时拒绝执行/要求助手追问。
- 提醒中心修改的是物品级 `reminderDays` 字段；设为 0 会取消该物品的 WorkManager 提醒，但不删除物品。
- WorkManager 仍然是可延迟后台任务，不保证精确时刻送达。

## 检查结果
- `node --check www/app.js`：通过。
- `node --check www/ai-mutations.js`：通过。
- `npm test`：26 项通过，0 失败。
- Android XML/Gradle 构建与设备 Keystore 实际运行尚未验证；本轮没有声称已生成 APK。
