# SHELFIE V1.5.1

## 修复
- 修复聊天消息头像设置为圆形时，头像图片仍以矩形显示的问题。
- 用户和助手头像图片统一继承头像容器的 `border-radius`，让头像图像本身真正按圆形或圆角矩形裁切。
- 头像库、资料预览、聊天消息以及助手顶部头像共享相同形状规则。

## Android 版本
- versionName: 1.5.1
- versionCode: 14
- applicationId: com.shelfie.expiry（debug 构建最终包名为 com.shelfie.expiry.debug）
- 延续 V1.4/V1.5 使用的固定 JKS 签名配置；所有后续更新必须使用同一把密钥。
