# SHELFIE V1.6.0 phone-only update

1. Upload `shiqi_android_v16_api_nudge_fix.zip` to the repository root.
2. Replace `.github/workflows/build-apk.yml` with `build-apk-v16.yml` (the complete YAML is also provided directly in the chat response).
3. Keep the existing `SHELFIE_KEYSTORE_BASE64` and `SHELFIE_KEYSTORE_PASSWORD` repository secrets unchanged.
4. Commit and manually run `Build and Publish SHELFIE V1.6.0` on `main`.
5. Verify the APK package and SHA-256 signing certificate match the persistent keystore.
6. Install over the existing app. Do not uninstall or clear app data.
