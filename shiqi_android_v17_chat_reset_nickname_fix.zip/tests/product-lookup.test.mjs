import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import {
  normalizeBarcodeCode,
  normalizeProductRecord,
  lookupBarcode,
  searchProducts
} from '../www/product-lookup.js';

const root = new URL('../', import.meta.url);
const read = path => readFile(new URL(path, root), 'utf8');

const product = (extra = {}) => ({
  code: '3017620422003',
  product_name: 'Example Oat Drink',
  product_name_zh: '示例燕麦饮',
  brands: 'Example Brand',
  quantity: '250 ml',
  categories: 'Plant-based drinks',
  image_front_small_url: 'https://images.example.org/item.jpg',
  ...extra
});

test('barcode normalization accepts common GTIN lengths and rejects arbitrary text', () => {
  assert.equal(normalizeBarcodeCode(' 3017 6204-22003 '), '3017620422003');
  assert.equal(normalizeBarcodeCode('96385074'), '96385074');
  assert.equal(normalizeBarcodeCode('6901234567890'), ''); // valid length, invalid GTIN check digit
  assert.equal(normalizeBarcodeCode('ABCD12345678'), '');
  assert.equal(normalizeBarcodeCode('1234567'), '');
  assert.equal(normalizeBarcodeCode('123456789012345'), '');
});

test('product normalization extracts only bounded catalogue facts', () => {
  const result = normalizeProductRecord(product(), { label: 'Open Food Facts', host: 'world.openfoodfacts.org', category: '食品饮料' });
  assert.equal(result.name, '示例燕麦饮');
  assert.equal(result.brand, 'Example Brand');
  assert.equal(result.quantity, '250 ml');
  assert.equal(result.category, '食品饮料');
  assert.equal(result.image, 'https://images.example.org/item.jpg');
  assert.match(result.sourceUrl, /world\.openfoodfacts\.org\/product\/3017620422003/);
  assert.equal(normalizeProductRecord({ product_name: '<script></script>' }), null);
});

test('barcode lookup prefers v3 all-product-types endpoint', async () => {
  const requested = [];
  const result = await lookupBarcode('3017620422003', { now: () => 1_000_000, minBarcodeIntervalMs: 0,
    request: async url => {
      requested.push(url);
      return { httpStatus: 200, data: { status: 'success', product: product() } };
    }
  });
  assert.equal(result.status, 'found');
  assert.equal(result.products[0].name, '示例燕麦饮');
  assert.equal(result.strategy, 'v3-all-types');
  assert.match(requested[0], /product_type=all/);
  assert.match(requested[0], /product_type/);
  assert.match(new URL(requested[0]).searchParams.get('fields'), /product_type/);
  assert.equal(requested.length, 1);
});

test('barcode lookup falls back to category databases when v3 does not find a code', async () => {
  const requested = [];
  const result = await lookupBarcode('3017620422003', { now: () => 2_000_000, minBarcodeIntervalMs: 0,
    request: async url => {
      requested.push(url);
      if (url.includes('/api/v3/')) return { httpStatus: 404, data: { status: 'failure' } };
      if (url.includes('world.openbeautyfacts.org')) return { httpStatus: 200, data: { status: 1, product: product({ product_name: 'Moisture Cream', product_name_zh: '保湿面霜' }) } };
      return { httpStatus: 404, data: { status: 0 } };
    }
  });
  assert.equal(result.status, 'found');
  assert.equal(result.strategy, 'v2-cross-database');
  assert.equal(result.products[0].category, '护肤美妆');
  assert.equal(requested.length, 5);
  assert.ok(requested.some(url => url.includes('world.openpetfoodfacts.org')));
});

test('valid barcode missing from all directories is a normal not-found result', async () => {
  const result = await lookupBarcode('3017620422003', { now: () => 3_000_000, minBarcodeIntervalMs: 0,
    request: async url => ({ httpStatus: 404, data: { status: 0, status_verbose: 'product not found' } })
  });
  assert.equal(result.status, 'not-found');
  assert.equal(result.products.length, 0);
  assert.match(result.message, /可以继续拍照识别或手动录入/);
});

test('network failure is not misreported as an ordinary missing product', async () => {
  const result = await lookupBarcode('3017620422003', { now: () => 4_000_000, minBarcodeIntervalMs: 0,
    request: async () => { throw new Error('offline'); }
  });
  assert.equal(result.status, 'error');
  assert.match(result.message, /无法连接/);
});

test('barcode lookup caches found and not-found results for fifteen minutes', async () => {
  let calls = 0;
  const request = async () => {
    calls++;
    return { httpStatus: 404, data: { status: 'failure' } };
  };
  const first = await lookupBarcode('3017620422003', { now: () => 5_000_000, minBarcodeIntervalMs: 0, request });
  const second = await lookupBarcode('3017620422003', { now: () => 5_100_000, minBarcodeIntervalMs: 0, request });
  assert.equal(first.status, 'not-found');
  assert.equal(second.status, 'not-found');
  assert.equal(second.cached, true);
  assert.equal(calls, 5); // one v3 request plus four v2 fallbacks, only once
});

test('manual product name search is submit-only, cross-catalogue and deduplicated', async () => {
  const requested = [];
  const result = await searchProducts('燕麦饮', { minSearchIntervalMs: 0,
    request: async url => {
      requested.push(url);
      return { httpStatus: 200, data: { products: [product()] } };
    }
  });
  assert.equal(result.status, 'found');
  assert.equal(result.products.length, 1);
  assert.equal(requested.length, 4);
  assert.ok(requested.every(url => url.includes('search_terms=')));
  assert.ok(requested.every(url => url.includes('page_size=8')));
});

test('search validates too-short terms and does not issue a network request', async () => {
  let calls = 0;
  const result = await searchProducts('a', { minSearchIntervalMs: 0, request: async () => { calls++; return {}; } });
  assert.equal(result.status, 'invalid');
  assert.equal(calls, 0);
});


test('manual name search applies a cooldown to respect public search limits', async () => {
  let calls = 0;
  const request = async () => { calls++; return { httpStatus: 200, data: { products: [] } }; };
  const base = Date.now() + 100000;
  await searchProducts('first query', { request, now: () => base, minSearchIntervalMs: 30000 });
  const second = await searchProducts('second query', { request, now: () => base + 10000, minSearchIntervalMs: 30000 });
  assert.equal(second.status, 'rate-limited');
  assert.equal(calls, 4);
});

test('lookup UI keeps public product facts separate from expiry facts and allows manual fallback', async () => {
  const html = await read('www/index.html');
  const js = await read('www/app.js');
  assert.match(html, /id="lookupBarcodeButton"/);
  assert.match(html, /id="searchProductButton"/);
  assert.match(html, /id="productLookupResults"/);
  assert.match(html, /不会导入其他商品的保质期/);
  assert.match(js, /用这个名称建立待识别草稿/);
  assert.match(js, /商品资料来源：/);
  assert.match(js, /source:'photo-scan'/);
});

test('Android public product lookup bridge restricts hosts and uses GET without an API key', async () => {
  const activity = await read('android/app/src/main/java/com/shelfie/expiry/MainActivity.java');
  assert.match(activity, /getProductJson\(String requestId, String endpoint\)/);
  assert.match(activity, /world\.openfoodfacts\.org/);
  assert.match(activity, /world\.openbeautyfacts\.org/);
  assert.match(activity, /world\.openpetfoodfacts\.org/);
  assert.match(activity, /world\.openproductsfacts\.org/);
  assert.match(activity, /isAllowedProductPath/);
  assert.match(activity, /cgi\/search\.pl/);
  assert.match(activity, /connection\.setRequestMethod\("GET"\)/);
  assert.match(activity, /setConnectTimeout\(10000\)/);
  assert.match(activity, /deliverProductLookupResult/);
});
