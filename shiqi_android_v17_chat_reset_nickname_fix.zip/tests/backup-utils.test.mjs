import test from 'node:test';
import assert from 'node:assert/strict';
import { webcrypto } from 'node:crypto';
import { encryptBackupPayload, decryptBackupPayload } from '../www/backup-utils.js';

const sample = {
  app: 'SHELFIE', schemaVersion: 4, items: [{ id: 'a', name: '牛奶' }],
  apiKey: 'test-secret', profile: { assistantNickname: '小月' },
  avatars: [{ id: 'av1', dataUrl: 'data:image/webp;base64,AAAA' }]
};

test('full backup encrypts complete personal data and decrypts with the same password', async () => {
  const encrypted = await encryptBackupPayload(sample, 'safe-passphrase-2026', webcrypto);
  assert.equal(encrypted.format, 'SHELFIE_FULL_BACKUP');
  assert.equal(JSON.stringify(encrypted).includes('test-secret'), false);
  assert.deepEqual(await decryptBackupPayload(encrypted, 'safe-passphrase-2026', webcrypto), sample);
});

test('full backup rejects an incorrect password and corrupted ciphertext', async () => {
  const encrypted = await encryptBackupPayload(sample, 'safe-passphrase-2026', webcrypto);
  await assert.rejects(() => decryptBackupPayload(encrypted, 'wrong-password', webcrypto));
  const corrupted = { ...encrypted, ciphertext: encrypted.ciphertext.slice(0, -4) + 'AAAA' };
  await assert.rejects(() => decryptBackupPayload(corrupted, 'safe-passphrase-2026', webcrypto));
});

test('full backup requires an eight-character password', async () => {
  await assert.rejects(() => encryptBackupPayload(sample, 'short', webcrypto), /至少需要 8/);
});
