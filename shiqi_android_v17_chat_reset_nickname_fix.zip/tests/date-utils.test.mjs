import test from 'node:test';
import assert from 'node:assert/strict';
import { parseDate, addShelfLife, diffDays, getExpiryInfo, getDaysLeft, isValidExpiryRecord, getReminderDate, shiftDate } from '../www/date-utils.js';

test('strictly rejects invalid calendar dates', () => {
  assert.equal(parseDate('2026-02-30'), null);
  assert.equal(parseDate('2026-2-03'), null);
  assert.equal(parseDate(''), null);
});

test('month addition clamps month-end without overflowing', () => {
  assert.equal(addShelfLife('2026-01-31', 1, 'months'), '2026-02-28');
  assert.equal(addShelfLife('2026-03-31', 1, 'months'), '2026-04-30');
  assert.equal(addShelfLife('2026-01-31', 2, 'months'), '2026-03-31');
});

test('year addition clamps leap day', () => {
  assert.equal(addShelfLife('2024-02-29', 1, 'years'), '2025-02-28');
  assert.equal(addShelfLife('2024-02-29', 4, 'years'), '2028-02-29');
});

test('day addition and invalid inputs', () => {
  assert.equal(addShelfLife('2026-12-31', 1, 'days'), '2027-01-01');
  assert.equal(addShelfLife('2026-01-01', 0, 'days'), '');
  assert.equal(addShelfLife('2026-01-01', 1.5, 'days'), '');
  assert.equal(addShelfLife('2026-01-01', 1, 'weeks'), '');
});

test('date difference compares calendar days independent of time-of-day', () => {
  assert.equal(diffDays('2026-11-21', new Date(2026, 10, 20, 23, 59)), 1);
  assert.equal(diffDays('2026-11-20', new Date(2026, 10, 20, 0, 1)), 0);
});

test('after-opening expiry is used when it is earlier than the printed date', () => {
  const info = getExpiryInfo({ expiry: '2027-01-01', openedDate: '2026-11-01', afterOpeningValue: 1, afterOpeningUnit: 'months' });
  assert.equal(info.date, '2026-12-01');
  assert.equal(info.basis, 'after-opening');
});

test('printed expiry remains effective when it is earlier than after-opening expiry', () => {
  const info = getExpiryInfo({ expiry: '2026-11-20', openedDate: '2026-11-01', afterOpeningValue: 6, afterOpeningUnit: 'months' });
  assert.equal(info.date, '2026-11-20');
  assert.equal(info.basis, 'printed');
});

test('after-opening record can be valid even when printed expiry is unknown', () => {
  assert.equal(isValidExpiryRecord({ openedDate: '2026-11-01', afterOpeningValue: 3, afterOpeningUnit: 'months' }), true);
  assert.equal(getExpiryInfo({}).date, '');
});

test('days left uses effective expiry', () => {
  assert.equal(getDaysLeft({ expiry: '2027-01-01', openedDate: '2026-11-01', afterOpeningValue: 1, afterOpeningUnit: 'months' }, new Date(2026, 10, 20)), 11);
});

test('calendar day shifting crosses month and year boundaries', () => {
  assert.equal(shiftDate('2027-01-01', -1), '2026-12-31');
  assert.equal(shiftDate('2026-12-31', 1), '2027-01-01');
});

test('reminder date is based on effective expiry and per-item lead time', () => {
  assert.equal(getReminderDate({ expiry: '2027-01-01', reminderDays: 7 }), '2026-12-25');
  assert.equal(getReminderDate({ expiry: '2027-01-01', openedDate: '2026-11-01', afterOpeningValue: 1, afterOpeningUnit: 'months', reminderDays: 3 }), '2026-11-28');
  assert.equal(getReminderDate({ expiry: '2027-01-01', reminderDays: 0 }), '');
});

test('manufacture date plus shelf life can produce effective expiry for imported records', () => {
  assert.equal(getExpiryInfo({ manufacture: '2026-11-01', shelfLife: 30, shelfUnit: 'days' }).date, '2026-12-01');
});
