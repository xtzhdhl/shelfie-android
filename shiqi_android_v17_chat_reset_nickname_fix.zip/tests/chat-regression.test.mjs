import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const app = await readFile(new URL('../www/app.js', import.meta.url), 'utf8');
const html = await readFile(new URL('../www/index.html', import.meta.url), 'utf8');

 test('clearing a chat keeps the API nudge mounted instead of deleting its node', () => {
  const clear = app.slice(app.indexOf('function clearChatConversation()'), app.indexOf("$('clearChat').onclick=clearChatConversation"));
  assert.match(clear, /const nudge=\$\('apiNudge'\)/);
  assert.match(clear, /if\(nudge\)nudge\.remove\(\)/);
  assert.match(clear, /host\.replaceChildren\(\)/);
  assert.match(clear, /if\(nudge\)host\.appendChild\(nudge\)/);
  assert.match(clear, /chatGeneration\+=1/);
});

test('API status update is safe when optional chat nudge node is missing', () => {
  const status = app.slice(app.indexOf('function updateApiStatus()'), app.indexOf('async function testApi()'));
  assert.match(status, /if\(nudge\)\{/);
  assert.match(status, /if\(nudgeText\)/);
  assert.match(status, /if\(nudgeAction\)/);
});

test('a response from before Clear Chat cannot overwrite the new conversation', () => {
  assert.match(app, /let chatGeneration=0/);
  assert.match(app, /const requestGeneration=chatGeneration/);
  assert.match(app, /if\(requestGeneration!==chatGeneration\)return/);
});

test('latest assistant formal name and nickname are injected into every system prompt', () => {
  const prompt = app.slice(app.indexOf('function makeSystemPrompt()'), app.indexOf('function apiPayload('));
  assert.match(prompt, /assistantFormalName/);
  assert.match(prompt, /assistantNickname/);
  assert.match(prompt, /assistantCurrentName/);
  assert.match(prompt, /不要再使用旧昵称/);
});

test('chat title uses and updates the selected assistant nickname', () => {
  assert.match(html, /和<span id="chatAssistantNickname">拾期<\/span>聊聊/);
  assert.match(app, /const chatTitle=\$\('chatAssistantNickname'\);if\(chatTitle\)chatTitle\.textContent=helperName/);
});

test('cleared conversation greeting uses the latest assistant nickname', () => {
  const clear = app.slice(app.indexOf('function clearChatConversation()'), app.indexOf("$('clearChat').onclick=clearChatConversation"));
  assert.match(clear, /现在我是\$\{assistantDisplayName\(\)\}/);
});
