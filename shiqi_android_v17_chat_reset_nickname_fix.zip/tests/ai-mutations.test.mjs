import test from 'node:test';
import assert from 'node:assert/strict';
import { prepareAiMutation, applyAiMutation } from '../www/ai-mutations.js';

const base = [
  { id: 'milk-1', name: '牛奶', expiry: '2026-12-01', reminderDays: 7, createdAt: '2026-11-01T00:00:00.000Z' },
  { id: 'cream-2', name: '面霜', expiry: '2027-03-01', reminderDays: 3, createdAt: '2026-11-02T00:00:00.000Z' }
];
const normalize = (candidate, existing) => ({ ...candidate, id: existing.id, createdAt: existing.createdAt });

test('AI update must match an existing ID and preserve immutable identity fields', () => {
  const prepared = prepareAiMutation({ type: 'update_item', itemId: 'milk-1', patch: { name: '燕麦奶', reminderDays: 1 } }, base, normalize);
  assert.equal(prepared.ok, true);
  assert.equal(prepared.mutation.item.id, 'milk-1');
  assert.equal(prepared.mutation.item.createdAt, base[0].createdAt);
  assert.equal(prepared.mutation.item.name, '燕麦奶');
  const updated = applyAiMutation(base, prepared.mutation);
  assert.equal(updated.length, 2);
  assert.equal(updated[0].reminderDays, 1);
  assert.equal(updated[1], base[1]);
});

test('AI delete is only prepared for the exact matching ID', () => {
  const prepared = prepareAiMutation({ type: 'delete_item', itemId: 'cream-2' }, base, normalize);
  assert.equal(prepared.ok, true);
  const updated = applyAiMutation(base, prepared.mutation);
  assert.deepEqual(updated.map(item => item.id), ['milk-1']);
});

test('AI cannot mutate an item when the supplied ID is unknown', () => {
  const prepared = prepareAiMutation({ type: 'delete_item', itemId: 'not-in-list' }, base, normalize);
  assert.equal(prepared.ok, false);
  assert.match(prepared.reason, /没有在清单里找到/);
});

test('AI update rejects an empty patch', () => {
  const prepared = prepareAiMutation({ type: 'update_item', itemId: 'milk-1', patch: {} }, base, normalize);
  assert.equal(prepared.ok, false);
  assert.match(prepared.reason, /没有提供需要修改/);
});
