import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { normalizePhotoExtraction, mergePhotoExtractions, normalizeBarcodeResults, hasPhotoExpiryBasis, photoDateBasisLabel, photoMissingRequirements } from '../www/photo-recognition.js';

const root = new URL('../', import.meta.url);
const read = path => readFile(new URL(path, root), 'utf8');

test('photo extraction keeps only complete, calendar-valid dates', () => {
  const result = normalizePhotoExtraction({
    name: '燕麦牛奶',
    manufactureDate: '2026-11-01',
    expiryDate: '2026-11-31',
    expiryText: '2026.11',
    warnings: []
  });
  assert.equal(result.name, '燕麦牛奶');
  assert.equal(result.manufacture, '2026-11-01');
  assert.equal(result.expiry, '');
  assert.equal(result.expiryText, '2026.11');
  assert.ok(result.warnings.some(value => value.includes('到期日期')));
});

test('photo extraction distinguishes printed expiry, shelf life and PAO', () => {
  const result = normalizePhotoExtraction({
    name: '面霜', category: '护肤美妆',
    manufactureDate: '', shelfLifeValue: null, shelfLifeUnit: 'months',
    paoValue: 6, paoUnit: 'months'
  });
  assert.equal(result.expiry, '');
  assert.equal(result.shelfLife, null);
  assert.equal(result.afterOpeningValue, 6);
  assert.equal(hasPhotoExpiryBasis(result), false);
  assert.equal(hasPhotoExpiryBasis(result, '2026-11-22'), true);
  assert.equal(photoDateBasisLabel(result, '2026-11-22'), '开封日期 + 开封后期限');
});

test('photo extraction does not infer a missing expiry date', () => {
  const result = normalizePhotoExtraction({ name: '牛奶', expiryText: 'EXP 2027/05' });
  assert.equal(result.expiry, '');
  assert.equal(result.expiryText, 'EXP 2027/05');
  assert.equal(hasPhotoExpiryBasis(result), false);
});

test('photo extraction sanitizes unsupported model categories and confidence', () => {
  const result = normalizePhotoExtraction({
    name: '<script>面霜</script>', category: 'some hallucinated category',
    fieldConfidence: { name: 'certain', expiryDate: 'high' }
  });
  assert.equal(result.category, '护肤美妆');
  assert.equal(result.fieldConfidence.name, 'low');
  assert.equal(result.fieldConfidence.expiry, 'high');
  assert.equal(result.name.length <= 40, true);
});

test('photo review UI asks for consent and only saves after explicit confirmation', async () => {
  const html = await read('www/index.html');
  const js = await read('www/app.js');
  assert.match(html, /id="photoConsent"/);
  assert.match(html, /id="recognizePhotoButton"/);
  assert.match(html, /id="savePhotoRecordButton"/);
  assert.match(js, /async function recognizePackagePhoto/);
  assert.match(js, /function savePhotoRecord/);
  assert.match(js, /photoConsent/);
});

test('Android file chooser supports gallery and camera capture with FileProvider', async () => {
  const activity = await read('android/app/src/main/java/com/shelfie/expiry/MainActivity.java');
  const manifest = await read('android/app/src/main/AndroidManifest.xml');
  const providerPaths = await read('android/app/src/main/res/xml/file_paths.xml');
  assert.match(activity, /MediaStore\.ACTION_IMAGE_CAPTURE/);
  assert.match(activity, /FileProvider\.getUriForFile/);
  assert.match(activity, /image\/\*/);
  assert.match(activity, /params\.getMode\(\) == FileChooserParams\.MODE_OPEN_MULTIPLE/);
  assert.match(activity, /Intent\.EXTRA_ALLOW_MULTIPLE, true/);
  assert.match(activity, /data\.getClipData\(\)\.getItemCount\(\) && selectedUris\.size\(\) < 36/);
  assert.match(manifest, /androidx\.core\.content\.FileProvider/);
  assert.match(providerPaths, /cache-path/);
});


test('Android bundled web assets are synchronized including the photo recognition module', async () => {
  const files = ['index.html', 'app.js', 'styles.css', 'photo-recognition.js', 'product-lookup.js', 'backup-utils.js', 'sw.js'];
  for (const file of files) {
    const web = await read(`www/${file}`);
    const android = await read(`android/app/src/main/assets/www/${file}`);
    assert.equal(android, web, `${file} is not synchronized`);
  }
});

test('vision request explicitly separates MFG, EXP, shelf life and PAO without guessing', async () => {
  const js = await read('www/app.js');
  assert.match(js, /严格区分 MFG\/生产日期、EXP\/有效期\/Best before、保质期时长、开封后使用期限 PAO/);
  assert.match(js, /只有完整且能确定年月日的日期才填写 manufactureDate\/expiryDate/);
  assert.match(js, /不要将今天日期当成生产或开封日期/);
  assert.match(js, /type:'image_url'/);
});

test('photo payload is not inserted into the saved item or backup record', async () => {
  const js = await read('www/app.js');
  const saveBlock = js.slice(js.indexOf('function savePhotoRecord()'), js.indexOf('function wirePhotoRecognition()'));
  assert.match(saveBlock, /normalizeAiItem\(/);
  assert.match(saveBlock, /source:'photo-scan'/);
  assert.doesNotMatch(saveBlock, /selectedPhotoDataUrl|data:image\//);
  const html = await read('www/index.html');
  assert.match(html, /不会把原图写入物品记录或备份/);
});


test('multi-photo merge keeps matching dates and de-duplicates evidence', () => {
  const merged = mergePhotoExtractions([
    { name: '燕麦牛奶', expiryDate: '2027-05-01', visibleText: ['EXP 2027-05-01'], fieldConfidence: { expiryDate: 'high' } },
    { name: '燕麦牛奶', expiryDate: '2027-05-01', manufactureDate: '2026-11-01', visibleText: ['EXP 2027-05-01'], fieldConfidence: { expiryDate: 'high', manufactureDate: 'medium' } }
  ]);
  assert.equal(merged.name, '燕麦牛奶');
  assert.equal(merged.expiry, '2027-05-01');
  assert.equal(merged.manufacture, '2026-11-01');
  assert.deepEqual(merged.visibleText, ['EXP 2027-05-01']);
});

test('multi-photo merge blanks conflicting dates rather than choosing one', () => {
  const merged = mergePhotoExtractions([
    { name: '牛奶', expiryDate: '2027-05-01', expiryText: 'EXP 2027-05-01' },
    { name: '牛奶', expiryDate: '2027-06-01', expiryText: 'EXP 2027-06-01' }
  ]);
  assert.equal(merged.expiry, '');
  assert.ok(merged.conflicts.includes('expiry'));
  assert.ok(merged.warnings.some(value => value.includes('到期日期信息不一致')));
});

test('barcode results are bounded, de-duplicated and sanitized', () => {
  const result = normalizeBarcodeResults([
    { rawValue: ' 6901234567890 ', format: 'EAN-13' },
    { rawValue: '6901234567890', format: 'EAN-13' },
    { rawValue: '<script>x</script>', format: 'QR' },
    { rawValue: ' '.repeat(8), format: 'EAN-8' }
  ]);
  assert.equal(result.length, 2);
  assert.equal(result[0].rawValue, '6901234567890');
  assert.equal(result[1].format, 'QR');
});

test('date helper asks only for an actual opening date when PAO is already known', () => {
  const result = normalizePhotoExtraction({ name: '面霜', paoValue: 6, paoUnit: 'months' });
  assert.deepEqual(photoMissingRequirements(result, ''), ['实际开封日期（如果希望按开封后期限计算）']);
  assert.deepEqual(photoMissingRequirements(result, '2026-11-22'), []);
});

test('photo scan UI supports up to three angles, local barcode scan and assistant follow-up', async () => {
  const html = await read('www/index.html');
  const js = await read('www/app.js');
  assert.match(html, /id="photoCameraInput"[^>]*capture="environment"/);
  assert.match(html, /id="photoGalleryInput"[^>]*multiple/);
  assert.match(html, /id="photoPreviewGrid"/);
  assert.match(html, /id="scanPhotoBarcodeButton"/);
  assert.match(html, /id="photoAskAssistantButton"/);
  assert.match(js, /selectedPhotoDataUrls/);
  assert.match(js, /const available=3-selectedPhotoDataUrls\.length/);
  assert.match(js, /imageDataUrls\.map/);
  assert.match(js, /mergePhotoExtractions/);
  assert.match(js, /ShelfieNative\.scanBarcodes/);
  assert.match(js, /askPhotoAssistantForMissingInfo/);
});


test('multi-photo duration merge detects same number with different units', () => {
  const merged = mergePhotoExtractions([
    { name: '牛奶', manufactureDate: '2026-11-01', shelfLifeValue: 6, shelfLifeUnit: 'months' },
    { name: '牛奶', manufactureDate: '2026-11-01', shelfLifeValue: 6, shelfLifeUnit: 'days' }
  ]);
  assert.equal(merged.shelfLife, null);
  assert.ok(merged.conflicts.includes('shelfLife'));
  assert.equal(merged.fieldConfidence.shelfLife, 'low');
  assert.ok(merged.warnings.some(value => value.includes('保质期期限不一致')));
});
