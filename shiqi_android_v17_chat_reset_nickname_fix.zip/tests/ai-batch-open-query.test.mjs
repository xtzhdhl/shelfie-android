import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import {
  prepareAiBatchCreate,
  prepareAiMutation,
  prepareAiQuery,
  applyAiMutation
} from '../www/ai-mutations.js';

const current = [
  { id: 'milk-1', name: '牛奶', category: '食品饮料', expiry: '2026-11-25', openedDate: '', reminderDays: 3, createdAt: '2026-11-01T00:00:00.000Z' },
  { id: 'cream-2', name: '面霜', category: '护肤美妆', expiry: '2027-03-01', openedDate: '', afterOpeningValue: 6, afterOpeningUnit: 'months', reminderDays: 7, createdAt: '2026-11-02T00:00:00.000Z' }
];
let serial = 0;
const normalize = (candidate, existing = null) => {
  const item = { ...candidate, id: existing?.id || candidate.id || `new-${++serial}`, createdAt: existing?.createdAt || candidate.createdAt || '2026-11-22T00:00:00.000Z' };
  const validDate = value => /^\d{4}-\d{2}-\d{2}$/.test(value || '') && !Number.isNaN(Date.parse(`${value}T12:00:00`));
  if (!item.name || !(validDate(item.expiry) || (validDate(item.manufacture) && Number(item.shelfLife) > 0) || (validDate(item.openedDate) && Number(item.afterOpeningValue) > 0))) return null;
  return item;
};

test('batch create prepares a complete batch and applies it together', () => {
  const prepared = prepareAiBatchCreate([
    { name: '牛奶', expiry: '2026-11-25', category: '食品饮料' },
    { name: '酸奶', manufacture: '2026-11-20', shelfLife: 7, shelfUnit: 'days', category: '食品饮料' }
  ], current, normalize);
  assert.equal(prepared.ok, true);
  assert.equal(prepared.mutation.items.length, 2);
  const next = applyAiMutation(current, prepared.mutation);
  assert.equal(next.length, 4);
  assert.deepEqual(next.slice(-2).map(item => item.name), ['牛奶', '酸奶']);
});

test('batch create is atomic when one item has no valid expiry evidence', () => {
  const prepared = prepareAiBatchCreate([
    { name: '牛奶', expiry: '2026-11-25' },
    { name: '没有日期的饼干' }
  ], current, normalize);
  assert.equal(prepared.ok, false);
  assert.match(prepared.reason, /本批次没有保存任何物品/);
});

test('batch create refuses more than twenty records', () => {
  const prepared = prepareAiBatchCreate(Array.from({ length: 21 }, (_, i) => ({ name: `物品${i}`, expiry: '2026-12-01' })), current, normalize);
  assert.equal(prepared.ok, false);
  assert.match(prepared.reason, /最多整理 20 件/);
});

test('batch apply rejects duplicate IDs and does not return a partial array', () => {
  assert.throws(() => applyAiMutation(current, { type: 'create_batch', items: [
    { id: 'new-x', name: 'A' }, { id: 'milk-1', name: 'B' }
  ] }), /编号重复/);
});

test('record opened updates the exact existing item and preserves its identity', () => {
  const prepared = prepareAiMutation({ type: 'record_opened', itemId: 'cream-2', openedDate: '2026-11-22' }, current, normalize);
  assert.equal(prepared.ok, true);
  assert.equal(prepared.mutation.intent, 'record_opened');
  assert.equal(prepared.mutation.item.openedDate, '2026-11-22');
  assert.equal(prepared.mutation.item.id, 'cream-2');
  assert.equal(prepared.mutation.item.afterOpeningValue, 6);
});

test('record opened refuses malformed dates and unknown item IDs', () => {
  assert.equal(prepareAiMutation({ type: 'record_opened', itemId: 'cream-2', openedDate: 'today' }, current, normalize).ok, false);
  assert.equal(prepareAiMutation({ type: 'record_opened', itemId: 'unknown', openedDate: '2026-11-22' }, current, normalize).ok, false);
});

test('query results only show records whose IDs exist locally', () => {
  const result = prepareAiQuery({ type: 'query_items', itemIds: ['cream-2'] }, current);
  assert.equal(result.ok, true);
  assert.equal(result.items.length, 1);
  assert.equal(result.items[0].name, '面霜');
  assert.equal(prepareAiQuery({ type: 'query_items', itemIds: ['invented-id'] }, current).ok, false);
});

test('AI system prompt documents batch entry, verified queries, and opened-date behavior', async () => {
  const app = await readFile(new URL('../www/app.js', import.meta.url), 'utf8');
  assert.match(app, /create_items/);
  assert.match(app, /query_items/);
  assert.match(app, /record_opened/);
  assert.match(app, /本地今天日期/);
});
