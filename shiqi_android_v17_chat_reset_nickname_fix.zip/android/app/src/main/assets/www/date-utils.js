/** Date-only helpers. Noon-local parsing avoids DST midnight edge cases. */
export function localDate(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function parseDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return null;
  const [y, m, d] = value.split('-').map(Number);
  const date = new Date(y, m - 1, d, 12, 0, 0, 0);
  return date.getFullYear() === y && date.getMonth() === m - 1 && date.getDate() === d ? date : null;
}

export function diffDays(value, today = new Date()) {
  const target = parseDate(value);
  if (!target) return null;
  const current = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 12);
  return Math.round((target - current) / 86400000);
}

export function addShelfLife(dateValue, amount, unit) {
  const d = parseDate(dateValue);
  const n = Number(amount);
  if (!d || !Number.isInteger(n) || n < 1 || !['days', 'months', 'years'].includes(unit)) return '';
  if (unit === 'days') {
    d.setDate(d.getDate() + n);
  } else {
    const originalDay = d.getDate();
    const originalMonth = d.getMonth();
    d.setDate(1);
    if (unit === 'months') d.setMonth(d.getMonth() + n);
    else d.setFullYear(d.getFullYear() + n);
    const lastDay = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    d.setDate(Math.min(originalDay, lastDay));
    if (unit === 'years' && d.getMonth() !== originalMonth) d.setMonth(originalMonth, 1);
  }
  return localDate(d);
}

/**
 * Calculates the effective expiry date. The product's printed expiry remains
 * authoritative unless an explicitly entered after-opening period expires sooner.
 */
export function getExpiryInfo(item = {}) {
  let printedExpiry = parseDate(item.expiry) ? item.expiry : '';
  if (!printedExpiry && parseDate(item.manufacture) && Number.isInteger(Number(item.shelfLife)) && Number(item.shelfLife) > 0) {
    printedExpiry = addShelfLife(item.manufacture, Number(item.shelfLife), item.shelfUnit || 'days');
  }
  const openedDate = parseDate(item.openedDate) ? item.openedDate : '';
  const afterOpeningValue = Number(item.afterOpeningValue);
  const afterOpeningUnit = item.afterOpeningUnit || 'months';
  const afterOpeningExpiry = openedDate && Number.isInteger(afterOpeningValue) && afterOpeningValue > 0
    ? addShelfLife(openedDate, afterOpeningValue, afterOpeningUnit)
    : '';

  if (printedExpiry && afterOpeningExpiry) {
    return printedExpiry <= afterOpeningExpiry
      ? { date: printedExpiry, basis: item.expiry ? 'printed' : 'calculated', printedExpiry, afterOpeningExpiry }
      : { date: afterOpeningExpiry, basis: 'after-opening', printedExpiry, afterOpeningExpiry };
  }
  if (printedExpiry) return { date: printedExpiry, basis: item.expiry ? 'printed' : 'calculated', printedExpiry, afterOpeningExpiry };
  if (afterOpeningExpiry) return { date: afterOpeningExpiry, basis: 'after-opening', printedExpiry, afterOpeningExpiry };
  return { date: '', basis: 'unknown', printedExpiry: '', afterOpeningExpiry: '' };
}

export function getDaysLeft(item, today = new Date()) {
  const expiry = getExpiryInfo(item).date;
  return expiry ? diffDays(expiry, today) : null;
}

export function isValidExpiryRecord(item = {}) {
  const info = getExpiryInfo(item);
  return Boolean(info.date);
}

/** Returns a date offset from a YYYY-MM-DD value using local calendar days. */
export function shiftDate(dateValue, dayOffset) {
  const d = parseDate(dateValue);
  const n = Number(dayOffset);
  if (!d || !Number.isInteger(n)) return '';
  d.setDate(d.getDate() + n);
  return localDate(d);
}

/** The date on which the user-selected reminder should be shown. */
export function getReminderDate(item = {}) {
  const expiry = getExpiryInfo(item).date;
  const reminderDays = Number(item.reminderDays);
  if (!expiry || !Number.isInteger(reminderDays) || reminderDays <= 0) return '';
  return shiftDate(expiry, -reminderDays);
}
