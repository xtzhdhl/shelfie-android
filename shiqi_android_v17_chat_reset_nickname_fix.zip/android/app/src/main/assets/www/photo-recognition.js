import { parseDate } from './date-utils.js';

const ALLOWED_CATEGORIES = ['食品饮料', '护肤美妆', '药品保健', '日用百货', '其他'];
const ALLOWED_UNITS = ['days', 'months', 'years'];
const CONFIDENCE = ['high', 'medium', 'low', 'unreadable'];

function cleanText(value, max = 160) {
  return String(value ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max);
}

function validDate(value) {
  const text = cleanText(value, 20);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return '';
  const parsed = parseDate(text);
  return parsed && !Number.isNaN(parsed.getTime()) ? text : '';
}

function positiveInteger(value, max = 36500) {
  const number = Number(value);
  return Number.isInteger(number) && number > 0 && number <= max ? number : null;
}

function categoryFromText(value) {
  const text = String(value ?? '');
  if (ALLOWED_CATEGORIES.includes(text)) return text;
  if (/面霜|精华|护肤|口红|乳液|化妆|防晒|洗发|沐浴/i.test(text)) return '护肤美妆';
  if (/药|维生素|胶囊|片剂|保健/i.test(text)) return '药品保健';
  if (/洗涤|清洁|纸巾|收纳|日用/i.test(text)) return '日用百货';
  if (/牛奶|饮料|食品|面包|零食|酸奶|饼干|水果/i.test(text)) return '食品饮料';
  return '其他';
}

function confidenceValue(value) {
  const candidate = String(value ?? '').toLowerCase();
  return CONFIDENCE.includes(candidate) ? candidate : 'low';
}

/**
 * Normalize untrusted model output. Only complete, calendar-valid YYYY-MM-DD
 * values are allowed into date controls; partial/ambiguous print text stays text.
 */
export function normalizePhotoExtraction(raw) {
  const source = raw && typeof raw === 'object' ? (raw.result && typeof raw.result === 'object' ? raw.result : raw) : {};
  const warnings = Array.isArray(source.warnings)
    ? source.warnings.map(value => cleanText(value, 180)).filter(Boolean).slice(0, 8)
    : [];

  const manufacture = validDate(source.manufactureDate ?? source.manufacture);
  const expiry = validDate(source.expiryDate ?? source.expiry);
  const shelfLife = positiveInteger(source.shelfLifeValue ?? source.shelfLife);
  const shelfUnitRaw = source.shelfLifeUnit ?? source.shelfUnit;
  const shelfUnit = ALLOWED_UNITS.includes(shelfUnitRaw) ? shelfUnitRaw : 'days';
  const afterOpeningValue = positiveInteger(source.paoValue ?? source.afterOpeningValue);
  const afterOpeningUnitRaw = source.paoUnit ?? source.afterOpeningUnit;
  const afterOpeningUnit = ALLOWED_UNITS.includes(afterOpeningUnitRaw) ? afterOpeningUnitRaw : 'months';

  if (source.manufactureDate && !manufacture) warnings.push('生产日期未能识别为完整有效日期，请按包装核对后手动填写。');
  if (source.expiryDate && !expiry) warnings.push('到期日期未能识别为完整有效日期，请按包装核对后手动填写。');
  if ((source.shelfLifeValue ?? source.shelfLife) != null && !shelfLife) warnings.push('保质期数字不完整或超出合理范围，已留空。');
  if (expiry && manufacture && expiry < manufacture) warnings.push('识别到的到期日期早于生产日期，请重点核对。');

  const confidenceSource = source.fieldConfidence || source.confidence || {};
  const fieldConfidence = {
    name: confidenceValue(confidenceSource.name),
    manufacture: confidenceValue(confidenceSource.manufactureDate ?? confidenceSource.manufacture),
    expiry: confidenceValue(confidenceSource.expiryDate ?? confidenceSource.expiry),
    shelfLife: confidenceValue(confidenceSource.shelfLife),
    pao: confidenceValue(confidenceSource.pao ?? confidenceSource.afterOpening)
  };

  const visibleText = Array.isArray(source.visibleText)
    ? source.visibleText.map(value => cleanText(value, 100)).filter(Boolean).slice(0, 12)
    : [];

  return {
    name: cleanText(source.name, 40),
    category: ALLOWED_CATEGORIES.includes(source.category) ? source.category : categoryFromText(source.name || source.category),
    manufacture,
    expiry,
    shelfLife,
    shelfUnit,
    openedDate: '',
    afterOpeningValue,
    afterOpeningUnit,
    manufactureText: cleanText(source.manufactureText, 60),
    expiryText: cleanText(source.expiryText, 60),
    batchCode: cleanText(source.batchCode, 60),
    visibleText,
    evidence: cleanText(source.dateEvidence ?? source.evidence, 260),
    fieldConfidence,
    conflicts: Array.isArray(source.conflicts) ? source.conflicts.map(value => cleanText(value, 40)).filter(Boolean).slice(0, 8) : [],
    warnings: [...new Set(warnings)]
  };
}

export function hasPhotoExpiryBasis(extraction, openedDate = '') {
  if (!extraction || typeof extraction !== 'object') return false;
  if (validDate(extraction.expiry)) return true;
  if (validDate(extraction.manufacture) && positiveInteger(extraction.shelfLife)) return true;
  return Boolean(validDate(openedDate) && positiveInteger(extraction.afterOpeningValue));
}

export function photoDateBasisLabel(extraction, openedDate = '') {
  if (!extraction) return '尚未识别';
  if (validDate(extraction.expiry)) return '产品标注到期日';
  if (validDate(extraction.manufacture) && positiveInteger(extraction.shelfLife)) return '生产日期 + 保质期';
  if (validDate(openedDate) && positiveInteger(extraction.afterOpeningValue)) return '开封日期 + 开封后期限';
  return '日期依据不足，需要补充或核对';
}

const CONFIDENCE_RANK = { unreadable: 0, low: 1, medium: 2, high: 3 };

function uniqueValues(values) {
  return [...new Set(values.map(value => cleanText(value, 160)).filter(Boolean))];
}

/**
 * Merge front/back/bottom package photos as one record. Conflicting dates and
 * durations are intentionally blanked rather than selecting one arbitrarily.
 */
export function mergePhotoExtractions(rawResults) {
  const rows = (Array.isArray(rawResults) ? rawResults : [rawResults])
    .slice(0, 3)
    .map(normalizePhotoExtraction);
  if (!rows.length) return normalizePhotoExtraction({});
  if (rows.length === 1) return rows[0];

  const warnings = rows.flatMap(row => row.warnings);
  const conflicts = [];
  const mergeText = (key, label, keepFirst = false) => {
    const values = uniqueValues(rows.map(row => row[key]));
    if (values.length > 1) {
      conflicts.push(key);
      warnings.push(`不同照片中的${label}信息不一致：${values.join(' / ')}。已留空，请对照原包装核对。`);
      return keepFirst ? values[0] : '';
    }
    return values[0] || '';
  };
  const mergeDate = (key, label) => mergeText(key, label, false);
  const mergeDuration = (valueKey, unitKey, label, fallbackUnit) => {
    const values = rows
      .filter(row => Number.isInteger(row[valueKey]) && row[valueKey] > 0)
      .map(row => ({ value: row[valueKey], unit: ALLOWED_UNITS.includes(row[unitKey]) ? row[unitKey] : fallbackUnit }));
    const signatures = [...new Set(values.map(item => `${item.value}:${item.unit}`))];
    if (signatures.length > 1) {
      conflicts.push(valueKey);
      warnings.push(`不同照片中的${label}期限不一致：${signatures.join(' / ')}。已留空，请核对。`);
      return { value: null, unit: fallbackUnit };
    }
    return values[0] || { value: null, unit: fallbackUnit };
  };
  const confidenceKeys = ['name', 'manufacture', 'expiry', 'shelfLife', 'pao'];
  const fieldConfidence = {};
  for (const key of confidenceKeys) {
    const values = rows.map(row => row.fieldConfidence[key]).filter(Boolean);
    const worst = values.length ? values.reduce((a, b) => CONFIDENCE_RANK[a] <= CONFIDENCE_RANK[b] ? a : b) : 'low';
    fieldConfidence[key] = conflicts.includes(key) ? 'low' : worst;
  }
  const visibleText = uniqueValues(rows.flatMap(row => row.visibleText)).slice(0, 24);
  const nameValues = uniqueValues(rows.map(row => row.name));
  const name = nameValues[0] || '';
  if (nameValues.length > 1) { conflicts.push('name'); fieldConfidence.name = 'low'; warnings.push(`不同照片的商品名称识别不一致：${nameValues.join(' / ')}。请人工确认名称。`); }

  const manufacture = mergeDate('manufacture', '生产日期');
  const expiry = mergeDate('expiry', '到期日期');
  const shelfLife = mergeDuration('shelfLife', 'shelfUnit', '保质期', 'days');
  const afterOpening = mergeDuration('afterOpeningValue', 'afterOpeningUnit', '开封后', 'months');
  const batchCode = uniqueValues(rows.map(row => row.batchCode)).join(' / ').slice(0, 60);
  const merged = normalizePhotoExtraction({
    name,
    category: rows.find(row => row.name)?.category || rows[0].category,
    manufactureDate: manufacture,
    expiryDate: expiry,
    shelfLifeValue: shelfLife.value,
    shelfLifeUnit: shelfLife.unit,
    paoValue: afterOpening.value,
    paoUnit: afterOpening.unit,
    manufactureText: uniqueValues(rows.map(row => row.manufactureText)).join(' / ').slice(0, 60),
    expiryText: uniqueValues(rows.map(row => row.expiryText)).join(' / ').slice(0, 60),
    batchCode,
    dateEvidence: uniqueValues(rows.map(row => row.evidence)).join('；').slice(0, 260),
    visibleText,
    fieldConfidence,
    warnings
  });
  merged.conflicts = conflicts;
  const confidenceKeyByConflict = {
    name: 'name', manufacture: 'manufacture', expiry: 'expiry',
    shelfLife: 'shelfLife', afterOpeningValue: 'pao'
  };
  for (const conflict of conflicts) {
    const confidenceKey = confidenceKeyByConflict[conflict];
    if (confidenceKey && merged.fieldConfidence) merged.fieldConfidence[confidenceKey] = 'low';
  }
  merged.warnings = [...new Set([...merged.warnings, ...warnings])].slice(0, 12);
  return merged;
}

/** Keep only safe, bounded, de-duplicated barcode strings from native scanning. */
export function normalizeBarcodeResults(rawResults) {
  const rows = Array.isArray(rawResults) ? rawResults : [];
  const seen = new Set();
  const clean = [];
  for (const row of rows.slice(0, 20)) {
    const rawValue = cleanText(typeof row === 'string' ? row : row?.rawValue, 120);
    if (!rawValue || seen.has(rawValue)) continue;
    seen.add(rawValue);
    clean.push({ rawValue, format: cleanText(typeof row === 'string' ? '' : row?.format, 24) || 'UNKNOWN' });
    if (clean.length >= 10) break;
  }
  return clean;
}

export function photoMissingRequirements(extraction, openedDate = '') {
  if (hasPhotoExpiryBasis(extraction, openedDate)) return [];
  const hasPao = Boolean(positiveInteger(extraction?.afterOpeningValue));
  if (hasPao && !validDate(openedDate)) return ['实际开封日期（如果希望按开封后期限计算）'];
  const hasPrintedExpiry = Boolean(validDate(extraction?.expiry));
  const hasManufacture = Boolean(validDate(extraction?.manufacture));
  const hasShelfLife = Boolean(positiveInteger(extraction?.shelfLife));
  const missing = [];
  if (!hasPrintedExpiry && !(hasManufacture && hasShelfLife)) {
    if (!hasManufacture && !hasShelfLife) {
      missing.push('包装标注的完整到期日，或者生产日期与包装明确标注的保质期限');
    } else if (!hasManufacture) {
      missing.push('生产日期');
    } else if (!hasShelfLife) {
      missing.push('包装明确标注的保质期限');
    }
  }
  if (hasPao && !validDate(openedDate)) missing.push('实际开封日期（如果希望按开封后期限计算）');
  return [...new Set(missing)];
}

