/** Validate AI-proposed mutations against local records before any write occurs. */
export function prepareAiMutation(action, items, normalizeItem) {
  if (!action || typeof action !== 'object') return { ok: false, reason: '指令格式不正确。' };
  const itemId = String(action.itemId || '').trim();
  if (!itemId) return { ok: false, reason: '没有提供可核对的物品编号。' };
  const current = items.find(item => String(item.id) === itemId);
  if (!current) return { ok: false, reason: '我没有在清单里找到这件物品，可能它已经被删除或编号不匹配。' };

  if (action.type === 'delete_item') {
    return { ok: true, mutation: { type: 'delete', itemId, before: current } };
  }

  if (action.type === 'record_opened') {
    const openedDate = String(action.openedDate || '').trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(openedDate)) {
      return { ok: false, reason: '开封日期必须是有效的 YYYY-MM-DD 日期；我没有修改这条记录。' };
    }
    const patch = { openedDate };
    if (action.afterOpeningValue !== undefined && action.afterOpeningValue !== null) {
      const value = Number(action.afterOpeningValue);
      if (!Number.isInteger(value) || value < 1 || value > 36500) {
        return { ok: false, reason: '开封后期限需要是 1 到 36500 之间的整数。' };
      }
      patch.afterOpeningValue = value;
      patch.afterOpeningUnit = ['days', 'months', 'years'].includes(action.afterOpeningUnit)
        ? action.afterOpeningUnit : 'months';
    }
    const updated = normalizeItem({ ...current, ...patch }, current);
    if (!updated || updated.openedDate !== openedDate) {
      return { ok: false, reason: '开封日期无法识别；请提供准确日期，例如 2026-11-22。' };
    }
    return {
      ok: true,
      mutation: {
        type: 'update',
        intent: 'record_opened',
        itemId,
        before: current,
        item: updated
      }
    };
  }

  if (action.type === 'update_item') {
    const patch = action.patch;
    if (!patch || typeof patch !== 'object' || Array.isArray(patch) || Object.keys(patch).length === 0) {
      return { ok: false, reason: '没有提供需要修改的具体内容。' };
    }
    const merged = { ...current, ...patch, id: current.id, createdAt: current.createdAt };
    const updated = normalizeItem(merged, current);
    if (!updated) return { ok: false, reason: '修改后的日期依据不完整或无效，请补充产品标注到期日，或生产日期和保质期，或开封日期和开封后期限。' };
    return { ok: true, mutation: { type: 'update', itemId, before: current, item: updated } };
  }

  return { ok: false, reason: '这个操作暂不支持。' };
}

/** Batch creation is all-or-nothing: one incomplete record blocks the whole batch. */
export function prepareAiBatchCreate(rawItems, existingItems, normalizeItem) {
  if (!Array.isArray(rawItems) || rawItems.length < 1) {
    return { ok: false, reason: '这次没有识别到要记录的物品。' };
  }
  if (rawItems.length > 20) {
    return { ok: false, reason: '一次最多整理 20 件物品，请分批发送。' };
  }

  const ids = new Set(existingItems.map(item => String(item.id)));
  const normalized = [];
  const errors = [];
  rawItems.forEach((raw, index) => {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
      errors.push(`第 ${index + 1} 件物品格式不正确`);
      return;
    }
    const item = normalizeItem(raw);
    if (!item) {
      const label = String(raw.name || `第 ${index + 1} 件物品`).trim();
      errors.push(`「${label}」缺少有效到期依据`);
      return;
    }
    const id = String(item.id || '').trim();
    if (!id || ids.has(id)) {
      errors.push(`「${item.name}」的记录编号重复，请重新整理`);
      return;
    }
    ids.add(id);
    normalized.push(item);
  });

  if (errors.length || normalized.length !== rawItems.length) {
    return {
      ok: false,
      reason: `${errors.join('；')}。本批次没有保存任何物品。请补充每件物品的产品标注到期日，或生产日期＋保质期，或开封日期＋开封后期限后再试。`
    };
  }
  return { ok: true, mutation: { type: 'create_batch', items: normalized } };
}

/** Query actions may only return IDs that are present in the local item list. */
export function prepareAiQuery(action, items) {
  if (!action || action.type !== 'query_items' || !Array.isArray(action.itemIds)) {
    return { ok: false, reason: '查询结果格式不正确，我没有显示未经核对的物品。' };
  }
  if (action.itemIds.length > 100) {
    return { ok: false, reason: '查询结果过多，请缩小一下查询范围。' };
  }
  const byId = new Map(items.map(item => [String(item.id), item]));
  const ids = [...new Set(action.itemIds.map(id => String(id || '').trim()).filter(Boolean))];
  const unknown = ids.filter(id => !byId.has(id));
  if (unknown.length) {
    return { ok: false, reason: '模型返回了无法在本机清单中核对的编号；为避免误报，请换一种说法重新查询。' };
  }
  return { ok: true, items: ids.map(id => byId.get(id)) };
}

export function applyAiMutation(items, mutation) {
  if (mutation.type === 'create') return [...items, mutation.item];
  if (mutation.type === 'create_batch') {
    const existingIds = new Set(items.map(item => String(item.id)));
    const incomingIds = mutation.items.map(item => String(item.id));
    if (incomingIds.some(id => !id || existingIds.has(id)) || new Set(incomingIds).size !== incomingIds.length) {
      throw new Error('批量记录编号重复；没有保存任何物品，请重新整理。');
    }
    return [...items, ...mutation.items];
  }
  if (mutation.type === 'update') {
    let found = false;
    const next = items.map(item => {
      if (String(item.id) !== String(mutation.itemId)) return item;
      found = true;
      return mutation.item;
    });
    if (!found) throw new Error('待修改物品已不存在。');
    return next;
  }
  if (mutation.type === 'delete') {
    const next = items.filter(item => String(item.id) !== String(mutation.itemId));
    if (next.length === items.length) throw new Error('待删除物品已不存在。');
    return next;
  }
  throw new Error('不支持的物品操作。');
}
