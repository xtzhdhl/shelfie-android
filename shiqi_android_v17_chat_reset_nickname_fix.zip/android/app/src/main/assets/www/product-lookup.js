const SOURCES = [
  { id: 'food', label: 'Open Food Facts', host: 'world.openfoodfacts.org', category: '食品饮料' },
  { id: 'beauty', label: 'Open Beauty Facts', host: 'world.openbeautyfacts.org', category: '护肤美妆' },
  { id: 'petfood', label: 'Open Pet Food Facts', host: 'world.openpetfoodfacts.org', category: '食品饮料' },
  { id: 'products', label: 'Open Products Facts', host: 'world.openproductsfacts.org', category: '日用百货' }
];

const PRODUCT_FIELDS = [
  'code', 'product_name', 'product_name_zh', 'product_name_en', 'generic_name',
  'brands', 'quantity', 'categories', 'categories_tags', 'image_front_url',
  'image_front_small_url', 'url', 'labels', 'product_type'
].join(',');

function clean(value, max = 180) {
  return String(value ?? '').replace(/<[^>]*>/g, ' ').replace(/[\u0000-\u001f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
}

function hasValidGtinCheckDigit(code) {
  const digits = [...code].map(Number);
  if (digits.some(value => !Number.isInteger(value))) return false;
  const body = digits.slice(0, -1).reverse();
  const sum = body.reduce((total, digit, index) => total + digit * (index % 2 === 0 ? 3 : 1), 0);
  return (10 - (sum % 10)) % 10 === digits[digits.length - 1];
}

export function normalizeBarcodeCode(value) {
  const text = clean(value, 80).replace(/[\s-]/g, '');
  return /^\d{8,14}$/.test(text) && hasValidGtinCheckDigit(text) ? text : '';
}

function categoryFromText(text, fallback) {
  const value = String(text ?? '');
  if (/药|维生素|胶囊|片剂|保健/i.test(value)) return '药品保健';
  if (/护肤|面霜|精华|口红|乳液|化妆|防晒|洗发|沐浴|beauty|cosmetic/i.test(value)) return '护肤美妆';
  if (/洗涤|清洁|纸巾|收纳|日用|household/i.test(value)) return '日用百货';
  if (/牛奶|饮料|食品|面包|零食|酸奶|饼干|水果|food/i.test(value)) return '食品饮料';
  return fallback || '其他';
}

export function normalizeProductRecord(raw, source = {}) {
  if (!raw || typeof raw !== 'object') return null;
  const product = raw.product && typeof raw.product === 'object' ? raw.product : raw;
  const code = clean(product.code ?? raw.code, 40);
  const name = clean(product.product_name_zh || product.product_name || product.product_name_en || product.generic_name || product.abbreviated_product_name, 100);
  if (!name) return null;
  const brand = clean(product.brands, 100);
  const quantity = clean(product.quantity, 60);
  const categories = clean(product.categories, 180);
  const image = [product.image_front_small_url, product.image_front_url].find(value => /^https:\/\//i.test(String(value || ''))) || '';
  const productType = clean(product.product_type, 24);
  const productSource = SOURCES.find(item => item.id === productType) || source;
  const fallbackCategory = productType === 'petfood' ? '其他' : (productSource.category || source.category || '其他');
  return {
    code,
    name,
    brand,
    quantity,
    category: productType === 'petfood' ? '其他' : categoryFromText(`${categories} ${name}`, fallbackCategory),
    categories,
    image,
    source: clean(productSource.label || source.label || source.id || 'Open Facts', 60),
    sourceHost: clean(productSource.host || source.host || 'world.openfoodfacts.org', 100),
    sourceUrl: code && (productSource.host || source.host) ? `https://${productSource.host || source.host}/product/${encodeURIComponent(code)}` : clean(product.url, 240)
  };
}

async function requestJson(request, url, signal) {
  if (typeof request === 'function') return request(url, signal);
  const response = await fetch(url, { method: 'GET', headers: { Accept: 'application/json' }, signal });
  const data = await response.json().catch(() => ({}));
  return { httpStatus: response.status, data };
}

function foundV3(data) {
  return Boolean(data && data.product && (data.status === 'success' || data.status === 'success_with_warnings' || data.product.product_name || data.product.product_name_zh));
}

function foundV2(data) {
  return Boolean(data && (data.status === 1 || data.status === '1') && data.product);
}

const barcodeResultCache = new Map();
let lastBarcodeLookupAt = 0;

/**
 * Search all product types through the current v3 API first. If that misses,
 * query the four maintained Open Facts deployments via the compatible v2
 * barcode endpoint. A miss is a normal result, not a fatal error.
 */
export async function lookupBarcode(value, options = {}) {
  const code = normalizeBarcodeCode(value);
  if (!code) return { status: 'invalid', code: '', products: [], message: '请填写 8–14 位数字条码。' };
  const request = options.request;
  const now = typeof options.now === 'function' ? options.now() : Date.now();
  const cached = barcodeResultCache.get(code);
  if (cached && now - cached.at < 15 * 60 * 1000) return { ...cached.result, cached: true, message: `${cached.result.message}（本机短时缓存）` };
  const minBarcodeIntervalMs = Math.max(0, Number(options.minBarcodeIntervalMs ?? 20000));
  if (lastBarcodeLookupAt && now - lastBarcodeLookupAt < minBarcodeIntervalMs) {
    return { status: 'rate-limited', code, products: [], message: '公开商品目录有访问频率限制，请间隔约 20 秒再查；相同条码的查询结果会短时缓存。' };
  }
  lastBarcodeLookupAt = now;
  const timeoutMs = Math.max(1000, Math.min(20000, Number(options.timeoutMs) || 10000));
  const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
  const errors = [];
  try {
    const fields = encodeURIComponent(PRODUCT_FIELDS);
    const v3Url = `https://world.openfoodfacts.org/api/v3/product/${encodeURIComponent(code)}.json?product_type=all&lc=zh&cc=sg&fields=${fields}`;
    try {
      const response = await requestJson(request, v3Url, controller?.signal);
      if (foundV3(response?.data)) {
        const record = normalizeProductRecord(response.data, { id: 'all', label: 'Open Facts 商品目录', host: 'world.openfoodfacts.org', category: '其他' });
        if (record) { const result = { status: 'found', code, products: [record], message: '已在 Open Facts 商品目录中找到资料。', strategy: 'v3-all-types' }; barcodeResultCache.set(code, { at: now, result }); return result; }
      }
    } catch (error) {
      errors.push(clean(error?.message || 'v3 查询失败', 120));
    }

    const results = await Promise.all(SOURCES.map(async source => {
      const url = `https://${source.host}/api/v2/product/${encodeURIComponent(code)}.json?fields=${fields}&lc=zh`;
      try {
        const response = await requestJson(request, url, controller?.signal);
        if (foundV2(response?.data)) return normalizeProductRecord(response.data, source);
      } catch (error) {
        errors.push(`${source.label}: ${clean(error?.message || '查询失败', 90)}`);
      }
      return null;
    }));
    const products = results.filter(Boolean);
    if (products.length) { const result = { status: 'found', code, products: deduplicateProducts(products), message: '已在备用商品目录中找到资料。', strategy: 'v2-cross-database' }; barcodeResultCache.set(code, { at: now, result }); return result; }
    if (errors.length >= SOURCES.length + 1) return { status: 'error', code, products: [], message: '暂时无法连接商品数据库，请检查网络后重试。', errors: [...new Set(errors)].slice(0, 5) };
    const result = { status: 'not-found', code, products: [], message: '条码有效，但目前这些公开目录没有收录。可以继续拍照识别或手动录入。' }; barcodeResultCache.set(code, { at: now, result }); return result;
  } finally {
    if (timer) clearTimeout(timer);
  }
}

function deduplicateProducts(products) {
  const seen = new Set();
  return products.filter(product => {
    const key = `${product.code}|${product.name.toLowerCase()}|${product.brand.toLowerCase()}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

let lastTextSearchAt = 0;

/** Manual, submit-only text lookup. Never intended for search-as-you-type. */
export async function searchProducts(query, options = {}) {
  const term = clean(query, 80);
  if (term.length < 2) return { status: 'invalid', query: term, products: [], message: '至少输入 2 个字符再搜索。' };
  const now = typeof options.now === 'function' ? options.now() : Date.now();
  const minSearchIntervalMs = Math.max(0, Number(options.minSearchIntervalMs ?? 30000));
  if (lastTextSearchAt && now - lastTextSearchAt < minSearchIntervalMs) {
    return { status: 'rate-limited', query: term, products: [], message: '为了避免公开数据库限制访问，名称搜索请间隔约 30 秒再试；你可以先使用条码或照片识别。' };
  }
  lastTextSearchAt = now;
  const request = options.request;
  const timeoutMs = Math.max(1000, Math.min(20000, Number(options.timeoutMs) || 12000));
  const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
  const errors = [];
  try {
    const results = await Promise.all(SOURCES.map(async source => {
      const params = new URLSearchParams({
        search_terms: term,
        search_simple: '1',
        action: 'process',
        json: '1',
        page_size: '8',
        fields: PRODUCT_FIELDS,
        lc: 'zh'
      });
      const url = `https://${source.host}/cgi/search.pl?${params.toString()}`;
      try {
        const response = await requestJson(request, url, controller?.signal);
        const rows = Array.isArray(response?.data?.products) ? response.data.products : [];
        return rows.map(row => normalizeProductRecord(row, source)).filter(Boolean);
      } catch (error) {
        errors.push(`${source.label}: ${clean(error?.message || '查询失败', 90)}`);
        return [];
      }
    }));
    const products = deduplicateProducts(results.flat()).slice(0, 16);
    if (products.length) return { status: 'found', query: term, products, message: `找到 ${products.length} 条可能匹配的商品资料。` };
    if (errors.length === SOURCES.length) return { status: 'error', query: term, products: [], message: '暂时无法连接商品数据库，请检查网络后重试。', errors };
    return { status: 'not-found', query: term, products: [], message: '公开目录中没有找到匹配商品。你仍然可以用这个名称手动建档。' };
  } finally {
    if (timer) clearTimeout(timer);
  }
}
