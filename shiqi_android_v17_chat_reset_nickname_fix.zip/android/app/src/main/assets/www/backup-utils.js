const DEFAULT_ITERATIONS = 310000;

function bytesToBase64(bytes) {
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function base64ToBytes(value) {
  const binary = atob(String(value || ''));
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function deriveKey(passphrase, salt, cryptoApi, iterations) {
  const material = await cryptoApi.subtle.importKey(
    'raw', new TextEncoder().encode(passphrase), 'PBKDF2', false, ['deriveKey']
  );
  return cryptoApi.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations, hash: 'SHA-256' },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export async function encryptBackupPayload(payload, passphrase, cryptoApi = globalThis.crypto) {
  if (!cryptoApi?.subtle || !cryptoApi?.getRandomValues) throw new Error('当前设备不支持加密备份');
  if (typeof passphrase !== 'string' || passphrase.length < 8) throw new Error('备份密码至少需要 8 个字符');
  const salt = cryptoApi.getRandomValues(new Uint8Array(16));
  const iv = cryptoApi.getRandomValues(new Uint8Array(12));
  const iterations = DEFAULT_ITERATIONS;
  const key = await deriveKey(passphrase, salt, cryptoApi, iterations);
  const plaintext = new TextEncoder().encode(JSON.stringify(payload));
  const ciphertext = await cryptoApi.subtle.encrypt({ name: 'AES-GCM', iv }, key, plaintext);
  return {
    format: 'SHELFIE_FULL_BACKUP',
    formatVersion: 1,
    cipher: 'AES-256-GCM',
    kdf: 'PBKDF2-SHA-256',
    iterations,
    salt: bytesToBase64(salt),
    iv: bytesToBase64(iv),
    ciphertext: bytesToBase64(new Uint8Array(ciphertext))
  };
}

export async function decryptBackupPayload(envelope, passphrase, cryptoApi = globalThis.crypto) {
  if (!cryptoApi?.subtle) throw new Error('当前设备不支持解密备份');
  if (!envelope || envelope.format !== 'SHELFIE_FULL_BACKUP' || envelope.formatVersion !== 1 || envelope.cipher !== 'AES-256-GCM' || envelope.kdf !== 'PBKDF2-SHA-256') {
    throw new Error('不是受支持的拾期加密备份');
  }
  if (typeof passphrase !== 'string' || !passphrase) throw new Error('请输入备份密码');
  const iterations = Number(envelope.iterations);
  if (!Number.isInteger(iterations) || iterations < 100000 || iterations > 1000000) throw new Error('备份加密参数无效');
  const salt = base64ToBytes(envelope.salt);
  const iv = base64ToBytes(envelope.iv);
  const ciphertext = base64ToBytes(envelope.ciphertext);
  if (salt.length !== 16 || iv.length !== 12 || ciphertext.length < 16 || ciphertext.length > 80 * 1024 * 1024) throw new Error('备份文件内容异常');
  const key = await deriveKey(passphrase, salt, cryptoApi, iterations);
  const plaintext = await cryptoApi.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext);
  const payload = JSON.parse(new TextDecoder().decode(plaintext));
  if (!payload || payload.app !== 'SHELFIE' || !Array.isArray(payload.items)) throw new Error('备份内容格式不正确');
  return payload;
}
