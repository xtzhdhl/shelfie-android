package com.shelfie.expiry;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Encrypts the user's API key at rest with a non-exportable Android Keystore AES key. */
public final class ApiKeyVault {
    private static final String KEY_ALIAS = "shelfie_api_key_aes_v1";
    private static final String PREFS = "shelfie_secure_secrets";
    private static final String PREF_IV = "api_key_iv";
    private static final String PREF_CIPHER = "api_key_ciphertext";
    private static final int GCM_TAG_BITS = 128;

    private ApiKeyVault() {}

    public static synchronized boolean save(Context context, String value) {
        if (value == null || value.trim().isEmpty()) return clear(context);
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
            byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
            SharedPreferences prefs = context.getApplicationContext()
                    .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            return prefs.edit()
                    .putString(PREF_IV, Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP))
                    .putString(PREF_CIPHER, Base64.encodeToString(encrypted, Base64.NO_WRAP))
                    .commit();
        } catch (Exception e) {
            android.util.Log.e("Shelfie", "Unable to encrypt API key", e);
            return false;
        }
    }

    public static synchronized String read(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String ivText = prefs.getString(PREF_IV, null);
        String encryptedText = prefs.getString(PREF_CIPHER, null);
        if (ivText == null || encryptedText == null) return "";
        try {
            byte[] iv = Base64.decode(ivText, Base64.NO_WRAP);
            byte[] encrypted = Base64.decode(encryptedText, Base64.NO_WRAP);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(GCM_TAG_BITS, iv));
            return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
        } catch (Exception e) {
            // A restored app backup may contain ciphertext without its device-bound Keystore key.
            android.util.Log.e("Shelfie", "Unable to decrypt saved API key; clearing unusable secret", e);
            clear(context);
            return "";
        }
    }

    public static synchronized boolean hasValue(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return prefs.contains(PREF_IV) && prefs.contains(PREF_CIPHER);
    }

    public static synchronized boolean clear(Context context) {
        boolean prefsCleared = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove(PREF_IV).remove(PREF_CIPHER).commit();
        try {
            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);
            if (keyStore.containsAlias(KEY_ALIAS)) keyStore.deleteEntry(KEY_ALIAS);
        } catch (Exception e) {
            android.util.Log.w("Shelfie", "Unable to remove API key Keystore entry", e);
            return false;
        }
        return prefsCleared;
    }

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(KEY_ALIAS)) {
            return (SecretKey) keyStore.getKey(KEY_ALIAS, null);
        }
        KeyGenerator generator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .setKeySize(256)
                .build();
        generator.init(spec);
        return generator.generateKey();
    }
}
