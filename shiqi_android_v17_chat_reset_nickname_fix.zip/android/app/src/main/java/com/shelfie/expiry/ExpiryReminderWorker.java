package com.shelfie.expiry;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Delivers a local expiry reminder. WorkManager persists and restores this work across reboot. */
public final class ExpiryReminderWorker extends Worker {
    public static final String CHANNEL_ID = "shelfie_expiry_reminders";
    public static final String KEY_ITEM_ID = "item_id";
    public static final String KEY_ITEM_NAME = "item_name";
    public static final String KEY_EXPIRY_DATE = "expiry_date";
    public static final String KEY_LOCATION = "location";

    public ExpiryReminderWorker(Context context, WorkerParameters params) {
        super(context, params);
    }

    @Override
    public Result doWork() {
        Context context = getApplicationContext();
        if (Build.VERSION.SDK_INT >= 33 &&
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // Permission was not granted. Do not crash or repeatedly retry in the background.
            return Result.success();
        }
        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) return Result.success();

        createChannel(context);
        String itemId = getInputData().getString(KEY_ITEM_ID);
        String name = getInputData().getString(KEY_ITEM_NAME);
        String expiry = getInputData().getString(KEY_EXPIRY_DATE);
        String location = getInputData().getString(KEY_LOCATION);
        if (name == null || name.trim().isEmpty() || expiry == null || expiry.isEmpty()) return Result.failure();

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pending = PendingIntent.getActivity(
                context,
                stableId(itemId),
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0)
        );

        String body = "预计到期日：" + expiry + "。记得检查一下";
        if (location != null && !location.trim().isEmpty()) body += "（存放位置：" + location + "）";

        androidx.core.app.NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_shelfie)
                .setContentTitle("拾期提醒 · " + name)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setContentIntent(pending);

        try {
            NotificationManagerCompat.from(context).notify(stableId(itemId), builder.build());
        } catch (SecurityException ignored) {
            // User may revoke notification permission between the permission check and notify().
        }
        return Result.success();
    }

    private static int stableId(String value) {
        int id = value == null ? 1 : value.hashCode();
        return id == Integer.MIN_VALUE ? 1 : Math.max(1, Math.abs(id));
    }

    private static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null || manager.getNotificationChannel(CHANNEL_ID) != null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "物品到期提醒", NotificationManager.IMPORTANCE_DEFAULT);
        channel.setDescription("在物品达到你设置的提前提醒日期时通知你");
        manager.createNotificationChannel(channel);
    }
}
