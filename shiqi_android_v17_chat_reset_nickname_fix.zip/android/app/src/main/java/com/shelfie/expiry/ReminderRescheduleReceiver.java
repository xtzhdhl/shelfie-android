package com.shelfie.expiry;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/** Recomputes local 09:00 reminder times after clock/date/time-zone changes. */
public final class ReminderRescheduleReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        final String action = intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_TIME_CHANGED.equals(action)
                && !Intent.ACTION_TIMEZONE_CHANGED.equals(action)
                && !Intent.ACTION_DATE_CHANGED.equals(action)) return;

        Context app = context.getApplicationContext();
        ShelfieDatabase database = new ShelfieDatabase(app);
        try {
            ShelfieReminderScheduler.scheduleAll(app, database.readAll());
        } catch (Exception e) {
            Log.e("Shelfie", "Could not rebuild expiry reminders", e);
        } finally {
            database.close();
        }
    }
}
