package com.shelfie.expiry;

import android.content.Context;

import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

/** Schedules one inexact, battery-friendly reminder per item at 09:00 local time. */
public final class ShelfieReminderScheduler {
    private static final String UNIQUE_PREFIX = "shelfie-expiry-";
    private static final String TAG = "shelfie-expiry-reminder";

    private ShelfieReminderScheduler() {}

    public static void cancel(Context context, String itemId) {
        if (itemId == null || itemId.trim().isEmpty()) return;
        WorkManager.getInstance(context.getApplicationContext()).cancelUniqueWork(UNIQUE_PREFIX + itemId);
    }

    public static void scheduleAll(Context context, JSONArray items) {
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item != null) schedule(context, item);
        }
    }

    public static void schedule(Context context, JSONObject item) {
        String id = item.optString("id", "").trim();
        String name = item.optString("name", "").trim();
        String expiry = optString(item, "effectiveExpiry", "").trim();
        String reminderDate = optString(item, "reminderDate", "").trim();
        int reminderDays = item.optInt("reminderDays", 7);

        if (id.isEmpty()) return;
        cancel(context, id);
        if (name.isEmpty() || expiry.isEmpty() || reminderDate.isEmpty() || reminderDays <= 0) return;

        // Do not schedule reminders for items that have already expired.
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        if (expiry.compareTo(today) < 0) return;

        long triggerAt = localNineAm(reminderDate);
        if (triggerAt < 0) return;
        long delay = Math.max(0L, triggerAt - System.currentTimeMillis());

        Data data = new Data.Builder()
                .putString(ExpiryReminderWorker.KEY_ITEM_ID, id)
                .putString(ExpiryReminderWorker.KEY_ITEM_NAME, name)
                .putString(ExpiryReminderWorker.KEY_EXPIRY_DATE, expiry)
                .putString(ExpiryReminderWorker.KEY_LOCATION, optString(item, "location", ""))
                .build();

        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(ExpiryReminderWorker.class)
                .setInputData(data)
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .addTag(TAG)
                .build();
        WorkManager.getInstance(context.getApplicationContext()).enqueueUniqueWork(
                UNIQUE_PREFIX + id, ExistingWorkPolicy.REPLACE, request);
    }

    private static String optString(JSONObject item, String key, String fallback) {
        if (!item.has(key) || item.isNull(key)) return fallback;
        return item.optString(key, fallback);
    }

    private static long localNineAm(String dateValue) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        format.setLenient(false);
        format.setTimeZone(TimeZone.getDefault());
        ParsePosition position = new ParsePosition(0);
        Date date = format.parse(dateValue, position);
        if (date == null || position.getIndex() != dateValue.length()) return -1L;
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 9);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTimeInMillis();
    }
}
