package com.shelfie.expiry;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/** Local, private SQLite store for Shelfie item records. */
public final class ShelfieDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "shelfie.db";
    private static final int DB_VERSION = 1;
    private static final String TABLE = "items";

    public ShelfieDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " (" +
                "id TEXT PRIMARY KEY NOT NULL," +
                "name TEXT NOT NULL," +
                "category TEXT NOT NULL," +
                "quantity INTEGER NOT NULL DEFAULT 1," +
                "manufacture TEXT," +
                "shelf_life INTEGER," +
                "shelf_unit TEXT," +
                "expiry TEXT," +
                "opened_date TEXT," +
                "after_opening_value INTEGER," +
                "after_opening_unit TEXT," +
                "location TEXT," +
                "note TEXT," +
                "reminder_days INTEGER NOT NULL DEFAULT 7," +
                "created_at TEXT," +
                "effective_expiry TEXT," +
                "reminder_date TEXT" +
                ")");
        db.execSQL("CREATE INDEX idx_items_effective_expiry ON " + TABLE + "(effective_expiry)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Version 1 is the first SQLite-backed release. Future migrations belong here.
    }

    /** Atomically synchronizes the current item list and returns IDs removed by the sync. */
    public Set<String> replaceAll(JSONArray items) throws JSONException {
        SQLiteDatabase db = getWritableDatabase();
        Set<String> previousIds = new HashSet<>();
        Set<String> currentIds = new HashSet<>();
        db.beginTransaction();
        try {
            try (Cursor c = db.query(TABLE, new String[]{"id"}, null, null, null, null, null)) {
                while (c.moveToNext()) previousIds.add(c.getString(0));
            }

            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                if (item == null) continue;
                String id = item.optString("id", "").trim();
                String name = item.optString("name", "").trim();
                if (id.isEmpty() || name.isEmpty()) continue;
                currentIds.add(id);

                ContentValues v = new ContentValues();
                v.put("id", id);
                v.put("name", name);
                v.put("category", optString(item, "category", "其他"));
                v.put("quantity", Math.max(1, item.optInt("quantity", 1)));
                putNullable(v, "manufacture", optString(item, "manufacture", ""));
                putNullableInt(v, "shelf_life", item, "shelfLife");
                putNullable(v, "shelf_unit", optString(item, "shelfUnit", "days"));
                putNullable(v, "expiry", optString(item, "expiry", ""));
                putNullable(v, "opened_date", optString(item, "openedDate", ""));
                putNullableInt(v, "after_opening_value", item, "afterOpeningValue");
                putNullable(v, "after_opening_unit", optString(item, "afterOpeningUnit", "months"));
                putNullable(v, "location", optString(item, "location", ""));
                putNullable(v, "note", optString(item, "note", ""));
                v.put("reminder_days", Math.max(0, Math.min(30, item.optInt("reminderDays", 7))));
                putNullable(v, "created_at", optString(item, "createdAt", ""));
                putNullable(v, "effective_expiry", optString(item, "effectiveExpiry", ""));
                putNullable(v, "reminder_date", optString(item, "reminderDate", ""));
                long rowId = db.insertWithOnConflict(TABLE, null, v, SQLiteDatabase.CONFLICT_REPLACE);
                if (rowId < 0) throw new android.database.SQLException("Unable to persist item " + id);
            }

            // Remove records deleted in the UI/import flow.
            for (String oldId : previousIds) {
                if (!currentIds.contains(oldId)) {
                    db.delete(TABLE, "id=?", new String[]{oldId});
                }
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }

        previousIds.removeAll(currentIds);
        return previousIds;
    }

    public JSONArray readAll() throws JSONException {
        JSONArray result = new JSONArray();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.query(TABLE, null, null, null, null, null, "rowid ASC")) {
            while (c.moveToNext()) {
                JSONObject item = new JSONObject();
                item.put("id", c.getString(c.getColumnIndexOrThrow("id")));
                item.put("name", c.getString(c.getColumnIndexOrThrow("name")));
                item.put("category", c.getString(c.getColumnIndexOrThrow("category")));
                item.put("quantity", c.getInt(c.getColumnIndexOrThrow("quantity")));
                putFromCursor(item, c, "manufacture", "manufacture");
                putFromCursor(item, c, "shelfLife", "shelf_life");
                putFromCursor(item, c, "shelfUnit", "shelf_unit");
                putFromCursor(item, c, "expiry", "expiry");
                putFromCursor(item, c, "openedDate", "opened_date");
                putFromCursor(item, c, "afterOpeningValue", "after_opening_value");
                putFromCursor(item, c, "afterOpeningUnit", "after_opening_unit");
                putFromCursor(item, c, "location", "location");
                putFromCursor(item, c, "note", "note");
                item.put("reminderDays", c.getInt(c.getColumnIndexOrThrow("reminder_days")));
                putFromCursor(item, c, "createdAt", "created_at");
                putFromCursor(item, c, "effectiveExpiry", "effective_expiry");
                putFromCursor(item, c, "reminderDate", "reminder_date");
                result.put(item);
            }
        }
        return result;
    }

    private static String optString(JSONObject item, String key, String fallback) {
        if (!item.has(key) || item.isNull(key)) return fallback;
        return item.optString(key, fallback);
    }

    private static void putNullable(ContentValues values, String key, String value) {
        if (value == null || value.trim().isEmpty()) values.putNull(key);
        else values.put(key, value);
    }

    private static void putNullableInt(ContentValues values, String column, JSONObject item, String key) {
        if (!item.has(key) || item.isNull(key)) {
            values.putNull(column);
            return;
        }
        Object value = item.opt(key);
        if (value instanceof Number) values.put(column, ((Number) value).intValue());
        else {
            try { values.put(column, Integer.parseInt(String.valueOf(value))); }
            catch (Exception ignored) { values.putNull(column); }
        }
    }

    private static void putFromCursor(JSONObject target, Cursor cursor, String jsonKey, String column) throws JSONException {
        int index = cursor.getColumnIndexOrThrow(column);
        if (cursor.isNull(index)) target.put(jsonKey, JSONObject.NULL);
        else if ("shelf_life".equals(column) || "after_opening_value".equals(column)) target.put(jsonKey, cursor.getInt(index));
        else target.put(jsonKey, cursor.getString(index));
    }
}
