# SHELFIE V1.7.0 Test Report

Date: 2026-11-22

## Automated tests

- `npm test`: **89 passed, 0 failed**.
- `node --check www/app.js`: passed.
- `node --check www/photo-recognition.js`: passed.
- `node --check www/product-lookup.js`: passed.
- `node --check www/ai-mutations.js`: passed.
- `node --check www/date-utils.js`: passed.
- `node --check www/backup-utils.js`: passed.
- HTML IDs: 147 unique, no duplicates.
- Android XML: all XML files parsed successfully.
- Android WebView assets: `www/` and `android/app/src/main/assets/www/` are byte-identical.
- GitHub Actions workflow: parsed with a YAML parser; workflow version and ZIP path checked.

## Regression coverage added

1. Clearing a conversation keeps the API status/nudge node mounted.
2. API status rendering safely handles an absent optional nudge element.
3. Responses started before clearing are discarded and cannot overwrite the new conversation.
4. The latest formal assistant name and nickname are injected into every system prompt.
5. The chat heading dynamically displays the latest assistant nickname.
6. The local clear-chat greeting uses the latest assistant nickname.

## Important limits

The test suite does not call the user's private API endpoint and does not validate real network connectivity. Android APK compilation and onePlus 12 device testing have not yet been performed for this release. Run the supplied GitHub Actions workflow and verify the resulting APK signature before installing as an update.
