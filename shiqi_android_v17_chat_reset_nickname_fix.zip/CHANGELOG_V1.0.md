# 拾期 SHELFIE V1.0 — AI 包装照片识别

## 新增
- 小助手页面增加「拍照识别包装」入口。
- Android WebView 支持调用系统相机拍照，以及从相册选择图片。
- Android 相机图片使用应用私有 cache + FileProvider 临时传递，不写入公共相册。
- 图片在前端按最长边 1440px 压缩为 JPEG；必要时二次压缩，降低视觉模型请求体积。
- 发送照片前必须勾选单次授权；识别结果先进入可编辑核对表，不会自动入库。
- 识别包装名称、分类、生产日期、标注到期日、保质期限、开封后期限（PAO）、批号与可见文字。
- 只接受完整且日历有效的 YYYY-MM-DD 日期；年月不完整、喷码模糊或识别不确定时保留原文并提示用户核对，不补猜日期。
- 用户核对并点击「确认并加入清单」后，才写入现有 SQLite / 本地存储并排程提醒。
- 原始图片不会写入 SQLite 或 JSON 备份；压缩后的识别副本仅在本次页面内存中保留。Android 相机源文件放在应用私有 cache，不进入公共相册；取消拍摄时立即删除，下一次启动相机或 Activity 结束时清理旧文件。

## 安全与使用说明
- 包装照片会发送给用户自己配置的 AI 服务商；请只上传自己有权处理的照片。
- 图片识别需要支持视觉输入的模型。当前 API「测试连接」只测试文本响应，不等于视觉能力测试。
- 部分 OpenAI 兼容服务商可能使用不同的多模态格式；若服务商不支持 `image_url` data URI，需按其接口规范适配。
- 模型结果仅为辅助识别，不构成日期事实保证。用户必须核对原包装，尤其是日期喷码、批号、年月不完整日期与 PAO 标志。

## Android 版本
- versionCode: 8
- versionName: 1.0.0
- Android camera capture uses `MediaStore.ACTION_IMAGE_CAPTURE` + `FileProvider`; gallery selection uses Storage Access Framework (`ACTION_OPEN_DOCUMENT`).

## 验证
- Node.js syntax checks passed.
- 44 automated tests passed (including image extraction validation, date-confidence rules, camera/gallery bridge contract, explicit consent, explicit-save UI, cache cleanup contract, and Android asset synchronization).
- Android Gradle compile and OnePlus 12 camera/gallery end-to-end checks have not yet been run in this environment.
