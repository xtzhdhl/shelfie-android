# SHELFIE V1.6.0

- Fixed the API configuration nudge showing even while saved API settings are present. The root cause was `.message-row { display:flex }` overriding the browser's built-in `[hidden]` display behavior.
- Added a global `[hidden] { display:none !important; }` rule and kept the nudge initially hidden until startup settings are evaluated.
- The nudge now appears only if the Base URL, model, or usable API key is missing, or after a real API test/chat request fails.
- Copy now distinguishes missing configuration from a genuine connection failure. A configured but not-yet-tested API is shown as `已配置`; successful test/request is `连接正常`; failed test/request is `连接失败`.
- No API request is sent automatically at startup, avoiding unwanted token usage.
- Preserved the existing application ID and fixed signing setup; versionCode 16, versionName 1.6.0.
