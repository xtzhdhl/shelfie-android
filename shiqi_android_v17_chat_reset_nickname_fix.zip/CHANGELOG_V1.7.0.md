# SHELFIE V1.7.0

## 修复清空对话后小助手不回复

- 根因：清空对话旧逻辑用 `chatMessages.innerHTML = ''` 删除了 `#apiNudge`；模型成功返回后 `updateApiStatus()` 再访问该节点的 `.hidden`，抛出异常，导致成功响应无法正常显示。
- 清空对话改为保留并重新挂载 API 提示节点。
- `updateApiStatus()` 对状态、提示、按钮节点增加空值保护，聊天区重建不会中断成功回复。
- 引入 `chatGeneration` 世代标记：清空时递增，清空前仍在执行的旧请求返回后会被忽略，不会污染新对话。
- 清空时清理待确认操作并恢复发送按钮。

## 小助手最新昵称同步

- 聊天标题由固定的「和拾期聊聊」改为动态「和{小助手昵称}聊聊」。
- 每次 API 请求的 system prompt 注入当前正式名称、最新昵称和界面显示名称。
- 明确要求模型在自我介绍和回应称呼时采用最新昵称，不沿用旧名字。
- 清空对话后的本地提示也使用最新昵称。

## 版本

- versionName: 1.7.0
- versionCode: 17
- debug applicationId: `com.shelfie.expiry.debug`
- 签名沿用 V1.4 建立的固定 JKS 和原有两个 GitHub Repository Secrets。
