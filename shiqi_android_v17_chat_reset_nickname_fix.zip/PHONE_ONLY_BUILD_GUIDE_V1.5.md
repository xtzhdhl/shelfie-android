# 手机浏览器操作：构建拾期 V1.5

1. 下载 `shiqi_android_v15_chat_avatar_polish.zip`。
2. 打开 GitHub 仓库 `xtzhdhl/shelfie-android`，使用 Chrome 桌面版网站。
3. 仓库根目录 → Add file → Upload files，上传 V1.5 ZIP，Commit changes。
4. 打开 `.github/workflows/build-apk.yml`，将内容完整替换为随本工程提供的 `build-apk-v15.yml` 内容，Commit changes。
5. 不要重新生成签名密钥，也不要更改 Repository Secrets。继续使用已有的 `SHELFIE_KEYSTORE_BASE64` 和 `SHELFIE_KEYSTORE_PASSWORD`。
6. 打开 Actions → `Build and Publish SHELFIE V1.5` → Run workflow → `main`。
7. 成功后检查 Artifact `shelfie-v1.5.0-debug-apk` 与 GitHub Release `v1.5.0`。
8. 在当前 V1.4 固定签名版本上直接安装 V1.5，不要卸载旧版，不要清除数据。若 Android 不允许覆盖安装，请停止，不要卸载；截图查看签名错误原因。

## 本版 UI 设置

设置 → 头像与称呼 → 聊天头像形状 → 选择「圆形」或「矩形」。设置保存在本机个人资料配置里，矩形模式使用竖向圆角矩形裁切。
