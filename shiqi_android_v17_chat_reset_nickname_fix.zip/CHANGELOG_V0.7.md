# 拾期 SHELFIE V0.7 · SQLite 与 Android 系统提醒


- 已实现：新增 `ShelfieDatabase`，使用 Android SQLite 保存物品名称、分类、数量、生产日期、保质期、标注到期日、开封日期、开封后期限、存放位置、备注与提醒天数。
- 已实现：Android 版启动时优先读取 SQLite；首次启动若数据库为空，会将旧版 WebView localStorage 中的物品迁移到 SQLite。浏览器预览仍使用 localStorage。
- 已实现：物品保存/编辑/删除/备份导入时同步 SQLite；数据库保存失败时前端会回滚本次 localStorage 写入并提示。
- 已实现：新增 WorkManager 单次提醒任务，按每件物品的有效到期日期和提醒提前天数，排程在提醒日当地时间 09:00；编辑时替换旧任务，删除时取消任务。
- 已实现：Android 13+ `POST_NOTIFICATIONS` 运行时权限流程、设置页通知状态/入口、通知渠道与本地通知。
- 已实现：设备重启、日期或时区改变后重新计算并排程未来提醒。
- 设计边界：WorkManager 提供可延迟后台执行，不保证分钟级准点；系统省电/厂商后台管控可能使通知延后。
- 尚未验证：本次未完成 Gradle 编译，也未在 OnePlus 12 真机验证通知。需要下一步通过 GitHub Actions 构建并安装后进行真机验收。
- 尚未完成：API Key 的 Android Keystore 加密、OCR、条码扫描、AI 编辑/删除/批量操作、Release 签名。


后续：V0.8 已在 CHANGELOG_V0.8.md 补充 Android Keystore、AI 修改/删除确认和提醒管理中心。
