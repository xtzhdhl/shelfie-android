# SHELFIE V1.5.2 手机构建指南

1. 将 `shiqi_android_v15_2_perfect_circle_avatar.zip` 上传到 `shelfie-android` 仓库根目录。
2. 将仓库 `.github/workflows/build-apk.yml` 全部替换为本轮提供的 V1.5.2 完整 YAML。
3. 确认 Repository Secrets 中仍有 `SHELFIE_KEYSTORE_BASE64` 与 `SHELFIE_KEYSTORE_PASSWORD`。无需重新生成 JKS。
4. Commit changes 后，在 Actions 运行 `Build and Publish SHELFIE V1.5.2`。
5. 验证签名 SHA-256 与固定 JKS 一致后，再通过应用内更新或 Artifact 安装。不要卸载旧版。

版本：versionName 1.5.2，versionCode 15。包名仍为 `com.shelfie.expiry.debug`。
