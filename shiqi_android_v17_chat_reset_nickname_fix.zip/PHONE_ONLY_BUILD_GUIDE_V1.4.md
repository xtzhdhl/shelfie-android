# 手机浏览器操作：构建拾期 V1.4

所有操作可用 Android Chrome 的“桌面版网站”完成。不要把 JKS 或密码上传为普通仓库文件。

## A. 先在 GitHub 配置 4 个 Secrets

1. 打开 `https://github.com/xtzhdhl/shelfie-android`。
2. 进入 Settings → Secrets and variables → Actions → New repository secret。
3. 依次创建以下名称和值：
   - `SHELFIE_KEYSTORE_BASE64`：复制 `SHELFIE_KEYSTORE_BASE64.txt` 的整行内容。
   - `SHELFIE_KEYSTORE_PASSWORD`：复制 `SHELFIE_KEYSTORE_PASSWORD.txt` 的内容。
   - `SHELFIE_KEY_ALIAS`：输入 `shelfie-upload`。
   - `SHELFIE_KEY_PASSWORD`：与 `SHELFIE_KEYSTORE_PASSWORD` 使用同一密码。
4. 每个 Secret 单独点 Add secret 保存。GitHub 保存后不会再次显示 Secret 原值。

## B. 上传源码 ZIP

1. 下载 `shiqi_android_v14_persistent_updates.zip`。
2. 在仓库 Code 页面点击 Add file → Upload files。
3. 上传 ZIP 到仓库根目录，提交到 `main`。

## C. 更新工作流

打开 `.github/workflows/build-apk.yml`，点 Edit，把全文替换为本 ZIP 内 `.github/workflows/build-apk.yml` 或另附的 `build-apk-v14.yml`，提交到 `main`。

## D. 运行构建

打开 Actions → `Build and Publish SHELFIE V1.4` → Run workflow → `main`。

成功后：
- Actions Artifact：`shelfie-v1.4.0-debug-apk`
- GitHub Release：`v1.4.0`，APK 文件 `shelfie-v1.4.0.apk`

## E. 第一次迁移时务必注意

V1.4 首次切换到新的固定签名，旧 Debug APK 可能不能覆盖安装。旧版只支持导出物品 JSON，不支持导出 API Key、头像库、昵称的完整资料。先导出可导出的物品、记下 API 地址和模型，并准备重新录入 API Key、重新上传头像。不要在未保存旧版物品数据前卸载。首次固定签名 V1.4 安装完成后，以后不要卸载应用；通过应用内更新或同签名 APK 覆盖升级。

## 签名密钥保管

单独下载并安全保存 `shelfie-upload-v14.jks`、`SHELFIE_KEYSTORE_PASSWORD.txt` 与 `SHELFIE_KEYSTORE_BASE64.txt`。不要提交到 GitHub 仓库、不要发给他人。未来构建必须一直使用同一份 JKS 和同一组密码；若丢失，未来 APK 将无法覆盖更新当前安装。
