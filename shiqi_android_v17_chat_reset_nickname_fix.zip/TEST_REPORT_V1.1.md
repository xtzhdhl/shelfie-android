# 拾期 SHELFIE V1.1 自动化测试报告

**结果：51 项通过，0 项失败。**

## 覆盖范围
- 日期计算：日期有效性、月底/闰年、时区无关的本地日历日比较、开封后期限、提醒日期。
- AI 清单操作：批量新增原子性、精确 ID 匹配、修改/删除确认、清单查询、开封登记。
- 包装照片识别：严格完整日期、MFG/EXP/保质期/PAO 区分、照片字段清洗、人工确认后保存。
- 多图识别：最多 3 张图片的联合数据流程、相同日期证据合并、不同日期/期限（包括数值相同但单位不同）冲突时清空相关字段，并降低冲突字段置信度。
- 条码处理：条码值去重、长度/数量限制、HTML 标签文本不会被当作可信格式。
- Android 契约：相册多选 ClipData（最多 3 张）、相机 FileProvider、ML Kit 本机扫描桥接、SQLite、WorkManager、Keystore。
- 前端资源：根目录网页与 Android assets 的核心模块保持同步；Service Worker 缓存版本更新并包含 photo-recognition.js。

## 独立静态检查
- `node --check www/app.js`：通过。
- `node --check www/photo-recognition.js`：通过。
- `node --check www/ai-mutations.js`：通过。
- `node --check www/date-utils.js`：通过。
- AndroidManifest.xml、FileProvider paths、styles.xml XML 解析：通过。

## 未执行项目
- 未执行 Gradle APK 编译：当前开发容器没有安装 Gradle/Android SDK，且 Gradle Wrapper 需要下载发行包。
- 未在 OnePlus 12 真机测试相机、相册多选、ML Kit 扫描速度/准确率、图片 EXIF 方向和实际 API 服务商兼容性。
- 自动化测试是源码/逻辑测试，不等同于 Android 真机验收。
