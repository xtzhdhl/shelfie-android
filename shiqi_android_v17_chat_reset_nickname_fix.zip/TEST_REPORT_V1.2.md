# 拾期 SHELFIE V1.2 自动化测试报告

测试日期：2026-11-22
工程版本：1.2.0（versionCode 10）

## 结果

- Node 自动化测试：**63 项通过，0 项失败**。
- `node --check`：`www/` 下全部 JavaScript 文件通过；Android assets 中全部 JavaScript 文件通过。
- HTML 检查：123 个 `id`，无重复。
- XML 检查：`AndroidManifest.xml`、`file_paths.xml` 均可解析。
- 资源同步：`www/` 下 9 个文件与 `android/app/src/main/assets/www/` 逐字节一致。

## 新增商品识别中心覆盖

1. GTIN 条码格式和校验位检查。
2. 商品字段清洗、长度限制、图片 URL HTTPS 限制。
3. 优先调用 Open Facts v3 `product_type=all` 商品接口。
4. v3 未命中时尝试食品、美妆、宠物食品、日用品四个目录的兼容条码接口。
5. 区分“商品未收录”与“网络连接失败”。
6. 商品名称/品牌手动搜索、结果去重、最少输入长度校验。
7. 条码短时缓存、名称搜索冷却，避免高频请求。
8. Android 原生只读网络桥限制 HTTPS、四个官方域名及指定商品/搜索路径；跟随重定向后重新验证协议、端口、域名和路径；限定 GET、连接/读取超时与响应体大小。
9. 目录资料进入待核对草稿，不导入产品日期或保质期，不绕过用户确认。

## 未完成的环境验证

本次执行 `cd android && ./gradlew --no-daemon :app:assembleDebug` 未能完成：Gradle Wrapper 首次运行需要下载 Gradle 8.9，但当前执行环境 DNS 无法解析 `services.gradle.org`（`curl: (6) Could not resolve host`）。当前环境也未配置 `ANDROID_HOME` / `ANDROID_SDK_ROOT`，未检测到 Android SDK。因此本报告**不代表 APK 编译成功**。

未完成 OnePlus 12 真机测试，包括相机拍摄、相册多选、实物条码识别、真实 Open Facts 网络响应、跨品类跳转、离线体验、通知送达、省电限制、SQLite 重启持久化与 API Key Keystore 读写。

## 结论

V1.2 源码和自动化契约测试通过；APK 构建、真实网络和真机运行需要在具备 Android SDK 与网络的环境进行。
