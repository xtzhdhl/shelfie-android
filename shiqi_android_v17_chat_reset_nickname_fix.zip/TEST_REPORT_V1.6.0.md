# SHELFIE V1.6.0 Test Report

- Node.js automated tests: 83 passed, 0 failed.
- JavaScript syntax check (`node --check www/app.js`): passed.
- Android bundled WebView assets compared byte-for-byte with `www`: passed (30 files).
- AndroidManifest.xml XML parsing: passed.
- Build workflow YAML syntax: passed.
- Shell version extraction check: versionName 1.6.0 / versionCode 16 passed.
- Application identity retained: `com.shelfie.expiry.debug` for debug APKs.

## Fix covered

The API setup nudge was visible even when the saved API setup was valid because `.message-row { display:flex }` overrode the browser's default `[hidden]` display rule. The app now includes a global `[hidden] { display:none !important; }` rule and initially hides the nudge while loading settings.

The nudge is shown when Base URL, model or a usable API key is missing. A configured but not-yet-tested API is shown as `已配置`, without an unsolicited request at startup. After a real API test or chat request succeeds, status becomes `连接正常`; after an actual request fails, status becomes `连接失败` and the nudge explains that the saved configuration could not connect.

## Not yet verified

- Cloud APK compilation and Release upload.
- Live API behavior and UI on OnePlus 12.
- In-place installation and data retention on the user's device.
