@echo off
chcp 65001 >nul
cd /d "%~dp0android"
call gradlew.bat assembleDebug
if errorlevel 1 (
  echo.
  echo APK build failed. Please check Android Studio / SDK setup and the error above.
  pause
  exit /b 1
)
copy /Y "app\build\outputs\apk\debug\app-debug.apk" "..\拾期-SHELFIE-debug.apk" >nul
if errorlevel 1 (
  echo Build succeeded but APK copy failed. Find it under android\app\build\outputs\apk\debug\
  pause
  exit /b 1
)
echo.
echo APK ready: %~dp0拾期-SHELFIE-debug.apk
start "" "%~dp0"
pause
