# SHELFIE V1.5.2

## 修复
- 圆形头像固定为正方形尺寸，防止窄屏 Flex 布局将头像压成椭圆。
- 头像图片绝对定位填充头像盒，并使用 `object-fit: cover`，不再参与父容器固有尺寸计算。
- 助手顶部头像、双方聊天消息头像、个人资料头像预览统一使用固定尺寸裁切容器。
- 矩形模式保留独立的竖向尺寸和圆角，不受圆形尺寸规则影响。

## Android 版本
- versionName：1.5.2
- versionCode：15
- applicationId：`com.shelfie.expiry`；debug 包名：`com.shelfie.expiry.debug`
- 沿用 V1.4 建立的 `shelfie-upload` 固定签名配置。
