# SHELFIE V1.5.1 手机构建指南

1. 在 GitHub 仓库根目录上传 `shiqi_android_v15_1_avatar_clip_fix.zip`。
2. 打开 `.github/workflows/build-apk.yml`，将其全部替换为本轮提供的 V1.5.1 完整 YAML。
3. 保留原有 Repository Secrets：`SHELFIE_KEYSTORE_BASE64`、`SHELFIE_KEYSTORE_PASSWORD`，不要重新生成签名密钥。
4. Commit changes 后，在 Actions 运行 `Build and Publish SHELFIE V1.5.1`。
5. 构建完成后先核对 `Verify APK signature and package` 绿色通过，再确认 Artifact 与 Release 成功。
6. 安装前不卸载 V1.4/V1.5。若系统提示签名不一致，取消安装并提供错误截图。

## 本次修复
聊天头像图片和助手标题头像图片现在继承父容器圆角，选择圆形时图片本身会被圆形裁切，选择矩形时则继承圆角矩形裁切。

Android versionName 为 1.5.1，versionCode 为 14，applicationId 为 `com.shelfie.expiry`，debug 包名为 `com.shelfie.expiry.debug`。
