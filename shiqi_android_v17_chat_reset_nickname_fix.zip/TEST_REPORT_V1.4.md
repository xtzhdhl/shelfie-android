# SHELFIE V1.4.0 测试报告

## 自动化结果

- Node.js 自动化测试：**73 / 73 passed，0 failed**
- `node --check www/app.js`：通过
- `node --check www/backup-utils.js`：通过
- GitHub Actions YAML 解析：通过
- Android 主 Manifest 与所有资源 XML 解析：通过
- `www/` 与 `android/app/src/main/assets/www/` 文件同步：通过
- 固定 JKS 签名密钥 alias / 密码有效性：通过

## 本轮新增测试覆盖

- 固定签名构建环境变量及包名稳定性
- 原生 Release 更新检查、APK 包名/版本/签名核验及系统安装器流程
- 应用设置中的自动/手动更新和完整加密备份入口
- 完整备份 AES-GCM 加密/解密、错误密码和损坏数据拒绝
- Android 系统自动备份排除设备绑定 Keystore 密文
- V1.3 头像库、个人资料和主题行为的回归契约

## 未完成的验证

当前容器没有 Android SDK / Gradle 安装环境，因此没有在此生成 APK，也没有执行 Android Gradle 编译。GitHub Actions 运行结果和 OnePlus 12 实机覆盖安装、应用内更新、完整备份恢复仍待验证。
