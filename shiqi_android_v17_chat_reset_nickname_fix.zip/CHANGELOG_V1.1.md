# 拾期 SHELFIE V1.1

## 多角度包装识别
- 一次可通过相机逐张拍摄或相册最多选择 3 张同一商品照片。
- 视觉请求一次性提交多图，模型被要求返回 merged 与 perPhoto 结果。
- 本地把 perPhoto 日期/期限结果再做一次交叉合并；多个照片出现不同日期或期限时，冲突字段清空并要求用户核对。
- 图片仍然需要单次发送授权；原图只暂存在当前页面内存，不写入 SQLite 或 JSON 备份。

## 条码识别
- 加入 Google ML Kit bundled Barcode Scanning 17.3.0。
- Android 端对已选择/压缩的图片进行本机条码识别，支持 EAN-13、EAN-8、UPC-A、UPC-E、Code 128、Code 39、QR 和 Data Matrix。
- 条码扫描不上传图片、不请求网络；识别码可写入物品备注，供日后检索。
- 条码本身不被当作生产日期、到期日期或保质期证据；本版本不包含商品条码数据库查询。

## 日期信息智能补全
- 如果照片没有形成有效到期依据，结果面板显示缺少的具体信息。
- 可以把识别到的文字摘要交给拾期小助手，让它逐次提出 1–2 个核对问题。
- 补充流程不会传送原图，也禁止 AI 猜日期或直接保存记录。

## Android 端
- WebView 文件选择器正式支持相册多选 ClipData（上限 3 张），相机仍逐张拍摄。
- app versionName 1.1.0 / versionCode 9。

## 验证边界
- Node 自动化测试：51/51 通过。
- JavaScript 语法检查与 Android XML 结构检查通过。
- 当前执行环境未安装 Gradle/Android SDK，未完成 APK 编译与实体设备联调；OnePlus 12 的相机、相册多选和 ML Kit 识别仍需安装后验收。
