# 手机更新指南 V1.7.0

1. 将 `shiqi_android_v17_chat_reset_nickname_fix.zip` 上传到仓库根目录。
2. 将 `.github/workflows/build-apk.yml` 全部替换为本工程提供的完整 V1.7.0 工作流。
3. Commit changes。
4. 打开 Actions，手动运行 `Build and Publish SHELFIE V1.7.0`。
5. 确认自动化测试、APK 构建、签名证书指纹验证、Artifact 上传、GitHub Release 发布均成功。
6. 使用应用内更新或 GitHub Release 安装 V1.7.0。沿用固定签名，不卸载、不清除应用数据。

## 真机重点验收

- 清空对话后发送第一条消息，小助手应正常回复。
- 清空前有未完成请求时，迟到的旧回复不应进入新对话。
- 修改小助手昵称并保存后，聊天标题立即显示新昵称。
- 询问小助手“你叫什么”，模型应按最新昵称自我介绍。
