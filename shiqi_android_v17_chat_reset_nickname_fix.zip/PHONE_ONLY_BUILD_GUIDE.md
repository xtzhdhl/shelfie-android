# 拾期 SHELFIE V0.7：只有安卓手机时获取 APK

本工程可通过 GitHub Actions 云端构建，无需在手机安装 Android Studio、Java 或 Android SDK。仓库 `xtzhdhl/shelfie-android` 已由用户创建；将下面步骤用于后续更新工程。

## 1. 上传并解压工程
1. 在手机浏览器进入自己的 `shelfie-android` 仓库。
2. 选择 **Add file → Upload files**，上传 `shiqi_android_v07_sqlite_notifications.zip`。
3. 上传 ZIP 本身不会将项目文件展开，下一步需要用 GitHub Codespaces 解压并提交工程文件。

## 2. 使用 Codespaces 展开并提交
1. 仓库页面选择绿色 **Code → Codespaces → Create codespace on main**。
2. 打开 Terminal，执行：

```bash
unzip -o shiqi_android_v07_sqlite_notifications.zip
cp -a shiqi_android_starter/. .
rm -rf shiqi_android_starter shiqi_android_v07_sqlite_notifications.zip
git add -A
git commit -m "Update SHELFIE to V0.7 SQLite and reminders"
git push
```

如果 ZIP 内顶层目录名发生变化，先运行 `ls` 查看实际文件夹名称，再替换 `cp` 命令里的路径。

## 3. 运行云端构建
1. 回到仓库 **Actions**。
2. 选择 **Build SHELFIE Android APK**。
3. 若没有自动运行，点 **Run workflow → Run workflow**。
4. 绿色成功后打开运行记录底部 **Artifacts**，下载 `shiqi-debug-apk`。
5. 解压 ZIP，得到 `app-debug.apk`，在手机文件管理器中安装。必要时允许文件管理器“安装未知应用”。

## 4. 安装后首次验证
1. 打开拾期，进入 **设置 → 系统到期提醒**，点击“开启系统通知”并允许。
2. 新增一条临时测试物品：把产品到期日设为今天，提醒天数设为 1 天；因提醒日期已过而到期日仍有效，提醒工作将尽快执行。测试后删除该记录。
3. 关闭应用再打开，检查刚才新增的物品仍在，确认 SQLite 本地持久化。
4. 之后再用一条未来物品测试修改/删除是否同步变更提醒。

## 注意
- Debug APK 适合个人试装，不是 Play 商店发布包。
- WorkManager 任务可被系统延迟，不保证分钟级准点；OnePlus 设备需真机验收通知权限及后台策略。
- 卸载应用或清除应用数据会删除 SQLite 记录；重要数据请定期导出 JSON。
