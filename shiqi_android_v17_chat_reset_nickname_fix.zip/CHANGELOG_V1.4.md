# SHELFIE V1.4.0 更新说明

## 重点：数据不再因正常升级而重置

- CI 使用固定私有 JKS 签名密钥，构建时从 GitHub Actions Repository Secrets 注入，不把密钥提交到公开仓库。
- 保持 Android `applicationId` / debug 后缀不变，版本升级为 `versionCode 12`、`versionName 1.4.0`。
- GitHub Actions 完成测试、Gradle 8.9 构建、上传 APK Artifact，并发布带 APK 的 GitHub Release。
- Android 原生更新器从官方公开仓库读取 Latest Release，自动/手动检查新版本。
- 下载时校验 HTTPS 仓库地址、最终下载主机、APK 包名、版本号和签名证书；签名不匹配时明确拦截，不自动卸载。
- 通过 Android 系统安装器请求用户确认更新；系统可能要求允许“安装未知应用”。

## 完整数据备份

- 新增密码加密完整备份：物品、API Key、API Base URL / model 等 API 配置、助手姓名/昵称、用户昵称、双方头像 ID、头像库图片、主题。
- PBKDF2-SHA-256 310,000 次迭代派生 AES-256-GCM 密钥。
- 导入前解密并显示记录/头像数量，用户确认后恢复。
- 保留旧版仅含物品记录的 JSON 导入兼容。
- Android 系统级云备份/设备迁移排除 Android Keystore 绑定的 `shelfie_secure_secrets.xml`，避免恢复不可解密密文。完整 API Key 迁移使用拾期加密完整备份。

## 一次性迁移限制

此前 CI 使用临时 Debug 签名。新固定签名与旧 APK 签名不同，Android 不允许直接覆盖。第一次切换到 V1.4 可能需要手动卸载旧版再安装 V1.4。卸载会删除未导出的旧应用数据。旧 V1.3 只支持物品 JSON 备份，不能完整导出 API Key / 头像 / 昵称；API Key 需要重新录入，头像需要从原图重新上传。一次性迁移到 V1.4 固定签名后，未来同包名、同签名、递增版本号的升级才可保留应用数据。

## 尚未验证

本轮当前容器未执行 Android Gradle APK 编译，也未在 OnePlus 12 真机验证。需先配置四个 GitHub Actions Secrets 并运行工作流；之后真机验收安装覆盖、自动更新、备份恢复、通知、相机和条码功能。
