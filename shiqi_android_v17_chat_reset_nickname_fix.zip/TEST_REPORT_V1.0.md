# 拾期 SHELFIE V1.0 — 自动化测试报告

## 测试结果

- 自动化测试：44 / 44 通过
- 失败：0
- JavaScript 语法检查：通过（`www/app.js`、`www/photo-recognition.js`）
- Android Manifest / FileProvider XML 解析：通过
- 前端资源与 Android WebView assets 同步：通过
- HTML：114 个 ID，无重复 ID

## 覆盖内容

- 商品照片字段提取结果清洗
- 日期必须是完整、有效的 `YYYY-MM-DD`
- MFG、EXP、保质期限和 PAO 区分
- 模糊年月、批号和无法确认的喷码不自动推断
- 发送照片前的明确授权
- 识别草稿需要人工核对并主动确认后才保存
- 原始照片数据不写入物品记录或 JSON 备份
- Android WebView 相机 / 相册文件选择器桥接
- FileProvider 私有缓存路径和临时文件清理
- Android 内置网页资源同步
- V0.9 之前已有的日期计算、AI 批量录入、查询、修改、删除、SQLite、通知与 Keystore 契约测试

## 尚未完成的验证

- Android Gradle APK 编译：当前执行环境无法从 `services.gradle.org` 下载 Gradle 8.9 分发包，因此未能完成编译验证。
- OnePlus 12 真机：尚未在真实设备验证相机 App、相册 URI 读取、不同视觉模型的多模态请求和系统行为。
- 视觉识别效果：取决于用户配置的模型与服务商是否支持 OpenAI Chat Completions 图片输入格式；测试不代表任何具体模型的 OCR 准确率。

## 隐私行为

- 选择照片后先在设备端压缩为 JPEG。
- 用户必须勾选单次授权才会向所配置的 AI 服务商发送照片。
- 照片识别结果仅作为草稿，确认前不写入物品清单。
- 原始照片不进入 SQLite 或 JSON 备份；Android 相机文件位于应用私有 cache，取消拍摄时删除，下一次拍摄或 Activity 销毁时清理。
