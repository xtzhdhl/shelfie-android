import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.shelfie.expiry',
  appName: '拾期',
  webDir: 'www',
  bundledWebRuntime: false,
};

export default config;
