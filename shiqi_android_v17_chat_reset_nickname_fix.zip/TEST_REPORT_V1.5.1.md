# SHELFIE V1.5.1 测试报告

- 自动化测试：79/79 通过，0 失败。
- JavaScript 语法检查：通过（app.js）。
- `www/styles.css` 与 Android assets 样式文件同步：通过。
- Android Gradle applicationId：`com.shelfie.expiry`。
- Debug applicationIdSuffix：`.debug`。
- versionName：`1.5.1`。
- versionCode：`14`。
- 签名环境变量接入方式：延续 V1.4 固定 JKS。

本报告只记录当前环境完成的源码和自动化检查。GitHub 云端 APK 构建及一加 12 真机圆形/矩形显示仍需实际验收。
