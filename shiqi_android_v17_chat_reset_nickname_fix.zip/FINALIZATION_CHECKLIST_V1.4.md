# V1.4 最终验收清单

## GitHub 配置

- [ ] 将 `shiqi_android_v14_persistent_updates.zip` 上传到原仓库根目录。
- [ ] 将此工程的 `.github/workflows/build-apk.yml` 内容替换仓库中的 `.github/workflows/build-apk.yml`。
- [ ] 在仓库 Settings → Secrets and variables → Actions 中配置：
  - `SHELFIE_KEYSTORE_BASE64`
  - `SHELFIE_KEYSTORE_PASSWORD`
  - `SHELFIE_KEY_ALIAS`（值为 `shelfie-upload`）
  - `SHELFIE_KEY_PASSWORD`
- [ ] 运行 `Build and Publish SHELFIE V1.4`，确认自动化测试与 APK 构建成功。
- [ ] 确认 Actions Artifact 与 GitHub Release 都有 `shelfie-v1.4.0.apk`。

## 首次固定签名迁移

- [ ] 若旧 V1.3 仍有物品，先从旧版导出物品 JSON；另行记下 API Base URL 和模型名。
- [ ] 准备好 API Key 以便 V1.4 重新输入；旧 V1.3 的 Keystore API Key 不可由旧版备份导出。
- [ ] 准备头像原图，V1.3 不能导出完整头像库。
- [ ] 只有确认旧版需要迁移的数据已尽可能保存后，才进行一次性卸载/安装固定签名 V1.4。
- [ ] 导入旧版物品 JSON，重新录入 API Key、资料和头像。
- [ ] 设置强密码，导出 V1.4 完整加密备份，并把备份文件与密码分开妥善保存。

## 后续更新验证

- [ ] 以后提升 versionCode / versionName 并使用同一 JKS 构建。
- [ ] 发布新 GitHub Release 后，V1.4 设置页能检测到更新。
- [ ] 允许拾期安装未知应用后，下载并通过 Android 安装器确认覆盖更新。
- [ ] 确认升级后物品、API 配置与 Key、头像库、助手昵称、用户昵称、主题都保留。
- [ ] 验证完整加密备份导出/恢复。
