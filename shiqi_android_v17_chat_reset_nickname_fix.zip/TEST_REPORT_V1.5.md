# SHELFIE V1.5.0 自动化测试报告

## 结果

- Node.js 自动化测试：78 / 78 通过，0 失败。
- JavaScript 语法检查：`app.js`、`photo-recognition.js`、`product-lookup.js`、`ai-mutations.js`、`date-utils.js`、`backup-utils.js` 全部通过。
- HTML 检查：144 个 ID，无重复。
- Android XML：Manifest、旧版备份规则和 Android 12+ 数据提取规则均可解析。
- Android WebView 资源：`www/` 与 `android/app/src/main/assets/www/` 文件逐项一致。
- GitHub Actions YAML：可解析；版本提取命令识别到 versionName 1.5.0 / versionCode 13。
- ZIP 完整性：打包后使用 `unzip -t` 检查。

## 本版新增测试

1. 设置页提供圆形、矩形两种聊天头像形状。
2. 头像形状写入既有个人资料设置，并在重新应用资料 UI 时恢复。
3. 矩形形状 CSS 同时作用于聊天消息头像和助手身份头像。
4. 输入框加号使用 SVG，并通过 Grid 居中。
5. 弹窗关闭叉号使用 SVG，并通过 Grid 居中。
6. Android applicationId、Debug 后缀和固定签名配置保持不变；versionCode 递增至 13，versionName 为 1.5.0。

## 尚未完成

本报告不代表 Android APK 已在本地编译，也不代表 OnePlus 12 真机视觉验收已经完成。需通过 GitHub Actions 使用仓库现有的两个签名 Secrets 构建，并在设备上检查圆形/矩形切换、图标居中、V1.4 到 V1.5 覆盖安装和数据保留。
